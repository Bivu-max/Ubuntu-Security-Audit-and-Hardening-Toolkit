
#!/bin/bash

# ==========================================================
#        ADVANCED UBUNTU SECURITY HARDENING
#                 & AUDIT TOOLKIT
#              SYSTEM SECURITY AUDIT
# ==========================================================

clear

echo "=========================================================="
echo "              SYSTEM SECURITY AUDIT"
echo "=========================================================="
echo

# ----------------------------------------------------------
# Ubuntu Version
# ----------------------------------------------------------

echo "[1] Ubuntu Version"
echo "----------------------------------------------------------"

if command -v lsb_release >/dev/null 2>&1; then
    OS_VERSION=$(lsb_release -ds)
    echo "OS               : $OS_VERSION"
else
    OS_VERSION=$(grep PRETTY_NAME /etc/os-release | cut -d= -f2- | tr -d '"')
    echo "OS               : $OS_VERSION"
fi

echo

# ----------------------------------------------------------
# Kernel Version
# ----------------------------------------------------------

echo "[2] Kernel Information"
echo "----------------------------------------------------------"

KERNEL=$(uname -r)
ARCH=$(uname -m)

echo "Kernel Version    : $KERNEL"
echo "Architecture      : $ARCH"

echo

# ----------------------------------------------------------
# Hostname
# ----------------------------------------------------------

echo "[3] Host Information"
echo "----------------------------------------------------------"

HOSTNAME=$(hostname)
echo "Hostname           : $HOSTNAME"

echo

# ----------------------------------------------------------
# System Uptime
# ----------------------------------------------------------

echo "[4] System Uptime"
echo "----------------------------------------------------------"

UPTIME=$(uptime -p)
echo "Uptime             : $UPTIME"

echo

# ----------------------------------------------------------
# Logged-in Users
# ----------------------------------------------------------

echo "[5] Logged-in Users"
echo "----------------------------------------------------------"

USER_COUNT=$(who | wc -l)

echo "Logged Users       : $USER_COUNT"

if [ "$USER_COUNT" -gt 0 ]; then
    echo
    echo "Currently Logged In:"
    who
else
    echo "No users are currently logged in."
fi

echo

# ----------------------------------------------------------
# Running Services
# ----------------------------------------------------------

echo "[6] Running Services"
echo "----------------------------------------------------------"

if command -v systemctl >/dev/null 2>&1; then

    SERVICE_COUNT=$(systemctl list-units \
        --type=service \
        --state=running \
        --no-legend 2>/dev/null | wc -l)

    echo "Running Services   : $SERVICE_COUNT"

    echo
    echo "Active Services:"
    systemctl list-units \
        --type=service \
        --state=running \
        --no-pager \
        --no-legend 2>/dev/null | head -15

else

    echo "systemctl is not available."

fi

echo

# ----------------------------------------------------------
# System Information
# ----------------------------------------------------------

echo "[7] System Information"
echo "----------------------------------------------------------"

CPU=$(nproc)
MEMORY=$(free -h | awk '/^Mem:/ {print $2}')
DISK=$(df -h / | awk 'NR==2 {print $2}')
USED=$(df -h / | awk 'NR==2 {print $5}')

echo "CPU Cores          : $CPU"
echo "Total Memory       : $MEMORY"
echo "Root Disk Size     : $DISK"
echo "Disk Usage         : $USED"

echo

# ----------------------------------------------------------
# Final Summary
# ----------------------------------------------------------

echo "=========================================================="
echo "                 AUDIT SUMMARY"
echo "=========================================================="

echo "Hostname           : $HOSTNAME"
echo "Operating System   : $OS_VERSION"
echo "Kernel             : $KERNEL"
echo "Uptime             : $UPTIME"
echo "Logged Users       : $USER_COUNT"
echo "Running Services   : $SERVICE_COUNT"
echo "CPU Cores          : $CPU"
echo "Memory             : $MEMORY"
echo "Root Disk Usage    : $USED"

echo
echo "System audit completed successfully."
echo "=========================================================="
