
#!/usr/bin/env bash

# ==========================================
# UBUNTU SECURITY TOOLKIT
# AUTOMATIC REPORT GENERATION
# ==========================================

PROJECT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

REPORT_DIR="$PROJECT_ROOT/reports"
TIMESTAMP=$(date +"%Y%m%d_%H%M%S")
REPORT_FILE="$REPORT_DIR/security_audit_report_$TIMESTAMP.txt"

# Protect the report because it may contain usernames,
# IP addresses and system configuration information.
umask 077

# Create reports directory if it does not exist.
mkdir -p "$REPORT_DIR"

# Create report file.
if ! touch "$REPORT_FILE"; then
    echo "[ERROR] Unable to create report file."
    exit 1
fi

chmod 600 "$REPORT_FILE"

# Module list
MODULES=(
    "modules/user/user_audit.sh"
    "modules/permission/file_permission.sh"
    "modules/password/password_audit.sh"
    "modules/network/network_audit.sh"
    "modules/firewall/firewall_audit.sh"
    "modules/ssh/ssh_audit.sh"
    "modules/service/service_audit.sh"
    "modules/package/package_audit.sh"
    "modules/logs/log_audit.sh"
    "modules/backup/backup.sh"
)

# Execution counters
TOTAL_MODULES=${#MODULES[@]}
SUCCESS_MODULES=0
FAILED_MODULES=0
MISSING_MODULES=0

# Report header
{
    echo "======================================================"
    echo "       UBUNTU SECURITY AUDIT AND HARDENING TOOLKIT"
    echo "             AUTOMATIC SECURITY REPORT"
    echo "======================================================"
    echo ""
    echo "Report Date    : $(date)"
    echo "Hostname       : $(hostname)"
    echo "Kernel Version : $(uname -r)"
    echo "Operating System:"
    grep '^PRETTY_NAME=' /etc/os-release 2>/dev/null | cut -d= -f2- | tr -d '"'
    echo ""
    echo "Total Modules  : $TOTAL_MODULES"
    echo "======================================================"
    echo ""
} >> "$REPORT_FILE"

echo "=========================================="
echo "     AUTOMATIC REPORT GENERATION"
echo "=========================================="

echo ""
echo "[+] Report file created:"
echo "$REPORT_FILE"

# Administrator authentication
echo ""
echo "[+] Checking administrator access..."

if sudo -v; then
    echo "[+] Administrator access available."
    echo "Administrator access: Available" >> "$REPORT_FILE"
else
    echo "[!] Administrator access unavailable."
    echo "Administrator access: Unavailable" >> "$REPORT_FILE"
    echo "Some checks may require manual authentication." >> "$REPORT_FILE"
fi

# Function to execute and record a module
run_report_module() {

    MODULE_PATH="$PROJECT_ROOT/$1"

    echo ""
    echo "[+] Running: $1"

    {
        echo ""
        echo "======================================================"
        echo "MODULE: $1"
        echo "======================================================"
        echo ""
    } >> "$REPORT_FILE"

    if [ ! -f "$MODULE_PATH" ]; then

        echo "[ERROR] Module file not found: $1" >> "$REPORT_FILE"
        echo "[!] Module file not found."

        ((MISSING_MODULES+=1))
        ((FAILED_MODULES+=1))
        return

    fi

    if bash "$MODULE_PATH" >> "$REPORT_FILE" 2>&1; then

        echo "[+] Execution completed."
        echo "[MODULE STATUS: SUCCESS]" >> "$REPORT_FILE"

        ((SUCCESS_MODULES+=1))

    else

        echo "[!] Module execution failed."
        echo "[MODULE STATUS: FAILED]" >> "$REPORT_FILE"

        ((FAILED_MODULES+=1))

    fi
}

# Execute all modules
for MODULE in "${MODULES[@]}"; do
    run_report_module "$MODULE"
done

# Final report summary
{
    echo ""
    echo "======================================================"
    echo "                 FINAL REPORT SUMMARY"
    echo "======================================================"
    echo "Total Modules       : $TOTAL_MODULES"
    echo "Successful Modules  : $SUCCESS_MODULES"
    echo "Failed Modules      : $FAILED_MODULES"
    echo "Missing Modules     : $MISSING_MODULES"
    echo ""
    echo "Report Generated    : $(date)"
    echo "Report File         : $REPORT_FILE"
    echo "======================================================"
    echo ""
    echo "END OF SECURITY AUDIT REPORT"
} >> "$REPORT_FILE"

# Display final information
echo ""
echo "=========================================="
echo "       REPORT GENERATION COMPLETED"
echo "=========================================="

echo "Total Modules      : $TOTAL_MODULES"
echo "Successful Modules : $SUCCESS_MODULES"
echo "Failed Modules     : $FAILED_MODULES"
echo "Missing Modules    : $MISSING_MODULES"

echo ""
echo "Report Location:"
echo "$REPORT_FILE"

echo ""
echo "Report Size:"
du -h "$REPORT_FILE" | cut -f1

echo ""
echo "=========================================="
