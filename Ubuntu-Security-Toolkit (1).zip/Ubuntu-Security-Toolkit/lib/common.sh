#!/bin/bash
# ==============================================================================
#   common.sh — Common Functions, Colors & Interface
#   Advanced Ubuntu Security Toolkit
#   Shared Library for All Security Audit Modules
# ==============================================================================

# Prevent multiple loading of this library
if [ "${COMMON_SH_LOADED:-0}" -eq 1 ]; then
    return 0
fi

COMMON_SH_LOADED=1


# ==============================================================================
#                         COLOR DEFINITIONS
# ==============================================================================

# Basic colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
WHITE='\033[1;37m'

# Light / bright colors
LRED='\033[1;31m'
LGREEN='\033[1;32m'
LBLUE='\033[1;34m'
LCYAN='\033[1;36m'

# Formatting
BOLD='\033[1m'
DIM='\033[2m'
NC='\033[0m'


# ==============================================================================
#                         LAYOUT CONFIGURATION
# ==============================================================================

# Main toolkit width
BOX_WIDTH=70

# Standard horizontal line
LINE="  ──────────────────────────────────────────────────────────────────────"

# Short horizontal line
SHORT_LINE="  ────────────────────────────────────────────────"


# ==============================================================================
#                         TERMINAL CONTROL
# ==============================================================================

# Hide cursor
hide_cursor() {
    printf '\033[?25l'
}

# Show cursor
show_cursor() {
    printf '\033[?25h'
}

# Restore cursor when script exits
trap show_cursor EXIT


# ==============================================================================
#                         MAIN TOOLKIT BANNER
# ==============================================================================

banner() {

    clear

    echo
    echo -e "${BLUE}${BOLD}"
    echo "  ╔══════════════════════════════════════════════════════════════════════╗"
    echo "  ║                                                                      ║"
    echo "  ║              ADVANCED UBUNTU SECURITY TOOLKIT                       ║"
    echo "  ║                                                                      ║"
    echo "  ╚══════════════════════════════════════════════════════════════════════╝"
    echo -e "${NC}"

    echo -e "  ${DIM}Date      :${NC} ${WHITE}$(date '+%d %B %Y')${NC}"
    echo -e "  ${DIM}Time      :${NC} ${WHITE}$(date '+%H:%M:%S %Z')${NC}"
    echo -e "  ${DIM}User      :${NC} ${WHITE}$(whoami)${NC}"
    echo -e "  ${DIM}Hostname  :${NC} ${WHITE}$(hostname)${NC}"

    echo
}


# ==============================================================================
#                         MODULE HEADER
# ==============================================================================

module_header() {

    local module_name="$1"
    local module_number="$2"

    echo
    echo -e "${BLUE}${BOLD}"
    echo "  ╔══════════════════════════════════════════════════════════════════════╗"
    echo "  ║                                                                      ║"

    printf "  ║%*s%s%*s║\n" \
        $(( (68 - ${#module_name}) / 2 )) "" \
        "$module_name" \
        $(( 68 - ${#module_name} - (68 - ${#module_name}) / 2 )) ""

    echo "  ║                                                                      ║"

    printf "  ║%*sMODULE %s / 7%*s║\n" \
        $(( (68 - 12) / 2 )) "" \
        "$module_number" \
        $(( 68 - 12 - (68 - 12) / 2 )) ""

    echo "  ╚══════════════════════════════════════════════════════════════════════╝"
    echo -e "${NC}"

}


# ==============================================================================
#                         SECTION HEADER
# ==============================================================================

section() {

    local title="$1"

    echo
    echo -e "${LCYAN}${BOLD}  ${title}${NC}"
    echo -e "${DIM}${LINE}${NC}"
    echo

}


# ==============================================================================
#                         SUBSECTION HEADER
# ==============================================================================

subsection() {

    local title="$1"

    echo
    echo -e "  ${LBLUE}${BOLD}▶ ${title}${NC}"
    echo -e "  ${DIM}${SHORT_LINE}${NC}"

}


# ==============================================================================
#                         INFORMATION ROW
# ==============================================================================

# Usage:
# row "Label" "Value" info
# row "Status" "Secure" ok
# row "Warning" "Review required" warn
# row "Problem" "Detected" bad

row() {

    local label="$1"
    local value="$2"
    local status="${3:-info}"

    local colour
    local icon

    case "$status" in

        ok)
            colour="$LGREEN"
            icon="✔"
            ;;

        warn)
            colour="$YELLOW"
            icon="⚠"
            ;;

        bad)
            colour="$LRED"
            icon="✖"
            ;;

        info)
            colour="$LCYAN"
            icon="ℹ"
            ;;

        *)
            colour="$WHITE"
            icon="•"
            ;;

    esac

    printf "  ${WHITE}%-32s${NC} ${colour}%s  %s${NC}\n" \
        "$label" "$icon" "$value"

}


# ==============================================================================
#                         SIMPLE VALUE ROW
# ==============================================================================

value_row() {

    local label="$1"
    local value="$2"

    printf "  ${WHITE}%-32s${NC} : ${CYAN}%s${NC}\n" \
        "$label" "$value"

}


# ==============================================================================
#                         MENU OPTION
# ==============================================================================

menu_option() {

    local number="$1"
    local title="$2"
    local description="$3"

    echo -e "  ${LCYAN}${BOLD}[$number]${NC}  ${WHITE}${BOLD}${title}${NC}"
    echo -e "       ${DIM}${description}${NC}"

}


# ==============================================================================
#                         MENU FOOTER
# ==============================================================================

menu_footer() {

    echo
    echo -e "  ${DIM}${LINE}${NC}"
    echo

}


# ==============================================================================
#                         INPUT BOX
# ==============================================================================

read_choice() {

    local max="$1"

    echo
    echo -e "  ${CYAN}┌─[ SELECT OPTION ]───────────────────────────────────────────────┐${NC}"
    echo -ne "  ${CYAN}└─${NC} Enter your choice ${WHITE}[0-${max}]${NC}: "

    read -r choice

    echo -e "${CYAN}  └───────────────────────────────────────────────────────────────┘${NC}"

}


# ==============================================================================
#                         YES / NO INPUT
# ==============================================================================

read_confirmation() {

    local message="$1"

    echo
    echo -ne "  ${YELLOW}${message} [y/N]: ${NC}"
    read -r confirmation

    case "$confirmation" in
        y|Y|yes|YES)
            return 0
            ;;
        *)
            return 1
            ;;
    esac

}


# ==============================================================================
#                         PAUSE SCREEN
# ==============================================================================

pause_screen() {

    echo
    echo -e "  ${DIM}──────────────────────────────────────────────────────────────────────${NC}"
    echo -e "  ${DIM}[ Press ENTER to continue ]${NC}"
    read -r

}


# ==============================================================================
#                         SUCCESS MESSAGE
# ==============================================================================

success_message() {

    local message="$1"

    echo
    echo -e "  ${LGREEN}✔ ${message}${NC}"

}


# ==============================================================================
#                         WARNING MESSAGE
# ==============================================================================

warning_message() {

    local message="$1"

    echo
    echo -e "  ${YELLOW}⚠ ${message}${NC}"

}


# ==============================================================================
#                         ERROR MESSAGE
# ==============================================================================

error_message() {

    local message="$1"

    echo
    echo -e "  ${LRED}✖ ${message}${NC}"

}


# ==============================================================================
#                         INFORMATION MESSAGE
# ==============================================================================

info_message() {

    local message="$1"

    echo
    echo -e "  ${LCYAN}ℹ ${message}${NC}"

}


# ==============================================================================
#                         ROOT PRIVILEGE CHECK
# ==============================================================================

require_root() {

    if [ "$(id -u)" -ne 0 ]; then

        echo
        echo -e "  ${YELLOW}⚠ ADMINISTRATOR PRIVILEGES REQUIRED${NC}"
        echo -e "  ${DIM}${LINE}${NC}"
        echo
        echo -e "  ${WHITE}This audit requires root privileges.${NC}"
        echo
        echo -e "  ${CYAN}Run the toolkit using:${NC}"
        echo
        echo -e "  ${LGREEN}sudo ./main.sh${NC}"
        echo

        pause_screen

        return 1
    fi

    return 0

}


# ==============================================================================
#                         COMMAND AVAILABILITY
# ==============================================================================

command_exists() {

    command -v "$1" >/dev/null 2>&1

}


# ==============================================================================
#                         SAFE VALUE
# ==============================================================================

safe_value() {

    if [ -n "$1" ]; then
        printf '%s' "$1"
    else
        printf '%s' "N/A"
    fi

}


# ==============================================================================
#                         FILE EXISTENCE CHECK
# ==============================================================================

file_exists() {

    [ -f "$1" ]

}


# ==============================================================================
#                         DIRECTORY EXISTENCE CHECK
# ==============================================================================

directory_exists() {

    [ -d "$1" ]

}


# ==============================================================================
#                         SERVICE STATUS
# ==============================================================================

service_status() {

    local service="$1"

    if ! command_exists systemctl; then
        echo "systemctl unavailable"
        return 1
    fi

    if systemctl is-active --quiet "$service" 2>/dev/null; then
        echo "active"
        return 0

    elif systemctl is-enabled --quiet "$service" 2>/dev/null; then
        echo "enabled"

    else
        echo "inactive"

    fi

}


# ==============================================================================
#                         STATUS DISPLAY
# ==============================================================================

display_status() {

    local status="$1"

    case "$status" in

        active|running|enabled|ok|secure|installed)
            echo -e "${LGREEN}✔ ${status}${NC}"
            ;;

        inactive|disabled|warning|review)
            echo -e "${YELLOW}⚠ ${status}${NC}"
            ;;

        failed|error|critical|danger)
            echo -e "${LRED}✖ ${status}${NC}"
            ;;

        *)
            echo -e "${LCYAN}ℹ ${status}${NC}"
            ;;

    esac

}


# ==============================================================================
#                         TABLE HEADER
# ==============================================================================

table_header() {

    local header="$1"

    echo -e "${CYAN}  ┌──────────────────────────────────────────────────────────────────────┐${NC}"
    printf "${CYAN}  │${NC} ${WHITE}${BOLD}%-68s${NC} ${CYAN}│${NC}\n" "$header"
    echo -e "${CYAN}  ├──────────────────────────────────────────────────────────────────────┤${NC}"

}


# ==============================================================================
#                         TABLE FOOTER
# ==============================================================================

table_footer() {

    echo -e "${CYAN}  └──────────────────────────────────────────────────────────────────────┘${NC}"

}


# ==============================================================================
#                         CENTERED TEXT
# ==============================================================================

center_text() {

    local text="$1"
    local width="${2:-68}"

    local length=${#text}

    if [ "$length" -ge "$width" ]; then
        echo "$text"
        return
    fi

    local left=$(( (width - length) / 2 ))
    local right=$(( width - length - left ))

    printf "%*s%s%*s\n" \
        "$left" "" \
        "$text" \
        "$right" ""

}


# ==============================================================================
#                         SECTION DIVIDER
# ==============================================================================

divider() {

    echo -e "${DIM}${LINE}${NC}"

}


# ==============================================================================
#                         CHECK RESULT
# ==============================================================================

check_result() {

    local label="$1"
    local result="$2"

    case "$result" in

        PASS|OK|SECURE|ACTIVE|ENABLED)
            printf "  ${LGREEN}✔ %-28s : %-20s${NC}\n" \
                "$label" "$result"
            ;;

        WARNING|REVIEW|INACTIVE|DISABLED)
            printf "  ${YELLOW}⚠ %-28s : %-20s${NC}\n" \
                "$label" "$result"
            ;;

        FAIL|FAILED|CRITICAL|DANGER)
            printf "  ${LRED}✖ %-28s : %-20s${NC}\n" \
                "$label" "$result"
            ;;

        *)
            printf "  ${LCYAN}ℹ %-28s : %-20s${NC}\n" \
                "$label" "$result"
            ;;

    esac

}


# ==============================================================================
#                         COUNT LINES SAFELY
# ==============================================================================

count_lines() {

    local data="$1"

    if [ -z "$data" ]; then
        echo "0"
    else
        printf '%s\n' "$data" | grep -c '[^[:space:]]'
    fi

}


# ==============================================================================
#                         GET FIRST IP ADDRESS
# ==============================================================================

get_primary_ip() {

    hostname -I 2>/dev/null |
        awk '{print $1}'

}


# ==============================================================================
#                         GET OS INFORMATION
# ==============================================================================

get_os_name() {

    if [ -f /etc/os-release ]; then

        # shellcheck disable=SC1091
        . /etc/os-release

        echo "${PRETTY_NAME:-${NAME:-Ubuntu}}"

    else

        echo "Unknown"

    fi

}


# ==============================================================================
#                         EXIT MESSAGE
# ==============================================================================

exit_message() {

    clear
    echo
    echo -e "  ${BLUE}══════════════════════════════════════════════════════════════════════${NC}"
    echo
    echo -e "  ${LGREEN}${BOLD}✔ Advanced Ubuntu Security Toolkit closed.${NC}"
    echo
    echo -e "  ${DIM}Stay secure. Keep your system updated.${NC}"
    echo
    echo -e "  ${BLUE}══════════════════════════════════════════════════════════════════════${NC}"
    echo

}


# ==============================================================================
#                         END OF COMMON LIBRARY
# ==============================================================================

return 0
