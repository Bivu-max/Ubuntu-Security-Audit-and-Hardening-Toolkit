
#!/bin/bash

# ==========================================
# UBUNTU LOG MONITORING AND SECURITY AUDIT
# ==========================================

PROJECT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"

source "$PROJECT_ROOT/lib/common.sh"

echo "=========================================="
echo "     LOG MONITORING SECURITY AUDIT"
echo "=========================================="

# 1. Check journalctl availability

echo ""
echo "1. Checking System Journal"

if ! command -v journalctl >/dev/null 2>&1; then
    error "journalctl command is unavailable"
    print_summary
    exit 1
fi

pass "System journal utility is available"

# 2. Check recent system logs

echo ""
echo "2. Checking Recent System Logs"

if sudo journalctl -n 10 --no-pager; then
    pass "Recent system logs retrieved"
else
    warning "Unable to retrieve system journal logs"
fi

# 3. Check recent system errors

echo ""
echo "3. Checking Recent System Errors"

ERROR_LOGS=$(sudo journalctl -p err -n 20 --no-pager 2>/dev/null)

if [ -z "$ERROR_LOGS" ]; then
    pass "No recent system errors detected"
else
    echo "$ERROR_LOGS"
    warning "Recent system errors found - review the messages"
fi

# 4. Check failed login attempts

echo ""
echo "4. Checking Failed Login Attempts"

if command -v lastb >/dev/null 2>&1; then

    FAILED_LOGINS=$(sudo lastb -n 10 2>/dev/null)

    if [ -z "$FAILED_LOGINS" ]; then
        pass "No failed login records found"
    else
        echo "$FAILED_LOGINS"
        warning "Failed login records detected"
    fi

else
    warning "lastb utility is unavailable"
fi

# 5. Check SSH authentication failures

echo ""
echo "5. Checking SSH Authentication Failures"

SSH_FAILURES=$(sudo journalctl -u ssh -u sshd \
    --since "24 hours ago" --no-pager 2>/dev/null |
    grep -Ei 'failed password|authentication failure|invalid user' |
    tail -n 20)

if [ -z "$SSH_FAILURES" ]; then
    pass "No matching SSH authentication failure messages found"
else
    echo "$SSH_FAILURES"
    warning "SSH authentication failure messages detected"
fi

# 6. Check authentication log file

echo ""
echo "6. Checking Authentication Log File"

AUTH_LOG="/var/log/auth.log"

if [ -f "$AUTH_LOG" ]; then

    pass "Authentication log file exists"

    echo ""
    echo "Recent authentication log entries:"

    sudo tail -n 10 "$AUTH_LOG"

else
    warning "Authentication log file is unavailable"
    echo "This may be normal on systems using journal-only logging."
fi

# 7. Check failed system services

echo ""
echo "7. Checking Failed Services"

FAILED_SERVICES=$(systemctl --failed \
    --type=service --no-legend --no-pager)

if [ -z "$FAILED_SERVICES" ]; then
    pass "No failed system services detected"
else
    echo "$FAILED_SERVICES"
    warning "Failed services found - investigate their logs"
fi

# 8. Check recent critical-level events

echo ""
echo "8. Checking Critical System Events"

CRITICAL_LOGS=$(sudo journalctl -p crit \
    --since "24 hours ago" --no-pager 2>/dev/null)

if [ -z "$CRITICAL_LOGS" ]; then
    pass "No critical journal events found in the last 24 hours"
else
    echo "$CRITICAL_LOGS"
    warning "Critical journal events detected"
fi

# 9. Final summary

echo ""
print_summary

echo ""
echo "=========================================="
echo " LOG MONITORING AUDIT COMPLETED"
echo "=========================================="
