
#!/bin/bash

# ==========================================
# UBUNTU NETWORK SECURITY AUDIT
# ==========================================

PROJECT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"

source "$PROJECT_ROOT/lib/common.sh"

echo "=========================================="
echo "        NETWORK SECURITY AUDIT"
echo "=========================================="

# 1. Check network interfaces

echo ""
echo "1. Checking Network Interfaces"

if command -v ip >/dev/null 2>&1; then

    ip -brief address

    if ip -brief address | grep -q "UP"; then
        pass "Active network interface detected"
    else
        warning "No active network interface detected"
    fi

else
    error "IP networking command is unavailable"
fi

# 2. Check default gateway and routing table

echo ""
echo "2. Checking Routing Table"

ip route show

if ip route show default | grep -q "default"; then
    pass "Default gateway is configured"
else
    warning "No default gateway detected"
fi

# 3. Check active network connections

echo ""
echo "3. Checking Active Network Connections"

if command -v ss >/dev/null 2>&1; then

    ss -tun

    pass "Network connection information retrieved"

else
    error "ss command is not installed"
fi

# 4. Check listening ports

echo ""
echo "4. Checking Listening TCP and UDP Ports"

if command -v ss >/dev/null 2>&1; then

    LISTENING_PORTS=$(ss -tuln)

    echo "$LISTENING_PORTS"

    PORT_COUNT=$(printf '%s\n' "$LISTENING_PORTS" | tail -n +2 | wc -l)

    echo ""
    echo "Number of listening socket entries: $PORT_COUNT"

    if [ "$PORT_COUNT" -gt 0 ]; then
        warning "Listening ports detected - review whether each service is required"
    else
        pass "No listening ports detected"
    fi

fi

# 5. Check IP forwarding

echo ""
echo "5. Checking IPv4 IP Forwarding"

IP_FORWARD=$(sysctl -n net.ipv4.ip_forward 2>/dev/null)

echo "IPv4 IP Forwarding: ${IP_FORWARD:-Unavailable}"

if [ "$IP_FORWARD" = "0" ]; then
    pass "IPv4 forwarding is disabled"
elif [ "$IP_FORWARD" = "1" ]; then
    warning "IPv4 forwarding is enabled - review whether routing is required"
else
    warning "Could not determine IPv4 forwarding status"
fi

# 6. Check DNS configuration

echo ""
echo "6. Checking DNS Configuration"

if [ -r /etc/resolv.conf ]; then

    cat /etc/resolv.conf

    if grep -Eq '^[[:space:]]*nameserver[[:space:]]+' /etc/resolv.conf; then
        pass "DNS nameserver configuration detected"
    else
        warning "No DNS nameserver entry detected"
    fi

else
    warning "DNS configuration file is not readable"
fi

# 7. Check network interface details

echo ""
echo "7. Checking Network Interface Details"

ip -brief link

pass "Network interface details collected"

# 8. Final summary

echo ""
print_summary

echo ""
echo "=========================================="
echo " NETWORK SECURITY AUDIT COMPLETED"
echo "=========================================="
