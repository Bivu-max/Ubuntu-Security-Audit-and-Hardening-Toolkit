clear
#!/usr/bin/env bash
# ==============================================================================
# MODULE: FILE PERMISSION SECURITY AUDIT
# Advanced Ubuntu Security Hardening & Audit Toolkit
# ==============================================================================
set -o pipefail

# ------------------------------------------------------------------------------
# 1. BOOTSTRAP & LIBRARY SOURCING
# ------------------------------------------------------------------------------
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"

if [ -f "$PROJECT_ROOT/lib/common.sh" ]; then
    source "$PROJECT_ROOT/lib/common.sh"
else
    echo -e "\033[1;31m[ERROR] Cannot find lib/common.sh at $PROJECT_ROOT/lib/common.sh\033[0m"
    exit 2
fi

# ------------------------------------------------------------------------------
# 2. GLOBAL AUDIT VARIABLES
# ------------------------------------------------------------------------------
TOTAL_CHECKS=0
PASSED_CHECKS=0
WARNING_CHECKS=0
ERROR_CHECKS=0

# Files to audit
F_PASSWD="/etc/passwd"
F_SHADOW="/etc/shadow"
F_GROUP="/etc/group"
F_GSHADOW="/etc/gshadow"
F_SUDOERS="/etc/sudoers"

# Data containers
declare -A FILE_EXISTS
declare -A FILE_OCT
declare -A FILE_SYM
declare -A FILE_OWN
declare -A FILE_GRP

# ------------------------------------------------------------------------------
# 3. HELPER FUNCTIONS FOR METRICS & LOGIC
# ------------------------------------------------------------------------------
increment_pass()  { ((TOTAL_CHECKS++)); ((PASSED_CHECKS++)); }
increment_warn()  { ((TOTAL_CHECKS++)); ((WARNING_CHECKS++)); }
increment_error() { ((TOTAL_CHECKS++)); ((ERROR_CHECKS++)); }

# Check if an octal permission string (e.g. "644" or "0644") grants world-write (last digit 2, 3, 6, 7)
is_world_writable() {
    local octal="$1"
    local others="${octal: -1}"
    [[ "$others" =~ [2367] ]]
}

# Check if an octal permission string grants world-read (last digit 4, 5, 6, 7)
is_world_readable() {
    local octal="$1"
    local others="${octal: -1}"
    [[ "$others" =~ [4567] ]]
}

# Check if an octal permission string grants group-read (second to last digit 4, 5, 6, 7)
is_group_readable() {
    local octal="$1"
    local group_perms="${octal: -2:1}"
    [[ "$group_perms" =~ [4567] ]]
}

# ------------------------------------------------------------------------------
# 4. DATA COLLECTION
# ------------------------------------------------------------------------------
collect_information() {
    local files=("$F_PASSWD" "$F_SHADOW" "$F_GROUP" "$F_GSHADOW" "$F_SUDOERS")
    
    for f in "${files[@]}"; do
        if file_exists "$f"; then
            FILE_EXISTS[$f]=1
            # Using standard GNU stat available on Ubuntu
            FILE_OCT[$f]=$(stat -c "%a" "$f" 2>/dev/null || echo "N/A")
            FILE_SYM[$f]=$(stat -c "%A" "$f" 2>/dev/null || echo "N/A")
            FILE_OWN[$f]=$(stat -c "%U" "$f" 2>/dev/null || echo "N/A")
            FILE_GRP[$f]=$(stat -c "%G" "$f" 2>/dev/null || echo "N/A")
        else
            FILE_EXISTS[$f]=0
            FILE_OCT[$f]="N/A"
            FILE_SYM[$f]="N/A"
            FILE_OWN[$f]="N/A"
            FILE_GRP[$f]="N/A"
        fi
    done
}

# ------------------------------------------------------------------------------
# 5. PRESENTATION
# ------------------------------------------------------------------------------
display_information() {
    module_header "FILE PERMISSION SECURITY AUDIT" "3"
    
    section "SYSTEM FILE PERMISSIONS INVENTORY"
    
    local files=("$F_PASSWD" "$F_SHADOW" "$F_GROUP" "$F_GSHADOW" "$F_SUDOERS")
    
    for f in "${files[@]}"; do
        subsection "$f"
        if [ "${FILE_EXISTS[$f]}" -eq 1 ]; then
            value_row "Numeric Permissions" "$(safe_value "${FILE_OCT[$f]}")"
            value_row "Symbolic Permissions" "$(safe_value "${FILE_SYM[$f]}")"
            value_row "Owner" "$(safe_value "${FILE_OWN[$f]}")"
            value_row "Group" "$(safe_value "${FILE_GRP[$f]}")"
        else
            row "File Status" "File does not exist" "warn"
        fi
    done
}

# ------------------------------------------------------------------------------
# 6. SECURITY ANALYSIS & CHECKS
# ------------------------------------------------------------------------------
perform_security_checks() {
    section "SECURITY AUDIT RESULTS"
    
    local files=("$F_PASSWD" "$F_SHADOW" "$F_GROUP" "$F_GSHADOW" "$F_SUDOERS")
    
    # 1. Check File Existence for required files
    for f in "${files[@]}"; do
        if [ "${FILE_EXISTS[$f]}" -eq 1 ]; then
            row "$f existence" "Secure configuration detected" "ok"
            increment_pass
        else
            row "$f existence" "Missing critical system file" "bad"
            increment_error
        fi
    done

    # 2. Check World-Writable Status (All files)
    for f in "${files[@]}"; do
        if [ "${FILE_EXISTS[$f]}" -eq 1 ]; then
            if is_world_writable "${FILE_OCT[$f]}"; then
                row "$f world-writable" "Potential security issue detected" "bad"
                increment_error
            else
                row "$f world-writable" "Secure configuration detected" "ok"
                increment_pass
            fi
        fi
    done

    # 3. Specific Checks: /etc/shadow
    if [ "${FILE_EXISTS[$F_SHADOW]}" -eq 1 ]; then
        if is_world_readable "${FILE_OCT[$F_SHADOW]}"; then
            row "/etc/shadow world-readable" "Potential security issue detected" "bad"
            increment_error
        else
            row "/etc/shadow world-readable" "Secure configuration detected" "ok"
            increment_pass
        fi

        if [[ "${FILE_OWN[$F_SHADOW]}" != "root" ]]; then
            row "/etc/shadow owner" "Potential security issue detected (Not root)" "bad"
            increment_error
        else
            row "/etc/shadow owner" "Secure configuration detected" "ok"
            increment_pass
        fi

        if [[ "${FILE_GRP[$F_SHADOW]}" == "shadow" || "${FILE_GRP[$F_SHADOW]}" == "root" ]]; then
            row "/etc/shadow group" "Secure configuration detected" "ok"
            increment_pass
        else
            row "/etc/shadow group" "Manual review recommended (Group not shadow/root)" "warn"
            increment_warn
        fi
    fi

    # 4. Specific Checks: /etc/gshadow
    if [ "${FILE_EXISTS[$F_GSHADOW]}" -eq 1 ]; then
        if is_world_readable "${FILE_OCT[$F_GSHADOW]}"; then
            row "/etc/gshadow world-readable" "Potential security issue detected" "bad"
            increment_error
        else
            row "/etc/gshadow world-readable" "Secure configuration detected" "ok"
            increment_pass
        fi
        
        if [[ "${FILE_OWN[$F_GSHADOW]}" != "root" ]]; then
            row "/etc/gshadow owner" "Potential security issue detected (Not root)" "bad"
            increment_error
        else
            row "/etc/gshadow owner" "Secure configuration detected" "ok"
            increment_pass
        fi
    fi

    # 5. Specific Checks: /etc/sudoers
    if [ "${FILE_EXISTS[$F_SUDOERS]}" -eq 1 ]; then
        if is_world_readable "${FILE_OCT[$F_SUDOERS]}"; then
            row "/etc/sudoers world-readable" "Manual review recommended" "warn"
            increment_warn
        else
            row "/etc/sudoers world-readable" "Secure configuration detected" "ok"
            increment_pass
        fi
        
        # Standard strict permissions for sudoers is 0440
        if [[ "${FILE_OCT[$F_SUDOERS]}" == "440" || "${FILE_OCT[$F_SUDOERS]}" == "0440" ]]; then
            row "/etc/sudoers strict perms (440)" "Secure configuration detected" "ok"
            increment_pass
        else
            row "/etc/sudoers strict perms (440)" "Manual review recommended" "warn"
            increment_warn
        fi
    fi
}

# ------------------------------------------------------------------------------
# 7. SUMMARY
# ------------------------------------------------------------------------------
show_summary() {
    section "MODULE SUMMARY"
    
    value_row "Checks Performed" "$TOTAL_CHECKS"
    value_row "Passed" "${LGREEN}${PASSED_CHECKS}${NC}"
    value_row "Warnings" "${YELLOW}${WARNING_CHECKS}${NC}"
    value_row "Errors" "${LRED}${ERROR_CHECKS}${NC}"
    
    divider
    
    if [ "$ERROR_CHECKS" -gt 0 ]; then
        row "Security Status" "ATTENTION REQUIRED" "bad"
    elif [ "$WARNING_CHECKS" -gt 0 ]; then
        row "Security Status" "REVIEW RECOMMENDED" "warn"
    else
        row "Security Status" "GOOD" "ok"
    fi
    echo
}

# ------------------------------------------------------------------------------
# 8. MAIN EXECUTION
# ------------------------------------------------------------------------------
main() {
    # 1. Collect information
    collect_information
    
    # 2. Display collected information
    display_information
    
    # 3. Perform security analysis
    perform_security_checks
    
    # 4. Display audit summary
    show_summary
    
    return 0
}

main "$@"