clear
#!/usr/bin/env bash
# ==============================================================================
# MODULE: DIRECTORY PERMISSION SECURITY AUDIT
# Advanced Ubuntu Security Hardening & Audit Toolkit
# ==============================================================================
set -o pipefail

# ------------------------------------------------------------------------------
# 1. BOOTSTRAP & LIBRARY SOURCING
# ------------------------------------------------------------------------------
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"

if [ -f "$PROJECT_ROOT/lib/common.sh" ]; then
    source "$PROJECT_ROOT/lib/common.sh"
else
    echo -e "\033[1;31m[ERROR] Cannot find lib/common.sh at $PROJECT_ROOT/lib/common.sh\033[0m"
    exit 2
fi

# ------------------------------------------------------------------------------
# 2. GLOBAL AUDIT VARIABLES
# ------------------------------------------------------------------------------
TOTAL_CHECKS=0
PASSED_CHECKS=0
WARNING_CHECKS=0
ERROR_CHECKS=0

TARGET_DIRS=(
    "/etc"
    "/var"
    "/var/log"
    "/home"
    "/tmp"
    "/var/tmp"
    "/usr"
    "/boot"
)

declare -A DIR_EXISTS
declare -A DIR_OCT
declare -A DIR_SYM
declare -A DIR_OWN
declare -A DIR_GRP

# ------------------------------------------------------------------------------
# 3. HELPER FUNCTIONS FOR METRICS
# ------------------------------------------------------------------------------
increment_pass()  { ((TOTAL_CHECKS++)); ((PASSED_CHECKS++)); }
increment_warn()  { ((TOTAL_CHECKS++)); ((WARNING_CHECKS++)); }
increment_error() { ((TOTAL_CHECKS++)); ((ERROR_CHECKS++)); }

# Check if an octal permission grants world-write (last digit 2, 3, 6, 7)
is_world_writable() {
    local oct="$1"
    local last_digit="${oct: -1}"
    [[ "$last_digit" =~ [2367] ]]
}

# Check if an octal permission has the sticky bit set (4 chars, first is 1, 3, 5, 7)
has_sticky_bit() {
    local oct="$1"
    if [ ${#oct} -eq 4 ]; then
        local first_digit="${oct:0:1}"
        [[ "$first_digit" =~ [1357] ]]
    else
        return 1
    fi
}

# ------------------------------------------------------------------------------
# 4. DATA COLLECTION
# ------------------------------------------------------------------------------
collect_information() {
    local d
    for d in "${TARGET_DIRS[@]}"; do
        if directory_exists "$d"; then
            DIR_EXISTS[$d]=1
            DIR_OCT[$d]=$(stat -c "%a" "$d" 2>/dev/null || echo "N/A")
            DIR_SYM[$d]=$(stat -c "%A" "$d" 2>/dev/null || echo "N/A")
            DIR_OWN[$d]=$(stat -c "%U" "$d" 2>/dev/null || echo "N/A")
            DIR_GRP[$d]=$(stat -c "%G" "$d" 2>/dev/null || echo "N/A")
        else
            DIR_EXISTS[$d]=0
            DIR_OCT[$d]="N/A"
            DIR_SYM[$d]="N/A"
            DIR_OWN[$d]="N/A"
            DIR_GRP[$d]="N/A"
        fi
    done
}

# ------------------------------------------------------------------------------
# 5. PRESENTATION
# ------------------------------------------------------------------------------
display_information() {
    module_header "DIRECTORY PERMISSION SECURITY AUDIT" "3"
    
    section "SYSTEM DIRECTORIES INVENTORY"
    
    local d
    for d in "${TARGET_DIRS[@]}"; do
        subsection "$d"
        if [ "${DIR_EXISTS[$d]}" -eq 1 ]; then
            value_row "Numeric Permissions" "$(safe_value "${DIR_OCT[$d]}")"
            value_row "Symbolic Permissions" "$(safe_value "${DIR_SYM[$d]}")"
            value_row "Owner" "$(safe_value "${DIR_OWN[$d]}")"
            value_row "Group" "$(safe_value "${DIR_GRP[$d]}")"
        else
            row "Directory Status" "Directory does not exist" "warn"
        fi
    done
}

# ------------------------------------------------------------------------------
# 6. SECURITY ANALYSIS & CHECKS
# ------------------------------------------------------------------------------
perform_security_checks() {
    section "SECURITY AUDIT RESULTS"
    
    local d
    for d in "${TARGET_DIRS[@]}"; do
        
        # 1. Directory Existence Check
        if [ "${DIR_EXISTS[$d]}" -eq 1 ]; then
            row "$d existence" "Secure configuration detected" "ok"
            increment_pass
        else
            row "$d existence" "Critical directory missing" "bad"
            increment_error
            continue
        fi

        local oct="${DIR_OCT[$d]}"
        
        # 2. Analyze Expected Shared Directories (/tmp, /var/tmp)
        if [[ "$d" == "/tmp" || "$d" == "/var/tmp" ]]; then
            if has_sticky_bit "$oct"; then
                row "$d sticky bit" "Secure configuration detected" "ok"
                increment_pass
            else
                row "$d sticky bit" "Potential security issue detected (Missing)" "bad"
                increment_error
            fi
            
            if is_world_writable "$oct"; then
                row "$d world-writable" "Normal configuration for shared dir" "info"
            fi
            
        # 3. Analyze Standard System Directories (/etc, /var, /usr, /boot)
        elif [[ "$d" == "/etc" || "$d" == "/var" || "$d" == "/usr" || "$d" == "/boot" || "$d" == "/var/log" ]]; then
            if is_world_writable "$oct"; then
                row "$d world-writable" "Potential security issue detected" "bad"
                increment_error
            else
                row "$d world-writable" "Secure configuration detected" "ok"
                increment_pass
            fi
            
            # Check for unusual owner (Not root)
            if [[ "${DIR_OWN[$d]}" != "root" ]]; then
                row "$d owner" "Manual review recommended (Not root)" "warn"
                increment_warn
            else
                row "$d owner" "Secure configuration detected" "ok"
                increment_pass
            fi

        # 4. Analyze User Directories (/home)
        elif [[ "$d" == "/home" ]]; then
            if is_world_writable "$oct"; then
                if has_sticky_bit "$oct"; then
                    row "$d permissions" "Manual review recommended (World writable + sticky)" "warn"
                    increment_warn
                else
                    row "$d permissions" "Potential security issue detected (World writable)" "bad"
                    increment_error
                fi
            else
                row "$d permissions" "Secure configuration detected" "ok"
                increment_pass
            fi
        fi

        # 5. Global Catch-All: World-writable WITHOUT sticky bit is heavily penalized
        if [[ "$d" != "/tmp" && "$d" != "/var/tmp" ]]; then
             if is_world_writable "$oct" && ! has_sticky_bit "$oct"; then
                row "$d insecure sharing" "Potential security issue detected (No sticky bit)" "bad"
                increment_error
             fi
        fi
        
    done
}

# ------------------------------------------------------------------------------
# 7. SUMMARY
# ------------------------------------------------------------------------------
show_summary() {
    section "MODULE SUMMARY"
    
    value_row "Checks Performed" "$TOTAL_CHECKS"
    value_row "Passed" "${LGREEN}${PASSED_CHECKS}${NC}"
    value_row "Warnings" "${YELLOW}${WARNING_CHECKS}${NC}"
    value_row "Errors" "${LRED}${ERROR_CHECKS}${NC}"
    
    divider
    
    if [ "$ERROR_CHECKS" -gt 0 ]; then
        row "Security Status" "ATTENTION REQUIRED" "bad"
    elif [ "$WARNING_CHECKS" -gt 0 ]; then
        row "Security Status" "REVIEW RECOMMENDED" "warn"
    else
        row "Security Status" "GOOD" "ok"
    fi
    echo
}

# ------------------------------------------------------------------------------
# 8. MAIN EXECUTION
# ------------------------------------------------------------------------------
main() {
    collect_information
    display_information
    perform_security_checks
    show_summary
    return 0
}

main "$@"