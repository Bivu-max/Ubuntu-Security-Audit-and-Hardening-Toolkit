clear
#!/usr/bin/env bash
# ==============================================================================
# MODULE: SGID FILE SECURITY AUDIT
# Advanced Ubuntu Security Hardening & Audit Toolkit
# ==============================================================================
set -o pipefail

# ------------------------------------------------------------------------------
# 1. BOOTSTRAP & LIBRARY SOURCING
# ------------------------------------------------------------------------------
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"

if [ -f "$PROJECT_ROOT/lib/common.sh" ]; then
    source "$PROJECT_ROOT/lib/common.sh"
else
    echo -e "\033[1;31m[ERROR] Cannot find lib/common.sh at $PROJECT_ROOT/lib/common.sh\033[0m"
    exit 2
fi

# ------------------------------------------------------------------------------
# 2. GLOBAL AUDIT VARIABLES
# ------------------------------------------------------------------------------
TOTAL_CHECKS=0
PASSED_CHECKS=0
WARNING_CHECKS=0
ERROR_CHECKS=0

declare -a SGID_FILES
declare -A FILE_OWNER
declare -A FILE_GROUP
declare -A FILE_PERMS

# Common acceptable SGID binaries on standard Ubuntu systems
EXPECTED_SGID=(
    "/usr/bin/chage"
    "/usr/bin/wall"
    "/usr/bin/ssh-agent"
    "/usr/bin/dotlockfile"
    "/usr/bin/bsd-write"
    "/usr/bin/expiry"
    "/usr/bin/crontab"
    "/usr/sbin/postdrop"
    "/usr/sbin/postqueue"
    "/usr/sbin/pam_extrausers_chkpwd"
    "/sbin/unix_chkpwd"
    "/sbin/pam_extrausers_chkpwd"
    "/usr/lib/openssh/ssh-keysign"
)

# ------------------------------------------------------------------------------
# 3. HELPER FUNCTIONS FOR METRICS
# ------------------------------------------------------------------------------
increment_pass()  { ((TOTAL_CHECKS++)); ((PASSED_CHECKS++)); }
increment_warn()  { ((TOTAL_CHECKS++)); ((WARNING_CHECKS++)); }
increment_error() { ((TOTAL_CHECKS++)); ((ERROR_CHECKS++)); }

# Check if a file is in the expected list
is_expected_sgid() {
    local target="$1"
    local expected
    for expected in "${EXPECTED_SGID[@]}"; do
        if [ "$target" == "$expected" ]; then
            return 0
        fi
    done
    return 1
}

# ------------------------------------------------------------------------------
# 4. DATA COLLECTION
# ------------------------------------------------------------------------------
collect_information() {
    # Find all SGID files gracefully, ignoring unreadable locations (-xdev prevents traversing network shares)
    mapfile -t SGID_FILES < <(find / -xdev -type f -perm -2000 2>/dev/null)

    local file
    for file in "${SGID_FILES[@]}"; do
        if command_exists stat; then
            FILE_OWNER["$file"]=$(stat -c "%U" "$file" 2>/dev/null || echo "Unknown")
            FILE_GROUP["$file"]=$(stat -c "%G" "$file" 2>/dev/null || echo "Unknown")
            FILE_PERMS["$file"]=$(stat -c "%a" "$file" 2>/dev/null || echo "Unknown")
        else
            FILE_OWNER["$file"]="N/A"
            FILE_GROUP["$file"]="N/A"
            FILE_PERMS["$file"]="N/A"
        fi
    done
}

# ------------------------------------------------------------------------------
# 5. PRESENTATION
# ------------------------------------------------------------------------------
display_information() {
    module_header "SGID FILE SECURITY AUDIT" "3"
    
    section "DISCOVERED SGID FILES"
    
    local count=${#SGID_FILES[@]}
    value_row "Total SGID Files Found" "$count"
    
    if [ "$count" -eq 0 ]; then
        divider
        row "Scan Result" "No SGID files detected on this system" "info"
    else
        echo
        local file
        for file in "${SGID_FILES[@]}"; do
            local perms="${FILE_PERMS[$file]}"
            local owner="${FILE_OWNER[$file]}"
            local group="${FILE_GROUP[$file]}"
            echo -e "  ${WHITE}▶ ${file}${NC}"
            echo -e "    ${DIM}Perms:${NC} ${CYAN}${perms}${NC}  ${DIM}Owner:${NC} ${CYAN}${owner}${NC}  ${DIM}Group:${NC} ${CYAN}${group}${NC}"
        done
    fi
}

# ------------------------------------------------------------------------------
# 6. SECURITY ANALYSIS & CHECKS
# ------------------------------------------------------------------------------
perform_security_checks() {
    section "SECURITY ANALYSIS & AUDIT"
    
    local count=${#SGID_FILES[@]}
    if [ "$count" -eq 0 ]; then
        row "SGID Files" "None found (unusual but secure)" "ok"
        increment_pass
        return
    fi

    local file
    for file in "${SGID_FILES[@]}"; do
        local short_name
        short_name=$(basename "$file")

        if is_expected_sgid "$file"; then
            row "$short_name" "Expected SGID executable" "ok"
            increment_pass
            
        # Exception for valid binaries commonly installed via Snap
        elif [[ "$file" == /snap/* ]] && [[ "$short_name" =~ ^(ssh-agent|dotlockfile|wall)$ ]]; then
            row "$short_name (snap)" "Expected snap SGID executable" "ok"
            increment_pass
            
        else
            # Unknown SGID files shouldn't be auto-marked as malicious, just flagged for review
            row "$short_name" "Unusual SGID (Review recommended)" "warn"
            increment_warn
        fi
    done
    
    divider
    row "Information" "SGID executes with the group privileges of the file." "info"
    row "Recommendation" "Review 'warn' items to ensure they are legitimate." "info"
    row "Recommendation" "Remove SGID bit from unneeded binaries: chmod -s <file>" "info"
}

# ------------------------------------------------------------------------------
# 7. SUMMARY
# ------------------------------------------------------------------------------
show_summary() {
    section "MODULE SUMMARY"
    
    value_row "Checks Performed" "$TOTAL_CHECKS"
    value_row "Passed" "${LGREEN}${PASSED_CHECKS}${NC}"
    value_row "Warnings" "${YELLOW}${WARNING_CHECKS}${NC}"
    value_row "Errors" "${LRED}${ERROR_CHECKS}${NC}"
    
    divider
    
    if [ "$ERROR_CHECKS" -gt 0 ]; then
        row "Security Status" "ATTENTION REQUIRED" "bad"
    elif [ "$WARNING_CHECKS" -gt 0 ]; then
        row "Security Status" "REVIEW RECOMMENDED" "warn"
    else
        row "Security Status" "GOOD" "ok"
    fi
    echo
}

# ------------------------------------------------------------------------------
# 8. MAIN EXECUTION
# ------------------------------------------------------------------------------
main() {
    collect_information
    display_information
    perform_security_checks
    show_summary
    return 0
}

main "$@"