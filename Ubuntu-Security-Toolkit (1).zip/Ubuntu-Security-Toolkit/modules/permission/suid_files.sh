clear
#!/usr/bin/env bash
# ==============================================================================
# MODULE: SUID FILE SECURITY AUDIT
# Advanced Ubuntu Security Hardening & Audit Toolkit
# ==============================================================================
set -o pipefail

# ------------------------------------------------------------------------------
# 1. BOOTSTRAP & LIBRARY SOURCING
# ------------------------------------------------------------------------------
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"

if [ -f "$PROJECT_ROOT/lib/common.sh" ]; then
    source "$PROJECT_ROOT/lib/common.sh"
else
    echo -e "\033[1;31m[ERROR] Cannot find lib/common.sh at $PROJECT_ROOT/lib/common.sh\033[0m"
    exit 2
fi

# ------------------------------------------------------------------------------
# 2. GLOBAL AUDIT VARIABLES
# ------------------------------------------------------------------------------
TOTAL_CHECKS=0
PASSED_CHECKS=0
WARNING_CHECKS=0
ERROR_CHECKS=0

declare -a SUID_FILES
declare -A FILE_OWNER
declare -A FILE_PERMS

# Common acceptable SUID binaries on standard Ubuntu systems
EXPECTED_SUID=(
    "/bin/su" "/usr/bin/su"
    "/bin/mount" "/usr/bin/mount"
    "/bin/umount" "/usr/bin/umount"
    "/bin/ping" "/usr/bin/ping"
    "/usr/bin/passwd"
    "/usr/bin/chsh"
    "/usr/bin/chfn"
    "/usr/bin/gpasswd"
    "/usr/bin/newgrp"
    "/usr/bin/sudo"
    "/usr/bin/pkexec"
    "/usr/bin/at"
    "/usr/bin/crontab"
    "/usr/bin/arping"
    "/usr/bin/fusermount"
    "/usr/bin/fusermount3"
    "/usr/lib/openssh/ssh-keysign"
    "/usr/lib/dbus-1.0/dbus-daemon-launch-helper"
    "/usr/lib/policykit-1/polkit-agent-helper-1"
    "/usr/lib/eject/dmcrypt-get-device"
    "/usr/lib/xorg/Xorg.wrap"
    "/usr/sbin/pppd"
    "/usr/sbin/mount.nfs"
    "/usr/sbin/exim4"
)

# ------------------------------------------------------------------------------
# 3. HELPER FUNCTIONS FOR METRICS
# ------------------------------------------------------------------------------
increment_pass()  { ((TOTAL_CHECKS++)); ((PASSED_CHECKS++)); }
increment_warn()  { ((TOTAL_CHECKS++)); ((WARNING_CHECKS++)); }
increment_error() { ((TOTAL_CHECKS++)); ((ERROR_CHECKS++)); }

# Check if a file is in the expected list
is_expected_suid() {
    local target="$1"
    local expected
    for expected in "${EXPECTED_SUID[@]}"; do
        if [ "$target" == "$expected" ]; then
            return 0
        fi
    done
    return 1
}

# ------------------------------------------------------------------------------
# 4. DATA COLLECTION
# ------------------------------------------------------------------------------
collect_information() {
    # Find all SUID files gracefully, ignoring unreadable locations
    mapfile -t SUID_FILES < <(find / -xdev -type f -perm -4000 2>/dev/null)

    local file
    for file in "${SUID_FILES[@]}"; do
        if command_exists stat; then
            FILE_OWNER["$file"]=$(stat -c "%U" "$file" 2>/dev/null || echo "Unknown")
            FILE_PERMS["$file"]=$(stat -c "%a" "$file" 2>/dev/null || echo "Unknown")
        else
            FILE_OWNER["$file"]="N/A"
            FILE_PERMS["$file"]="N/A"
        fi
    done
}

# ------------------------------------------------------------------------------
# 5. PRESENTATION
# ------------------------------------------------------------------------------
display_information() {
    module_header "SUID FILE SECURITY AUDIT" "3"
    
    section "DISCOVERED SUID FILES"
    
    local count=${#SUID_FILES[@]}
    value_row "Total SUID Files Found" "$count"
    
    if [ "$count" -eq 0 ]; then
        divider
        row "Scan Result" "No SUID files detected on this system" "info"
    else
        echo
        local file
        for file in "${SUID_FILES[@]}"; do
            local perms="${FILE_PERMS[$file]}"
            local owner="${FILE_OWNER[$file]}"
            echo -e "  ${WHITE}▶ ${file}${NC}"
            echo -e "    ${DIM}Perms:${NC} ${CYAN}${perms}${NC}  ${DIM}Owner:${NC} ${CYAN}${owner}${NC}"
        done
    fi
}

# ------------------------------------------------------------------------------
# 6. SECURITY ANALYSIS & CHECKS
# ------------------------------------------------------------------------------
perform_security_checks() {
    section "SECURITY ANALYSIS & AUDIT"
    
    local count=${#SUID_FILES[@]}
    if [ "$count" -eq 0 ]; then
        row "SUID Files" "None found (unusual but secure)" "ok"
        increment_pass
        return
    fi

    local file
    for file in "${SUID_FILES[@]}"; do
        local short_name
        short_name=$(basename "$file")

        if is_expected_suid "$file"; then
            row "$short_name" "Expected SUID executable" "ok"
            increment_pass
            
        # Exception for valid binaries installed via Snap packaging
        elif [[ "$file" == /snap/* ]] && [[ "$short_name" =~ ^(sudo|su|passwd|mount|umount|ping)$ ]]; then
            row "$short_name (snap)" "Expected snap SUID executable" "ok"
            increment_pass
            
        else
            # Unknown SUID files shouldn't be auto-marked as malicious, just flagged for review
            row "$short_name" "Unusual SUID (Review recommended)" "warn"
            increment_warn
        fi
    done
    
    divider
    row "Recommendation" "Review 'warn' items to ensure they are legitimate." "info"
    row "Recommendation" "Remove SUID bit from unneeded binaries: chmod -s <file>" "info"
}

# ------------------------------------------------------------------------------
# 7. SUMMARY
# ------------------------------------------------------------------------------
show_summary() {
    section "MODULE SUMMARY"
    
    value_row "Checks Performed" "$TOTAL_CHECKS"
    value_row "Passed" "${LGREEN}${PASSED_CHECKS}${NC}"
    value_row "Warnings" "${YELLOW}${WARNING_CHECKS}${NC}"
    value_row "Errors" "${LRED}${ERROR_CHECKS}${NC}"
    
    divider
    
    if [ "$ERROR_CHECKS" -gt 0 ]; then
        row "Security Status" "ATTENTION REQUIRED" "bad"
    elif [ "$WARNING_CHECKS" -gt 0 ]; then
        row "Security Status" "REVIEW RECOMMENDED" "warn"
    else
        row "Security Status" "GOOD" "ok"
    fi
    echo
}

# ------------------------------------------------------------------------------
# 8. MAIN EXECUTION
# ------------------------------------------------------------------------------
main() {
    collect_information
    display_information
    perform_security_checks
    show_summary
    return 0
}

main "$@"