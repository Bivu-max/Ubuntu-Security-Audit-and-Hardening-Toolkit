clear
#!/usr/bin/env bash
# ==============================================================================
# MODULE: WORLD-WRITABLE SECURITY AUDIT
# Advanced Ubuntu Security Hardening & Audit Toolkit
# ==============================================================================
set -o pipefail

# ------------------------------------------------------------------------------
# 1. BOOTSTRAP & LIBRARY SOURCING
# ------------------------------------------------------------------------------
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"

if [ -f "$PROJECT_ROOT/lib/common.sh" ]; then
    source "$PROJECT_ROOT/lib/common.sh"
else
    echo -e "\033[1;31m[ERROR] Cannot find lib/common.sh at $PROJECT_ROOT/lib/common.sh\033[0m"
    exit 2
fi

# ------------------------------------------------------------------------------
# 2. GLOBAL AUDIT VARIABLES
# ------------------------------------------------------------------------------
TOTAL_CHECKS=0
PASSED_CHECKS=0
WARNING_CHECKS=0
ERROR_CHECKS=0

declare -a WW_DIRS
declare -a WW_FILES

declare -A FILE_OWNER
declare -A FILE_GROUP
declare -A FILE_PERMS
declare -A DIR_PERMS

# ------------------------------------------------------------------------------
# 3. HELPER FUNCTIONS FOR METRICS
# ------------------------------------------------------------------------------
increment_pass()  { ((TOTAL_CHECKS++)); ((PASSED_CHECKS++)); }
increment_warn()  { ((TOTAL_CHECKS++)); ((WARNING_CHECKS++)); }
increment_error() { ((TOTAL_CHECKS++)); ((ERROR_CHECKS++)); }

# Check if an octal permission has the sticky bit set (4 chars, first is 1, 3, 5, 7)
has_sticky_bit() {
    local oct="$1"
    if [ ${#oct} -eq 4 ]; then
        local first_digit="${oct:0:1}"
        [[ "$first_digit" =~ [1357] ]]
    else
        return 1
    fi
}

# ------------------------------------------------------------------------------
# 4. DATA COLLECTION
# ------------------------------------------------------------------------------
collect_information() {
    # Find world-writable directories, excluding dynamic/virtual filesystems
    mapfile -t WW_DIRS < <(find / \( -path /proc -o -path /sys -o -path /dev -o -path /run \) -prune -o -type d -perm -0002 -print 2>/dev/null)
    
    # Find world-writable files, excluding dynamic/virtual filesystems
    mapfile -t WW_FILES < <(find / \( -path /proc -o -path /sys -o -path /dev -o -path /run \) -prune -o -type f -perm -0002 -print 2>/dev/null)

    local item
    
    # Collect stat info for directories
    for item in "${WW_DIRS[@]}"; do
        if command_exists stat; then
            DIR_PERMS["$item"]=$(stat -c "%a" "$item" 2>/dev/null || echo "N/A")
        else
            DIR_PERMS["$item"]="N/A"
        fi
    done

    # Collect stat info for files
    for item in "${WW_FILES[@]}"; do
        if command_exists stat; then
            FILE_OWNER["$item"]=$(stat -c "%U" "$item" 2>/dev/null || echo "Unknown")
            FILE_GROUP["$item"]=$(stat -c "%G" "$item" 2>/dev/null || echo "Unknown")
            FILE_PERMS["$item"]=$(stat -c "%a" "$item" 2>/dev/null || echo "N/A")
        else
            FILE_OWNER["$item"]="N/A"
            FILE_GROUP["$item"]="N/A"
            FILE_PERMS["$item"]="N/A"
        fi
    done
}

# ------------------------------------------------------------------------------
# 5. PRESENTATION
# ------------------------------------------------------------------------------
display_information() {
    module_header "WORLD-WRITABLE SECURITY AUDIT" "3"
    
    section "DISCOVERED WORLD-WRITABLE DIRECTORIES"
    local dir_count=${#WW_DIRS[@]}
    value_row "Total Directories Found" "$dir_count"
    
    if [ "$dir_count" -gt 0 ]; then
        echo
        local d
        for d in "${WW_DIRS[@]}"; do
            local perms="${DIR_PERMS[$d]}"
            echo -e "  ${WHITE}▶ ${d}${NC} ${DIM}(Perms: ${perms})${NC}"
        done
    fi

    section "DISCOVERED WORLD-WRITABLE FILES"
    local file_count=${#WW_FILES[@]}
    value_row "Total Files Found" "$file_count"
    
    if [ "$file_count" -gt 0 ]; then
        echo
        local f
        for f in "${WW_FILES[@]}"; do
            local perms="${FILE_PERMS[$f]}"
            local owner="${FILE_OWNER[$f]}"
            local group="${FILE_GROUP[$f]}"
            echo -e "  ${WHITE}▶ ${f}${NC}"
            echo -e "    ${DIM}Perms:${NC} ${CYAN}${perms}${NC}  ${DIM}Owner:${NC} ${CYAN}${owner}${NC}  ${DIM}Group:${NC} ${CYAN}${group}${NC}"
        done
    fi
}

# ------------------------------------------------------------------------------
# 6. SECURITY ANALYSIS & CHECKS
# ------------------------------------------------------------------------------
perform_security_checks() {
    section "SECURITY ANALYSIS & AUDIT"
    
    # 1. Directory Analysis
    subsection "Directory Configuration Check"
    if [ ${#WW_DIRS[@]} -eq 0 ]; then
        row "World-Writable Dirs" "None found (Highly secure)" "ok"
        increment_pass
    else
        local d
        for d in "${WW_DIRS[@]}"; do
            local perms="${DIR_PERMS[$d]}"
            if has_sticky_bit "$perms"; then
                if [[ "$d" == "/tmp" || "$d" == "/var/tmp" || "$d" == "/dev/shm" ]]; then
                    row "$d" "Secure configuration detected (Sticky bit)" "ok"
                    increment_pass
                else
                    row "$d" "Sticky bit enabled (Legitimate?)" "info"
                    increment_warn
                fi
            else
                row "$d" "Potential security issue detected (No sticky bit)" "bad"
                increment_error
            fi
        done
    fi

    # 2. File Analysis
    subsection "File Configuration Check"
    if [ ${#WW_FILES[@]} -eq 0 ]; then
        row "World-Writable Files" "None found" "ok"
        increment_pass
    else
        local f
        for f in "${WW_FILES[@]}"; do
            # Any world-writable file outside of specific intended contexts is suspicious
            if [[ "$f" == /etc/* || "$f" == /boot/* || "$f" == /root/* || "$f" == /usr/* ]]; then
                row "Sensitive: $(basename "$f")" "Potential security issue detected" "bad"
                increment_error
            else
                row "$(basename "$f")" "Manual review recommended" "warn"
                increment_warn
            fi
        done
    fi
    
    divider
    row "Recommendation" "Ensure WW dirs have sticky bit: chmod +t <dir>" "info"
    row "Recommendation" "Remove WW perms from sensitive files: chmod o-w <file>" "info"
}

# ------------------------------------------------------------------------------
# 7. SUMMARY
# ------------------------------------------------------------------------------
show_summary() {
    section "MODULE SUMMARY"
    
    value_row "Checks Performed" "$TOTAL_CHECKS"
    value_row "Passed" "${LGREEN}${PASSED_CHECKS}${NC}"
    value_row "Warnings" "${YELLOW}${WARNING_CHECKS}${NC}"
    value_row "Errors" "${LRED}${ERROR_CHECKS}${NC}"
    
    divider
    
    if [ "$ERROR_CHECKS" -gt 0 ]; then
        row "Security Status" "ATTENTION REQUIRED" "bad"
    elif [ "$WARNING_CHECKS" -gt 0 ]; then
        row "Security Status" "REVIEW RECOMMENDED" "warn"
    else
        row "Security Status" "GOOD" "ok"
    fi
    echo
}

# ------------------------------------------------------------------------------
# 8. MAIN EXECUTION
# ------------------------------------------------------------------------------
main() {
    collect_information
    display_information
    perform_security_checks
    show_summary
    return 0
}

main "$@"