#!/bin/bash

# ==========================================
# UBUNTU FILE PERMISSION SECURITY AUDIT
# ==========================================

PROJECT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"

source "$PROJECT_ROOT/lib/common.sh"

echo "=========================================="
echo "     FILE PERMISSION SECURITY AUDIT"
echo "=========================================="

# Important system files to check
FILES=(
    "/etc/passwd"
    "/etc/shadow"
    "/etc/group"
    "/etc/gshadow"
    "/etc/sudoers"
)

# Check each file
for FILE in "${FILES[@]}"

do
    echo ""
    echo "Checking: $FILE"

    # Check file existence
    if [ ! -f "$FILE" ]; then
        error "$FILE does not exist"
        continue
    fi

    pass "$FILE exists"

    # Check file owner
    OWNER=$(stat -c "%U" "$FILE")

    if [ "$OWNER" = "root" ]; then
        pass "$FILE is owned by root"
    else
        warning "$FILE is not owned by root"
    fi

    # Get file permissions
    MODE=$(stat -c "%a" "$FILE")

    echo "Current Permission: $MODE"

    # Convert permissions to octal
    PERMISSION=$((8#$MODE))

    # Check group and other write permissions
    if (( PERMISSION & 0022 )); then
        warning "$FILE is writable by group or others"
    else
        pass "$FILE is not writable by group or others"
    fi

    # Extra protection for sensitive files
    if [[ "$FILE" == "/etc/shadow" || "$FILE" == "/etc/gshadow" ]]; then

        if (( PERMISSION & 0044 )); then
            warning "$FILE is readable by group or others"
        else
            pass "$FILE is protected from group and other reading"
        fi

    fi

done

# Display final summary
echo ""
print_summary

echo ""
echo "=========================================="
echo " FILE PERMISSION AUDIT COMPLETED"
echo "=========================================="
