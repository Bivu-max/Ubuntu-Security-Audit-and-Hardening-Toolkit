clear
#!/usr/bin/env bash
# ==============================================================================
# MODULE: ACCESS CONTROL LIST (ACL) SECURITY AUDIT
# Advanced Ubuntu Security Hardening & Audit Toolkit
# ==============================================================================
set -o pipefail

# ------------------------------------------------------------------------------
# 1. BOOTSTRAP & LIBRARY SOURCING
# ------------------------------------------------------------------------------
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"

if [ -f "$PROJECT_ROOT/lib/common.sh" ]; then
    source "$PROJECT_ROOT/lib/common.sh"
else
    echo -e "\033[1;31m[ERROR] Cannot find lib/common.sh at $PROJECT_ROOT/lib/common.sh\033[0m"
    exit 2
fi

# ------------------------------------------------------------------------------
# 2. GLOBAL AUDIT VARIABLES
# ------------------------------------------------------------------------------
TOTAL_CHECKS=0
PASSED_CHECKS=0
WARNING_CHECKS=0
ERROR_CHECKS=0

TARGET_DIRS=(
    "/etc"
    "/home"
    "/var/log"
)

HAS_GETFACL=0

declare -A DIR_EXISTS
declare -A DIR_HAS_EXT_ACL
declare -A DIR_HAS_NAMED_USER
declare -A DIR_HAS_NAMED_GROUP
declare -A DIR_HAS_DEFAULT
declare -A DIR_STANDARD_ONLY

# ------------------------------------------------------------------------------
# 3. HELPER FUNCTIONS FOR METRICS
# ------------------------------------------------------------------------------
increment_pass()  { ((TOTAL_CHECKS++)); ((PASSED_CHECKS++)); }
increment_warn()  { ((TOTAL_CHECKS++)); ((WARNING_CHECKS++)); }
increment_error() { ((TOTAL_CHECKS++)); ((ERROR_CHECKS++)); }

# ------------------------------------------------------------------------------
# 4. DATA COLLECTION
# ------------------------------------------------------------------------------
collect_information() {
    # Check if getfacl is installed before attempting to use it
    if command_exists getfacl; then
        HAS_GETFACL=1
    else
        HAS_GETFACL=0
    fi

    local d
    for d in "${TARGET_DIRS[@]}"; do
        if directory_exists "$d"; then
            DIR_EXISTS["$d"]=1
            
            if [ "$HAS_GETFACL" -eq 1 ]; then
                DIR_HAS_EXT_ACL["$d"]=0
                DIR_HAS_NAMED_USER["$d"]=0
                DIR_HAS_NAMED_GROUP["$d"]=0
                DIR_HAS_DEFAULT["$d"]=0
                DIR_STANDARD_ONLY["$d"]=1
                
                # Analyze the directory itself for extended entries
                local acl_out
                acl_out=$(getfacl "$d" 2>/dev/null)
                
                # Identify extended named user ACL entries (user:name:perms)
                if echo "$acl_out" | grep -q "^user:[^:]\+:"; then 
                    DIR_HAS_NAMED_USER["$d"]=1
                    DIR_HAS_EXT_ACL["$d"]=1
                    DIR_STANDARD_ONLY["$d"]=0
                fi
                
                # Identify extended named group ACL entries (group:name:perms)
                if echo "$acl_out" | grep -q "^group:[^:]\+:"; then 
                    DIR_HAS_NAMED_GROUP["$d"]=1
                    DIR_HAS_EXT_ACL["$d"]=1
                    DIR_STANDARD_ONLY["$d"]=0
                fi
                
                # Identify default ACL entries (default:...)
                if echo "$acl_out" | grep -q "^default:"; then 
                    DIR_HAS_DEFAULT["$d"]=1
                    DIR_HAS_EXT_ACL["$d"]=1
                    DIR_STANDARD_ONLY["$d"]=0
                fi
                
                # Superficial scan to detect if immediate contents have extended ACLs
                if find "$d" -xdev -maxdepth 2 -exec getfacl -s {} + 2>/dev/null | grep -q "^# file:"; then
                    DIR_HAS_EXT_ACL["$d"]=1
                    DIR_STANDARD_ONLY["$d"]=0
                fi
            fi
        else
            DIR_EXISTS["$d"]=0
        fi
    done
}

# ------------------------------------------------------------------------------
# 5. PRESENTATION
# ------------------------------------------------------------------------------
display_information() {
    module_header "ACCESS CONTROL LIST (ACL) SECURITY AUDIT" "3"
    
    section "ACL TOOL AVAILABILITY"
    if [ "$HAS_GETFACL" -eq 1 ]; then
        row "getfacl command" "Installed and available" "ok"
    else
        row "getfacl command" "Not installed (Skipping analysis)" "warn"
    fi
    
    if [ "$HAS_GETFACL" -eq 1 ]; then
        section "ACL CONFIGURATION DISCOVERY"
        
        local d
        for d in "${TARGET_DIRS[@]}"; do
            subsection "$d"
            if [ "${DIR_EXISTS[$d]}" -eq 1 ]; then
                if [ "${DIR_HAS_EXT_ACL[$d]}" -eq 1 ]; then
                    value_row "Standard Permissions" "Yes (user::, group::, other::)"
                    value_row "Extended ACLs Present" "Yes"
                    
                    [ "${DIR_HAS_NAMED_USER[$d]}" -eq 1 ] && value_row "Named User Entries" "Detected"
                    [ "${DIR_HAS_NAMED_GROUP[$d]}" -eq 1 ] && value_row "Named Group Entries" "Detected"
                    [ "${DIR_HAS_DEFAULT[$d]}" -eq 1 ] && value_row "Default ACL Entries" "Detected"
                else
                    value_row "Standard Permissions" "Yes"
                    value_row "Extended ACLs Present" "No"
                fi
            else
                row "Directory Status" "Directory does not exist" "warn"
            fi
        done
    fi
}

# ------------------------------------------------------------------------------
# 6. SECURITY ANALYSIS & CHECKS
# ------------------------------------------------------------------------------
perform_security_checks() {
    section "SECURITY ANALYSIS & AUDIT"
    
    if [ "$HAS_GETFACL" -eq 0 ]; then
        row "ACL Audit" "Cannot perform audit without getfacl" "warn"
        increment_warn
        row "Recommendation" "Install 'acl' package to enable auditing." "info"
        return
    fi
    
    local d
    for d in "${TARGET_DIRS[@]}"; do
        if [ "${DIR_EXISTS[$d]}" -eq 1 ]; then
            if [ "${DIR_STANDARD_ONLY[$d]}" -eq 1 ]; then
                row "$d ACLs" "Secure configuration detected (Standard only)" "ok"
                increment_pass
            else
                row "$d Extended ACLs" "Manual review recommended" "warn"
                increment_warn
                
                # Flag specific extended ACL types that could allow unexpected access
                if [ "${DIR_HAS_NAMED_USER[$d]}" -eq 1 ]; then
                    row "$d Named Users" "Manual review recommended" "warn"
                    increment_warn
                fi
                if [ "${DIR_HAS_NAMED_GROUP[$d]}" -eq 1 ]; then
                    row "$d Named Groups" "Manual review recommended" "warn"
                    increment_warn
                fi
                if [ "${DIR_HAS_DEFAULT[$d]}" -eq 1 ]; then
                    row "$d Default ACLs" "Manual review recommended (Inheritance)" "warn"
                    increment_warn
                fi
            fi
        fi
    done
    
    divider
    row "Information" "ACL configurations may be legitimate depending on system config." "info"
    row "Information" "We do not automatically classify extended ACLs as malicious." "info"
    row "Recommendation" "Use 'getfacl <path>' to review unexpected permissions." "info"
    row "Recommendation" "Use 'setfacl -b <path>' to safely remove unwanted ACLs." "info"
}

# ------------------------------------------------------------------------------
# 7. SUMMARY
# ------------------------------------------------------------------------------
show_summary() {
    section "MODULE SUMMARY"
    
    value_row "Checks Performed" "$TOTAL_CHECKS"
    value_row "Passed" "${LGREEN}${PASSED_CHECKS}${NC}"
    value_row "Warnings" "${YELLOW}${WARNING_CHECKS}${NC}"
    value_row "Errors" "${LRED}${ERROR_CHECKS}${NC}"
    
    divider
    
    if [ "$ERROR_CHECKS" -gt 0 ]; then
        row "Security Status" "ATTENTION REQUIRED" "bad"
    elif [ "$WARNING_CHECKS" -gt 0 ]; then
        row "Security Status" "REVIEW RECOMMENDED" "warn"
    else
        row "Security Status" "GOOD" "ok"
    fi
    echo
}

# ------------------------------------------------------------------------------
# 8. MAIN EXECUTION
# ------------------------------------------------------------------------------
main() {
    collect_information
    display_information
    perform_security_checks
    show_summary
    return 0
}

main "$@"