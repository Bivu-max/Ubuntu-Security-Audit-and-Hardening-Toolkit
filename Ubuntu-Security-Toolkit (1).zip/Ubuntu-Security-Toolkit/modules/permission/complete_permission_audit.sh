clear
#!/usr/bin/env bash
# ==============================================================================
# MODULE: COMPLETE PERMISSION SECURITY AUDIT
# Advanced Ubuntu Security Hardening & Audit Toolkit
# ==============================================================================
set -o pipefail

# ------------------------------------------------------------------------------
# 1. BOOTSTRAP & LIBRARY SOURCING
# ------------------------------------------------------------------------------
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"

if [ -f "$PROJECT_ROOT/lib/common.sh" ]; then
    source "$PROJECT_ROOT/lib/common.sh"
else
    echo -e "\033[1;31m[ERROR] Cannot find lib/common.sh at $PROJECT_ROOT/lib/common.sh\033[0m"
    exit 2
fi

# ------------------------------------------------------------------------------
# 2. GLOBAL AUDIT VARIABLES
# ------------------------------------------------------------------------------
TOTAL_CHECKS=0
PASSED_CHECKS=0
WARNING_CHECKS=0
ERROR_CHECKS=0

TARGET_SCRIPTS=(
    "file_permissions.sh"
    "directory_permissions.sh"
    "suid_files.sh"
    "sgid_files.sh"
    "special_permissions.sh"
    "world_writable.sh"
    "acl_audit.sh"
)

declare -A SCRIPT_EXISTS
declare -A SCRIPT_EXECUTABLE
declare -A SCRIPT_EXIT_CODE

# ------------------------------------------------------------------------------
# 3. HELPER FUNCTIONS FOR METRICS
# ------------------------------------------------------------------------------
increment_pass()  { ((TOTAL_CHECKS++)); ((PASSED_CHECKS++)); }
increment_warn()  { ((TOTAL_CHECKS++)); ((WARNING_CHECKS++)); }
increment_error() { ((TOTAL_CHECKS++)); ((ERROR_CHECKS++)); }

# ------------------------------------------------------------------------------
# 4. DATA COLLECTION
# ------------------------------------------------------------------------------
collect_information() {
    local script_name
    for script_name in "${TARGET_SCRIPTS[@]}"; do
        local full_path="$SCRIPT_DIR/$script_name"
        
        if file_exists "$full_path"; then
            SCRIPT_EXISTS["$script_name"]=1
            
            # Check if the file has execute permissions
            if [ -x "$full_path" ]; then
                SCRIPT_EXECUTABLE["$script_name"]=1
            else
                SCRIPT_EXECUTABLE["$script_name"]=0
            fi
        else
            SCRIPT_EXISTS["$script_name"]=0
            SCRIPT_EXECUTABLE["$script_name"]=0
        fi
        
        # Initialize exit code tracker
        SCRIPT_EXIT_CODE["$script_name"]=-1
    done
}

# ------------------------------------------------------------------------------
# 5. PRESENTATION
# ------------------------------------------------------------------------------
display_information() {
    module_header "COMPLETE PERMISSION SECURITY AUDIT" "3"
    
    section "AUDIT MODULES INVENTORY"
    
    local script_name
    for script_name in "${TARGET_SCRIPTS[@]}"; do
        if [ "${SCRIPT_EXISTS[$script_name]}" -eq 1 ]; then
            if [ "${SCRIPT_EXECUTABLE[$script_name]}" -eq 1 ]; then
                row "$script_name" "Ready for execution" "ok"
            else
                row "$script_name" "Exists but not executable" "warn"
            fi
        else
            row "$script_name" "Module script missing" "bad"
        fi
    done
}

# ------------------------------------------------------------------------------
# 6. SECURITY ANALYSIS & CHECKS
# ------------------------------------------------------------------------------
perform_security_checks() {
    local script_name
    
    for script_name in "${TARGET_SCRIPTS[@]}"; do
        
        if [ "${SCRIPT_EXECUTABLE[$script_name]}" -eq 1 ]; then
            echo
            divider
            echo -e "  ${LCYAN}${BOLD}▶ EXECUTING MODULE: ${script_name}${NC}"
            divider
            
            # Execute the target script directly (sudo is assumed at master level)
            "$SCRIPT_DIR/$script_name"
            local exit_code=$?
            
            SCRIPT_EXIT_CODE["$script_name"]=$exit_code
            
            if [ "$exit_code" -eq 0 ]; then
                increment_pass
            else
                increment_error
            fi
            
        else
            # If the script is missing, it's an error. If it exists but isn't executable, it's a warning.
            if [ "${SCRIPT_EXISTS[$script_name]}" -eq 0 ]; then
                increment_error
            else
                increment_warn
            fi
        fi
    done
    
    # Final rollup presentation for the Master Controller
    module_header "PERMISSION AUDIT RESULTS" "3"
    section "MASTER EXECUTION RESULTS"
    
    for script_name in "${TARGET_SCRIPTS[@]}"; do
        if [ "${SCRIPT_EXECUTABLE[$script_name]}" -eq 1 ]; then
            if [ "${SCRIPT_EXIT_CODE[$script_name]}" -eq 0 ]; then
                row "$script_name execution" "Completed successfully" "ok"
            else
                row "$script_name execution" "Failed (Exit code: ${SCRIPT_EXIT_CODE[$script_name]})" "bad"
            fi
        else
            if [ "${SCRIPT_EXISTS[$script_name]}" -eq 0 ]; then
                row "$script_name execution" "Skipped (File missing)" "bad"
            else
                row "$script_name execution" "Skipped (Not executable)" "warn"
            fi
        fi
    done
}

# ------------------------------------------------------------------------------
# 7. SUMMARY
# ------------------------------------------------------------------------------
show_summary() {
    section "OVERALL MODULE SUMMARY"
    
    value_row "Total Audits Attempted" "$TOTAL_CHECKS"
    value_row "Successful Audits" "${LGREEN}${PASSED_CHECKS}${NC}"
    value_row "Warnings / Skipped" "${YELLOW}${WARNING_CHECKS}${NC}"
    value_row "Failed Audits" "${LRED}${ERROR_CHECKS}${NC}"
    
    divider
    
    if [ "$ERROR_CHECKS" -gt 0 ]; then
        row "Overall Module Status" "ATTENTION REQUIRED" "bad"
    elif [ "$WARNING_CHECKS" -gt 0 ]; then
        row "Overall Module Status" "REVIEW RECOMMENDED" "warn"
    else
        row "Overall Module Status" "GOOD (All Scripts Passed)" "ok"
    fi
    echo
}

# ------------------------------------------------------------------------------
# 8. MAIN EXECUTION
# ------------------------------------------------------------------------------
main() {
    # 1. Collect information
    collect_information
    
    # 2. Display collected information
    display_information
    
    # 3. Perform security analysis
    perform_security_checks
    
    # 4. Display audit summary
    show_summary
    
    return 0
}

main "$@"