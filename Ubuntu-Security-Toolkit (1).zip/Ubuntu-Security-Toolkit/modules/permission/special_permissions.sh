clear
#!/usr/bin/env bash
# ==============================================================================
# MODULE: SPECIAL PERMISSIONS SECURITY AUDIT
# Advanced Ubuntu Security Hardening & Audit Toolkit
# ==============================================================================
set -o pipefail

# ------------------------------------------------------------------------------
# 1. BOOTSTRAP & LIBRARY SOURCING
# ------------------------------------------------------------------------------
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"

if [ -f "$PROJECT_ROOT/lib/common.sh" ]; then
    source "$PROJECT_ROOT/lib/common.sh"
else
    echo -e "\033[1;31m[ERROR] Cannot find lib/common.sh at $PROJECT_ROOT/lib/common.sh\033[0m"
    exit 2
fi

# ------------------------------------------------------------------------------
# 2. GLOBAL AUDIT VARIABLES
# ------------------------------------------------------------------------------
TOTAL_CHECKS=0
PASSED_CHECKS=0
WARNING_CHECKS=0
ERROR_CHECKS=0

TARGET_DIRS=(
    "/tmp"
    "/var/tmp"
)

declare -A DIR_EXISTS
declare -A DIR_OCT
declare -A DIR_SYM

# ------------------------------------------------------------------------------
# 3. HELPER FUNCTIONS FOR METRICS
# ------------------------------------------------------------------------------
increment_pass()  { ((TOTAL_CHECKS++)); ((PASSED_CHECKS++)); }
increment_warn()  { ((TOTAL_CHECKS++)); ((WARNING_CHECKS++)); }
increment_error() { ((TOTAL_CHECKS++)); ((ERROR_CHECKS++)); }

# Check if an octal permission grants world-write (last digit 2, 3, 6, 7)
is_world_writable() {
    local oct="$1"
    local last_digit="${oct: -1}"
    [[ "$last_digit" =~ [2367] ]]
}

# Check if an octal permission has the sticky bit set (4 chars, first is 1, 3, 5, 7)
has_sticky_bit() {
    local oct="$1"
    if [ ${#oct} -eq 4 ]; then
        local first_digit="${oct:0:1}"
        [[ "$first_digit" =~ [1357] ]]
    else
        return 1
    fi
}

# ------------------------------------------------------------------------------
# 4. DATA COLLECTION
# ------------------------------------------------------------------------------
collect_information() {
    local d
    for d in "${TARGET_DIRS[@]}"; do
        if directory_exists "$d"; then
            DIR_EXISTS[$d]=1
            if command_exists stat; then
                DIR_OCT[$d]=$(stat -c "%a" "$d" 2>/dev/null || echo "N/A")
                DIR_SYM[$d]=$(stat -c "%A" "$d" 2>/dev/null || echo "N/A")
            else
                DIR_OCT[$d]="N/A"
                DIR_SYM[$d]="N/A"
            fi
        else
            DIR_EXISTS[$d]=0
            DIR_OCT[$d]="N/A"
            DIR_SYM[$d]="N/A"
        fi
    done
}

# ------------------------------------------------------------------------------
# 5. PRESENTATION
# ------------------------------------------------------------------------------
display_information() {
    module_header "SPECIAL PERMISSIONS SECURITY AUDIT" "3"
    
    section "SPECIAL PERMISSIONS OVERVIEW"
    row "SUID (Set User ID)" "Executes with the file owner's privileges." "info"
    row "SGID (Set Group ID)" "Executes with the group's privileges/inherits dir group." "info"
    row "Sticky Bit" "Prevents users from deleting files they don't own." "info"
    
    section "SHARED DIRECTORIES INVENTORY"
    
    local d
    for d in "${TARGET_DIRS[@]}"; do
        subsection "$d"
        if [ "${DIR_EXISTS[$d]}" -eq 1 ]; then
            value_row "Numeric Permissions" "$(safe_value "${DIR_OCT[$d]}")"
            value_row "Symbolic Permissions" "$(safe_value "${DIR_SYM[$d]}")"
        else
            row "Directory Status" "Directory does not exist" "warn"
        fi
    done
}

# ------------------------------------------------------------------------------
# 6. SECURITY ANALYSIS & CHECKS
# ------------------------------------------------------------------------------
perform_security_checks() {
    section "SECURITY ANALYSIS & AUDIT"
    
    local d
    for d in "${TARGET_DIRS[@]}"; do
        
        # 1. Directory Existence Check
        if [ "${DIR_EXISTS[$d]}" -eq 1 ]; then
            row "$d existence" "Directory present" "ok"
            increment_pass
        else
            row "$d existence" "Critical shared directory missing" "bad"
            increment_error
            continue
        fi

        local oct="${DIR_OCT[$d]}"
        
        # 2. Sticky Bit & World-Writable Analysis
        if is_world_writable "$oct"; then
            if has_sticky_bit "$oct"; then
                row "$d sticky bit" "Secure configuration detected (Protected)" "ok"
                increment_pass
            else
                row "$d sticky bit" "Potential security issue detected (Missing)" "bad"
                increment_error
            fi
        else
            # Not world-writable (unusual for /tmp and /var/tmp, but secure from an access perspective)
            row "$d permissions" "Manual review recommended (Not world-writable)" "warn"
            increment_warn
        fi
    done
    
    divider
    row "Recommendation" "Ensure shared directories like /tmp have 1777 permissions." "info"
    row "Remediation" "Use 'chmod +t <dir>' to enable sticky bit protection." "info"
}

# ------------------------------------------------------------------------------
# 7. SUMMARY
# ------------------------------------------------------------------------------
show_summary() {
    section "MODULE SUMMARY"
    
    value_row "Checks Performed" "$TOTAL_CHECKS"
    value_row "Passed" "${LGREEN}${PASSED_CHECKS}${NC}"
    value_row "Warnings" "${YELLOW}${WARNING_CHECKS}${NC}"
    value_row "Errors" "${LRED}${ERROR_CHECKS}${NC}"
    
    divider
    
    if [ "$ERROR_CHECKS" -gt 0 ]; then
        row "Security Status" "ATTENTION REQUIRED" "bad"
    elif [ "$WARNING_CHECKS" -gt 0 ]; then
        row "Security Status" "REVIEW RECOMMENDED" "warn"
    else
        row "Security Status" "GOOD" "ok"
    fi
    echo
}

# ------------------------------------------------------------------------------
# 8. MAIN EXECUTION
# ------------------------------------------------------------------------------
main() {
    collect_information
    display_information
    perform_security_checks
    show_summary
    return 0
}

main "$@"