
#!/usr/bin/env bash

# ==========================================
# UBUNTU SECURITY TOOLKIT
# BACKUP AND RECOVERY MODULE
# ==========================================

PROJECT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"

source "$PROJECT_ROOT/lib/common.sh"

BACKUP_DIR="$PROJECT_ROOT/backups"
TIMESTAMP=$(date +"%Y%m%d_%H%M%S")
BACKUP_FILE="$BACKUP_DIR/system_config_backup_$TIMESTAMP.tar.gz"

echo "=========================================="
echo "       BACKUP AND RECOVERY MODULE"
echo "=========================================="

# 1. Check required commands

echo ""
echo "1. Checking backup utilities"

if ! command -v tar >/dev/null 2>&1; then
    error "tar utility is not installed"
    print_summary
    exit 1
fi

if ! command -v gzip >/dev/null 2>&1; then
    error "gzip utility is not installed"
    print_summary
    exit 1
fi

pass "tar and gzip utilities are available"

# 2. Check backup directory

echo ""
echo "2. Checking backup directory"

if [ ! -d "$BACKUP_DIR" ]; then
    mkdir -p "$BACKUP_DIR"
fi

if [ -d "$BACKUP_DIR" ] && [ -w "$BACKUP_DIR" ]; then
    pass "Backup directory is available"
else
    error "Backup directory is unavailable or not writable"
    print_summary
    exit 1
fi

# 3. Request administrator authentication

echo ""
echo "3. Checking administrator access"

if sudo -v; then
    pass "Administrator access is available"
else
    error "Administrator authentication failed"
    print_summary
    exit 1
fi

# 4. Select important configuration files

echo ""
echo "4. Selecting system configuration files"

BACKUP_ITEMS=()

for ITEM in \
    etc/passwd \
    etc/group \
    etc/login.defs \
    etc/sudoers \
    etc/apt/sources.list \
    etc/apt/sources.list.d \
    etc/ssh/sshd_config \
    etc/ufw
do
    if [ -e "/$ITEM" ]; then
        BACKUP_ITEMS+=("$ITEM")
        echo "[+] Selected: /$ITEM"
    else
        echo "[!] Not available: /$ITEM"
    fi
done

if [ "${#BACKUP_ITEMS[@]}" -eq 0 ]; then
    error "No configuration files found for backup"
    print_summary
    exit 1
fi

pass "Configuration files selected"

# 5. Create compressed backup

echo ""
echo "5. Creating compressed backup"

umask 077

if [ -e "$BACKUP_FILE" ]; then
    error "Backup filename already exists"
    print_summary
    exit 1
fi

# Create an empty file owned by the current user.
# Administrator privileges are used only to read protected files.

if ! touch "$BACKUP_FILE"; then
    error "Unable to create backup archive"
    print_summary
    exit 1
fi

chmod 600 "$BACKUP_FILE"

if sudo tar -czf "$BACKUP_FILE" -C / "${BACKUP_ITEMS[@]}"; then
    pass "Compressed backup created successfully"
else
    rm -f "$BACKUP_FILE"
    error "Backup creation failed"
    print_summary
    exit 1
fi

# 6. Verify backup archive

echo ""
echo "6. Verifying backup archive"

if gzip -t "$BACKUP_FILE" && tar -tzf "$BACKUP_FILE" >/dev/null; then
    pass "Backup archive verification successful"
else
    rm -f "$BACKUP_FILE"
    error "Backup archive verification failed"
    print_summary
    exit 1
fi

# 7. Check backup permissions

echo ""
echo "7. Checking backup file permissions"

chmod 600 "$BACKUP_FILE"

OWNER=$(stat -c "%U" "$BACKUP_FILE")
PERMISSIONS=$(stat -c "%a" "$BACKUP_FILE")

if [ "$OWNER" = "$(id -un)" ] && [ "$PERMISSIONS" = "600" ]; then
    pass "Backup file ownership and permissions are secure"
else
    warning "Review backup file ownership or permissions"
fi

# 8. Display backup information

echo ""
echo "8. Backup information"

echo "Backup file : $BACKUP_FILE"
echo "File size   : $(du -h "$BACKUP_FILE" | cut -f1)"
echo "Permissions : $PERMISSIONS"

# 9. Display backup summary

echo ""
print_summary

echo ""
echo "=========================================="
echo " BACKUP MODULE COMPLETED"
echo "=========================================="
