
#!/bin/bash

# ==========================================
# UBUNTU SSH SECURITY AUDIT
# ==========================================

PROJECT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"

source "$PROJECT_ROOT/lib/common.sh"

echo "=========================================="
echo "          SSH SECURITY AUDIT"
echo "=========================================="

# 1. Check SSH server installation

echo ""
echo "1. Checking SSH Server Installation"

if ! command -v sshd >/dev/null 2>&1; then
    warning "OpenSSH server is not installed"
    echo "SSH server security checks cannot continue."
    print_summary
    exit 0
fi

pass "OpenSSH server is installed"

# 2. Check SSH service status

echo ""
echo "2. Checking SSH Service Status"

if systemctl is-active --quiet ssh; then
    pass "SSH service is running"
elif systemctl is-active --quiet sshd; then
    pass "SSHD service is running"
else
    warning "SSH service is not currently running"
fi

# 3. Read effective SSH configuration

echo ""
echo "3. Checking Effective SSH Configuration"

if ! command -v timeout >/dev/null 2>&1; then
    warning "timeout command is unavailable"
    print_summary
    exit 0
fi

SSH_CONFIG=$(sudo timeout 10 sshd -T 2>/dev/null)

if [ -z "$SSH_CONFIG" ]; then
    error "Unable to read effective SSH configuration"
    echo "Check the SSH configuration and try again."
    print_summary
    exit 1
fi

pass "Effective SSH configuration retrieved"

# 4. Check root login

echo ""
echo "4. Checking Root Login Policy"

ROOT_LOGIN=$(echo "$SSH_CONFIG" | awk '$1 == "permitrootlogin" {print $2; exit}')

echo "PermitRootLogin: $ROOT_LOGIN"

case "$ROOT_LOGIN" in
    no)
        pass "Direct root SSH login is disabled"
        ;;
    prohibit-password)
        warning "Root login is allowed using key-based authentication"
        ;;
    *)
        warning "Root SSH login policy needs review"
        ;;
esac

# 5. Check password authentication

echo ""
echo "5. Checking Password Authentication"

PASSWORD_AUTH=$(echo "$SSH_CONFIG" | awk '$1 == "passwordauthentication" {print $2; exit}')

echo "PasswordAuthentication: $PASSWORD_AUTH"

if [ "$PASSWORD_AUTH" = "no" ]; then
    pass "SSH password authentication is disabled"
elif [ "$PASSWORD_AUTH" = "yes" ]; then
    warning "SSH password authentication is enabled"
else
    warning "SSH password authentication setting needs review"
fi

# 6. Check empty passwords

echo ""
echo "6. Checking Empty Password Authentication"

EMPTY_PASSWORD=$(echo "$SSH_CONFIG" | awk '$1 == "permitemptypasswords" {print $2; exit}')

echo "PermitEmptyPasswords: $EMPTY_PASSWORD"

if [ "$EMPTY_PASSWORD" = "no" ]; then
    pass "Empty password authentication is disabled"
else
    warning "Empty password authentication setting needs review"
fi

# 7. Check SSH port

echo ""
echo "7. Checking SSH Port"

SSH_PORT=$(echo "$SSH_CONFIG" | awk '$1 == "port" {print $2; exit}')

echo "Configured SSH Port: ${SSH_PORT:-Unknown}"

if [[ "$SSH_PORT" =~ ^[0-9]+$ ]] && 
   [ "$SSH_PORT" -ge 1 ] && [ "$SSH_PORT" -le 65535 ]; then
    pass "Valid SSH port configuration detected"
else
    warning "SSH port configuration needs review"
fi

# 8. Check public key authentication

echo ""
echo "8. Checking Public Key Authentication"

PUBKEY_AUTH=$(echo "$SSH_CONFIG" | awk '$1 == "pubkeyauthentication" {print $2; exit}')

echo "PubkeyAuthentication: $PUBKEY_AUTH"

if [ "$PUBKEY_AUTH" = "yes" ]; then
    pass "Public key authentication is enabled"
else
    warning "Public key authentication is disabled or needs review"
fi

# 9. Check SSH configuration file

echo ""
echo "9. Checking SSH Configuration File"

SSH_FILE="/etc/ssh/sshd_config"

if [ -f "$SSH_FILE" ]; then
    pass "SSH configuration file exists"

    OWNER=$(stat -c "%U" "$SSH_FILE")

    if [ "$OWNER" = "root" ]; then
        pass "SSH configuration file is owned by root"
    else
        warning "SSH configuration file ownership needs review"
    fi
else
    error "SSH configuration file is missing"
fi

# 10. Final summary

echo ""
print_summary

echo ""
echo "=========================================="
echo " SSH SECURITY AUDIT COMPLETED"
echo "=========================================="
