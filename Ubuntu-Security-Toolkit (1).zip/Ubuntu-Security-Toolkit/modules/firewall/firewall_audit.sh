
#!/bin/bash

# ==========================================
# UBUNTU FIREWALL SECURITY AUDIT
# ==========================================

PROJECT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"

source "$PROJECT_ROOT/lib/common.sh"

echo "=========================================="
echo "        FIREWALL SECURITY AUDIT"
echo "=========================================="

# 1. Check whether UFW is installed

echo ""
echo "1. Checking UFW Installation"

if ! command -v ufw >/dev/null 2>&1; then
    warning "UFW is not installed"
    echo "Another firewall tool may be managing network traffic."
    print_summary
    exit 0
fi

pass "UFW firewall is installed"

# 2. Request administrator authentication

echo ""
echo "2. Checking Administrator Access"

if ! sudo -v; then
    error "Administrator authentication failed"
    print_summary
    exit 1
fi

pass "Administrator authentication successful"

# 3. Check firewall status

echo ""
echo "3. Checking Firewall Status"

UFW_STATUS=$(sudo ufw status verbose 2>&1)

echo "$UFW_STATUS"

if echo "$UFW_STATUS" | grep -q "^Status: active"; then
    pass "UFW firewall is active"
elif echo "$UFW_STATUS" | grep -q "^Status: inactive"; then
    warning "UFW firewall is inactive"
else
    error "Unable to determine UFW status"
fi

# 4. Check default firewall policies

echo ""
echo "4. Checking Default Firewall Policies"

DEFAULT_POLICY=$(echo "$UFW_STATUS" | grep "^Default:")

if [ -n "$DEFAULT_POLICY" ]; then

    echo "$DEFAULT_POLICY"

    if echo "$DEFAULT_POLICY" | grep -qi "deny (incoming)"; then
        pass "Default incoming traffic policy is deny"
    else
        warning "Default incoming traffic policy should be reviewed"
    fi

    if echo "$DEFAULT_POLICY" | grep -qi "allow (outgoing)"; then
        pass "Default outgoing traffic policy allows connections"
    else
        warning "Default outgoing traffic policy should be reviewed"
    fi

else
    warning "Default firewall policies are unavailable"
fi

# 5. Display configured firewall rules

echo ""
echo "5. Checking Firewall Rules"

sudo ufw status numbered

pass "Firewall rule information collected"

# 6. Check firewall logging

echo ""
echo "6. Checking Firewall Logging"

LOG_STATUS=$(echo "$UFW_STATUS" | grep -i "Logging:")

if [ -n "$LOG_STATUS" ]; then

    echo "$LOG_STATUS"

    if echo "$LOG_STATUS" | grep -qi "on"; then
        pass "Firewall logging is enabled"
    else
        warning "Firewall logging is disabled"
    fi

else
    warning "Firewall logging information is unavailable"
fi

# 7. Final security summary

echo ""
print_summary

echo ""
echo "=========================================="
echo " FIREWALL SECURITY AUDIT COMPLETED"
echo "=========================================="
