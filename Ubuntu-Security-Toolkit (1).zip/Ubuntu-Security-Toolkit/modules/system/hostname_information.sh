clear
#!/usr/bin/env bash
# ==============================================================================
#   MODULE: Hostname Information
#   Advanced Ubuntu Security Hardening & Audit Toolkit
# ==============================================================================
set -o pipefail

# ------------------------------------------------------------------------------
# 1. BOOTSTRAP & LIBRARY SOURCING
# ------------------------------------------------------------------------------
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"

# Source the common library; exit gracefully if not found
if [ -f "$PROJECT_ROOT/lib/common.sh" ]; then
    source "$PROJECT_ROOT/lib/common.sh"
else
    echo -e "\033[1;31m[ERROR] Cannot find lib/common.sh at $PROJECT_ROOT/lib/common.sh\033[0m"
    exit 2
fi

# ------------------------------------------------------------------------------
# 2. GLOBAL AUDIT VARIABLES
# ------------------------------------------------------------------------------
TOTAL_CHECKS=0
PASSED_CHECKS=0
WARNING_CHECKS=0
ERROR_CHECKS=0

# Hostname Variables
ACTIVE_HOSTNAME="Unknown"
FQDN="Unknown"
ETC_HOSTNAME_VAL="Unknown"
HOSTS_HAS_HOSTNAME=1

# File Security Variables
ETC_HOSTNAME_PERMS="Unknown"
ETC_HOSTNAME_OWNER="Unknown"
ETC_HOSTS_PERMS="Unknown"
ETC_HOSTS_OWNER="Unknown"

# ------------------------------------------------------------------------------
# 3. HELPER FUNCTIONS FOR METRICS
# ------------------------------------------------------------------------------
increment_pass()  { ((TOTAL_CHECKS++)); ((PASSED_CHECKS++)); }
increment_warn()  { ((TOTAL_CHECKS++)); ((WARNING_CHECKS++)); }
increment_error() { ((TOTAL_CHECKS++)); ((ERROR_CHECKS++)); }

# ------------------------------------------------------------------------------
# 4. DATA COLLECTION
# ------------------------------------------------------------------------------
get_hostname_information() {
    # 1. Active Hostname
    if command_exists hostnamectl; then
        ACTIVE_HOSTNAME="$(hostnamectl --static 2>/dev/null)"
        [ -z "$ACTIVE_HOSTNAME" ] && ACTIVE_HOSTNAME="$(hostname 2>/dev/null)"
    elif command_exists hostname; then
        ACTIVE_HOSTNAME="$(hostname 2>/dev/null)"
    fi
    ACTIVE_HOSTNAME="${ACTIVE_HOSTNAME:-Unknown}"

    # 2. Fully Qualified Domain Name (FQDN)
    if command_exists hostname; then
        FQDN="$(hostname -f 2>/dev/null || echo "Not configured")"
    fi

    # 3. Static configuration file (/etc/hostname)
    if [ -f /etc/hostname ]; then
        ETC_HOSTNAME_VAL="$(cat /etc/hostname 2>/dev/null | tr -d ' \n')"
        ETC_HOSTNAME_PERMS="$(stat -c "%a" /etc/hostname 2>/dev/null)"
        ETC_HOSTNAME_OWNER="$(stat -c "%U:%G" /etc/hostname 2>/dev/null)"
    fi

    # 4. Local resolution file (/etc/hosts)
    if [ -f /etc/hosts ]; then
        ETC_HOSTS_PERMS="$(stat -c "%a" /etc/hosts 2>/dev/null)"
        ETC_HOSTS_OWNER="$(stat -c "%U:%G" /etc/hosts 2>/dev/null)"
        
        # Check if the active hostname is mapped in /etc/hosts
        if grep -qwi "$ACTIVE_HOSTNAME" /etc/hosts 2>/dev/null; then
            HOSTS_HAS_HOSTNAME=0
        fi
    fi
}

# ------------------------------------------------------------------------------
# 5. PRESENTATION
# ------------------------------------------------------------------------------
show_hostname_information() {
    module_header "HOSTNAME INFORMATION AUDIT" "4"

    section "HOSTNAME CONFIGURATION"
    
    value_row "Active Hostname" "$ACTIVE_HOSTNAME"
    value_row "FQDN" "$FQDN"
    value_row "/etc/hostname File" "$ETC_HOSTNAME_VAL"
    
    echo
    section "FILE METADATA"
    
    value_row "/etc/hostname Owner" "$ETC_HOSTNAME_OWNER"
    value_row "/etc/hostname Perms" "$ETC_HOSTNAME_PERMS"
    value_row "/etc/hosts Owner" "$ETC_HOSTS_OWNER"
    value_row "/etc/hosts Perms" "$ETC_HOSTS_PERMS"
}

# ------------------------------------------------------------------------------
# 6. SECURITY ANALYSIS & CHECKS
# ------------------------------------------------------------------------------
perform_security_checks() {
    section "SECURITY-RELEVANT INFORMATION"

    # Check 1: Generic/Default Hostname usage
    local generic_names=("ubuntu" "localhost" "debian" "linux" "server")
    local is_generic=0
    for name in "${generic_names[@]}"; do
        if [[ "${ACTIVE_HOSTNAME,,}" == "$name" ]]; then
            is_generic=1
            break
        fi
    done

    if [ "$is_generic" -eq 1 ]; then
        row "System Identity" "Default hostname used ($ACTIVE_HOSTNAME)" "warn"
        increment_warn
    else
        row "System Identity" "Custom hostname configured" "ok"
        increment_pass
    fi

    # Check 2: Configuration consistency
    if [ "$ACTIVE_HOSTNAME" = "$ETC_HOSTNAME_VAL" ]; then
        row "Config Consistency" "Active hostname matches /etc/hostname" "ok"
        increment_pass
    else
        row "Config Consistency" "Active hostname differs from /etc/hostname" "warn"
        increment_warn
    fi

    # Check 3: Local Resolution Mapping
    if [ "$HOSTS_HAS_HOSTNAME" -eq 0 ]; then
        row "Local Resolution" "Hostname mapped correctly in /etc/hosts" "ok"
        increment_pass
    else
        row "Local Resolution" "Hostname NOT found in /etc/hosts" "warn"
        increment_warn
    fi

    # Check 4: /etc/hostname Permissions
    if [ ! -f /etc/hostname ]; then
        row "/etc/hostname File" "File does not exist" "bad"
        increment_error
    else
        if [[ "$ETC_HOSTNAME_PERMS" =~ ^[46][04][04]$ ]] && [[ "$ETC_HOSTNAME_OWNER" == "root:root" ]]; then
            row "/etc/hostname Security" "Secure permissions ($ETC_HOSTNAME_PERMS, $ETC_HOSTNAME_OWNER)" "ok"
            increment_pass
        else
            row "/etc/hostname Security" "Insecure permissions or ownership!" "bad"
            increment_error
        fi
    fi

    # Check 5: /etc/hosts Permissions
    if [ ! -f /etc/hosts ]; then
        row "/etc/hosts File" "File does not exist" "bad"
        increment_error
    else
        if [[ "$ETC_HOSTS_PERMS" =~ ^[46][04][04]$ ]] && [[ "$ETC_HOSTS_OWNER" == "root:root" ]]; then
            row "/etc/hosts Security" "Secure permissions ($ETC_HOSTS_PERMS, $ETC_HOSTS_OWNER)" "ok"
            increment_pass
        else
            row "/etc/hosts Security" "Insecure permissions or ownership!" "bad"
            increment_error
        fi
    fi
}

# ------------------------------------------------------------------------------
# 7. SUMMARY
# ------------------------------------------------------------------------------
show_summary() {
    section "AUDIT SUMMARY"

    value_row "Checks Performed" "$TOTAL_CHECKS"
    value_row "Passed" "${LGREEN}${PASSED_CHECKS}${NC}"
    value_row "Warnings" "${YELLOW}${WARNING_CHECKS}${NC}"
    value_row "Errors" "${LRED}${ERROR_CHECKS}${NC}"
    
    echo

    # Overall Status Calculation
    if [ "$ERROR_CHECKS" -gt 0 ]; then
        row "Security Status" "ATTENTION REQUIRED" "bad"
        divider
        echo -e "  ${LRED}✖ Hostname audit completed with critical findings.${NC}"
    elif [ "$WARNING_CHECKS" -gt 0 ]; then
        row "Security Status" "REVIEW RECOMMENDED" "warn"
        divider
        echo -e "  ${YELLOW}⚠ Hostname audit completed with warnings.${NC}"
    else
        row "Security Status" "GOOD" "ok"
        divider
        echo -e "  ${LGREEN}✔ Hostname audit completed successfully.${NC}"
    fi
    
    divider
    echo
}

# ------------------------------------------------------------------------------
# 8. MAIN EXECUTION
# ------------------------------------------------------------------------------
main() {
    # 1. Collect Data
    get_hostname_information
    
    # 2. Present Info
    show_hostname_information
    
    # 3. Analyze Data
    perform_security_checks
    
    # 4. Display Summary
    show_summary
    
    return 0
}

# Execute main function with all script arguments
main "$@"
