clear
#!/usr/bin/env bash
# ==============================================================================
#   MODULE: Running Services Information
#   Advanced Ubuntu Security Hardening & Audit Toolkit
# ==============================================================================
set -o pipefail

# ------------------------------------------------------------------------------
# 1. BOOTSTRAP & LIBRARY SOURCING
# ------------------------------------------------------------------------------
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"

# Source the common library; exit gracefully if not found
if [ -f "$PROJECT_ROOT/lib/common.sh" ]; then
    source "$PROJECT_ROOT/lib/common.sh"
else
    echo -e "\033[1;31m[ERROR] Cannot find lib/common.sh at $PROJECT_ROOT/lib/common.sh\033[0m"
    exit 2
fi

# ------------------------------------------------------------------------------
# 2. GLOBAL AUDIT VARIABLES
# ------------------------------------------------------------------------------
TOTAL_CHECKS=0
PASSED_CHECKS=0
WARNING_CHECKS=0
ERROR_CHECKS=0

# Service Metrics Variables
SRV_LOADED="0"
SRV_RUNNING="0"
SRV_FAILED_COUNT="0"
SRV_FAILED_LIST=""
SYSTEMD_AVAILABLE=true

# ------------------------------------------------------------------------------
# 3. HELPER FUNCTIONS FOR METRICS
# ------------------------------------------------------------------------------
increment_pass()  { ((TOTAL_CHECKS++)); ((PASSED_CHECKS++)); }
increment_warn()  { ((TOTAL_CHECKS++)); ((WARNING_CHECKS++)); }
increment_error() { ((TOTAL_CHECKS++)); ((ERROR_CHECKS++)); }

# ------------------------------------------------------------------------------
# 4. DATA COLLECTION
# ------------------------------------------------------------------------------
get_running_services() {
    # Check if systemd is the init system
    if ! command_exists systemctl; then
        SYSTEMD_AVAILABLE=false
        return
    fi

    # Collect numerical metrics safely
    SRV_LOADED=$(systemctl list-units --type=service --all --no-pager --no-legend 2>/dev/null | wc -l)
    SRV_RUNNING=$(systemctl list-units --type=service --state=running --no-pager --no-legend 2>/dev/null | wc -l)
    SRV_FAILED_COUNT=$(systemctl list-units --type=service --state=failed --no-pager --no-legend 2>/dev/null | wc -l)
    
    # Collect list of failed services (if any)
    if [ "$SRV_FAILED_COUNT" -gt 0 ]; then
        SRV_FAILED_LIST=$(systemctl list-units --type=service --state=failed --no-pager --no-legend 2>/dev/null | awk '{print $1}')
    fi
}

# ------------------------------------------------------------------------------
# 5. PRESENTATION
# ------------------------------------------------------------------------------
show_running_services() {
    module_header "RUNNING SERVICES AUDIT" "7"

    section "SERVICE METRICS"
    
    if [ "$SYSTEMD_AVAILABLE" = false ]; then
        row "Init System" "systemd not detected" "bad"
        return
    fi

    value_row "Total Loaded Services" "$SRV_LOADED"
    value_row "Actively Running" "$SRV_RUNNING"
    
    if [ "$SRV_FAILED_COUNT" -gt 0 ]; then
        value_row "Failed Services" "${LRED}${SRV_FAILED_COUNT}${NC}"
    else
        value_row "Failed Services" "${LGREEN}0${NC}"
    fi

    # Note if not running as root
    if [ "$EUID" -ne 0 ]; then
        echo
        row "Privilege Level" "Standard user. Some details may be hidden." "info"
    fi
}

# ------------------------------------------------------------------------------
# 6. SECURITY ANALYSIS & CHECKS
# ------------------------------------------------------------------------------
perform_security_checks() {
    if [ "$SYSTEMD_AVAILABLE" = false ]; then
        return
    fi

    # --------------------------------------------------------------------------
    section "CRITICAL SECURITY DAEMONS"
    
    # Check highly recommended security services
    local security_daemons=("apparmor.service" "ufw.service" "sshd.service" "auditd.service" "fail2ban.service")
    
    for srv in "${security_daemons[@]}"; do
        local display_name="${srv%.service}"
        
        if systemctl is-active --quiet "$srv" 2>/dev/null; then
            row "Daemon: $display_name" "Active and operational" "ok"
            increment_pass
        else
            # Distinguish between high priority (ufw/apparmor) and medium priority
            if [[ "$srv" == "apparmor.service" || "$srv" == "ufw.service" ]]; then
                row "Daemon: $display_name" "Critical service is INACTIVE" "bad"
                increment_error
            else
                row "Daemon: $display_name" "Not running / Not installed" "warn"
                increment_warn
            fi
        fi
    done

    # --------------------------------------------------------------------------
    section "RISKY / EXPOSED SERVICES"
    
    # Define services that are legacy, unencrypted, or rarely needed on secure servers
    local risky_daemons=("telnet.socket" "telnet@.service" "rsh.socket" "vsftpd.service" "proftpd.service" "cups.service" "avahi-daemon.service" "rpcbind.service")
    local risky_found=0

    for srv in "${risky_daemons[@]}"; do
        if systemctl is-active --quiet "$srv" 2>/dev/null; then
            local display_name="${srv%.*}"
            row "Risky: $display_name" "Service is ACTIVE" "bad"
            increment_error
            risky_found=1
        fi
    done

    if [ "$risky_found" -eq 0 ]; then
        row "Legacy/Risky Services" "None detected" "ok"
        increment_pass
    fi

    # --------------------------------------------------------------------------
    section "SYSTEM STABILITY"

    if [ "$SRV_FAILED_COUNT" -gt 0 ]; then
        row "Failed State Daemons" "$SRV_FAILED_COUNT services failed" "bad"
        increment_error
        echo
        echo -e "  ${LRED}▶ Failed Services List:${NC}"
        for failed_srv in $SRV_FAILED_LIST; do
            echo -e "  ${WHITE}- ${failed_srv}${NC}"
        done
    else
        row "Failed State Daemons" "All services healthy" "ok"
        increment_pass
    fi
}

# ------------------------------------------------------------------------------
# 7. SUMMARY
# ------------------------------------------------------------------------------
show_summary() {
    section "AUDIT SUMMARY"

    value_row "Checks Performed" "$TOTAL_CHECKS"
    value_row "Passed" "${LGREEN}${PASSED_CHECKS}${NC}"
    value_row "Warnings" "${YELLOW}${WARNING_CHECKS}${NC}"
    value_row "Errors" "${LRED}${ERROR_CHECKS}${NC}"
    
    echo

    # Overall Status Calculation
    if [ "$SYSTEMD_AVAILABLE" = false ]; then
        row "Security Status" "UNDETERMINED (No Systemd)" "warn"
        divider
        echo -e "  ${YELLOW}⚠ Could not complete audit due to missing systemctl.${NC}"
    elif [ "$ERROR_CHECKS" -gt 0 ]; then
        row "Security Status" "ATTENTION REQUIRED" "bad"
        divider
        echo -e "  ${LRED}✖ Service audit completed with critical security findings.${NC}"
    elif [ "$WARNING_CHECKS" -gt 0 ]; then
        row "Security Status" "REVIEW RECOMMENDED" "warn"
        divider
        echo -e "  ${YELLOW}⚠ Service audit completed with warnings.${NC}"
    else
        row "Security Status" "GOOD" "ok"
        divider
        echo -e "  ${LGREEN}✔ Service audit completed successfully.${NC}"
    fi
    
    divider
    echo
}

# ------------------------------------------------------------------------------
# 8. MAIN EXECUTION
# ------------------------------------------------------------------------------
main() {
    # 1. Collect Data
    get_running_services
    
    # 2. Present Metrics
    show_running_services
    
    # 3. Analyze Security Stance
    perform_security_checks
    
    # 4. Display Summary
    show_summary
    
    # Sensible exit codes
    if [ "$SYSTEMD_AVAILABLE" = false ]; then
        return 1
    fi
    return 0
}

# Execute main function with all script arguments
main "$@"
