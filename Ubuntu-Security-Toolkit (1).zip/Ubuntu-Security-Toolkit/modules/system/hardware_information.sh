clear
#!/usr/bin/env bash
# ==============================================================================
#   MODULE: Hardware Information
#   Advanced Ubuntu Security Hardening & Audit Toolkit
# ==============================================================================
set -o pipefail

# ------------------------------------------------------------------------------
# 1. BOOTSTRAP & LIBRARY SOURCING
# ------------------------------------------------------------------------------
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"

# Source the common library; exit gracefully if not found
if [ -f "$PROJECT_ROOT/lib/common.sh" ]; then
    source "$PROJECT_ROOT/lib/common.sh"
else
    echo -e "\033[1;31m[ERROR] Cannot find lib/common.sh at $PROJECT_ROOT/lib/common.sh\033[0m"
    exit 2
fi

# ------------------------------------------------------------------------------
# 2. GLOBAL AUDIT VARIABLES
# ------------------------------------------------------------------------------
TOTAL_CHECKS=0
PASSED_CHECKS=0
WARNING_CHECKS=0
ERROR_CHECKS=0

# Hardware Information Variables
HW_CPU_MODEL="Unknown"
HW_CPU_CORES="Unknown"
HW_RAM_TOTAL="Unknown"
HW_SWAP_TOTAL="Unknown"
HW_DISK_TOTAL="Unknown"
HW_DISK_USAGE_PCT=0
HW_VIRTUALIZATION="Unknown"
HW_CPU_VULN_COUNT=0

# ------------------------------------------------------------------------------
# 3. HELPER FUNCTIONS FOR METRICS
# ------------------------------------------------------------------------------
increment_pass()  { ((TOTAL_CHECKS++)); ((PASSED_CHECKS++)); }
increment_warn()  { ((TOTAL_CHECKS++)); ((WARNING_CHECKS++)); }
increment_error() { ((TOTAL_CHECKS++)); ((ERROR_CHECKS++)); }

# ------------------------------------------------------------------------------
# 4. DATA COLLECTION
# ------------------------------------------------------------------------------
get_hardware_information() {
    # 1. CPU Information
    if command_exists lscpu; then
        HW_CPU_MODEL="$(lscpu 2>/dev/null | grep -i "^Model name:" | sed 's/.*:[[:space:]]*//' || echo "Unknown")"
    elif [ -f /proc/cpuinfo ]; then
        HW_CPU_MODEL="$(grep -m1 'model name' /proc/cpuinfo 2>/dev/null | sed 's/.*:[[:space:]]*//' || echo "Unknown")"
    fi

    if command_exists nproc; then
        HW_CPU_CORES="$(nproc 2>/dev/null || echo "Unknown")"
    fi

    # 2. Memory & Swap Information
    if command_exists free; then
        HW_RAM_TOTAL="$(free -h 2>/dev/null | awk '/^Mem:/ {print $2}')"
        HW_SWAP_TOTAL="$(free -h 2>/dev/null | awk '/^Swap:/ {print $2}')"
    fi

    # 3. Disk Information (Root Partition)
    if command_exists df; then
        HW_DISK_TOTAL="$(df -h / 2>/dev/null | awk 'NR==2 {print $2}')"
        # Extract percentage as an integer for threshold checking
        HW_DISK_USAGE_PCT="$(df / 2>/dev/null | awk 'NR==2 {print $5}' | tr -d '%' || echo 0)"
    fi

    # 4. Virtualization
    if command_exists systemd-detect-virt; then
        HW_VIRTUALIZATION="$(systemd-detect-virt 2>/dev/null || echo "None (Bare Metal)")"
        [ "$HW_VIRTUALIZATION" = "none" ] && HW_VIRTUALIZATION="None (Bare Metal)"
    fi

    # 5. Hardware/CPU Vulnerabilities (Check kernel mitigations)
    if [ -d /sys/devices/system/cpu/vulnerabilities ]; then
        # Count files that literally start with "Vulnerable"
        HW_CPU_VULN_COUNT=$(grep -il "^Vulnerable" /sys/devices/system/cpu/vulnerabilities/* 2>/dev/null | wc -l)
    fi
}

# ------------------------------------------------------------------------------
# 5. PRESENTATION
# ------------------------------------------------------------------------------
show_hardware_information() {
    module_header "HARDWARE INFORMATION AUDIT" "3"

    section "SYSTEM HARDWARE DETAILS"
    
    value_row "CPU Model" "$HW_CPU_MODEL"
    value_row "CPU Cores" "$HW_CPU_CORES cores"
    value_row "Physical Memory (RAM)" "$HW_RAM_TOTAL"
    value_row "Configured Swap" "$HW_SWAP_TOTAL"
    value_row "Root Disk Capacity" "$HW_DISK_TOTAL"
    value_row "Virtualization" "$HW_VIRTUALIZATION"
}

# ------------------------------------------------------------------------------
# 6. SECURITY ANALYSIS & CHECKS
# ------------------------------------------------------------------------------
perform_security_checks() {
    section "SECURITY-RELEVANT INFORMATION"

    # Check 1: Virtualization Threat Model Context
    if [[ "${HW_VIRTUALIZATION,,}" == *"none"* || "${HW_VIRTUALIZATION,,}" == *"bare"* ]]; then
        row "Hardware Context" "Running on Bare Metal (Physical)" "info"
        increment_pass
    else
        row "Hardware Context" "Running inside VM/Container ($HW_VIRTUALIZATION)" "info"
        increment_pass
    fi

    # Check 2: Disk Space (Availability / DoS / Logging Risk)
    if [ -z "$HW_DISK_USAGE_PCT" ] || ! [[ "$HW_DISK_USAGE_PCT" =~ ^[0-9]+$ ]]; then
        row "Disk Availability" "Could not determine disk usage" "warn"
        increment_warn
    elif [ "$HW_DISK_USAGE_PCT" -ge 95 ]; then
        row "Disk Availability" "CRITICAL: Root disk is ${HW_DISK_USAGE_PCT}% full!" "bad"
        increment_error
    elif [ "$HW_DISK_USAGE_PCT" -ge 85 ]; then
        row "Disk Availability" "WARNING: Root disk is ${HW_DISK_USAGE_PCT}% full" "warn"
        increment_warn
    else
        row "Disk Availability" "Adequate disk space available (${HW_DISK_USAGE_PCT}% used)" "ok"
        increment_pass
    fi

    # Check 3: Swap Memory (Data Exposure Risk)
    if [[ "$HW_SWAP_TOTAL" == "0B" ]] || [[ "$HW_SWAP_TOTAL" == "0" ]] || [[ -z "$HW_SWAP_TOTAL" ]]; then
        row "Swap Memory" "No swap configured (Secure against disk leaks)" "ok"
        increment_pass
    else
        row "Swap Memory" "Swap is active. Ensure partition is encrypted." "warn"
        increment_warn
    fi

    # Check 4: Unmitigated CPU Vulnerabilities (e.g., Spectre, Meltdown)
    if [ ! -d /sys/devices/system/cpu/vulnerabilities ]; then
        row "CPU Vulnerabilities" "Sysfs interface missing; cannot verify mitigations" "info"
    elif [ "$HW_CPU_VULN_COUNT" -gt 0 ]; then
        row "CPU Vulnerabilities" "$HW_CPU_VULN_COUNT unmitigated hardware flaws detected!" "bad"
        increment_error
    else
        row "CPU Vulnerabilities" "All known CPU vulnerabilities mitigated" "ok"
        increment_pass
    fi
}

# ------------------------------------------------------------------------------
# 7. SUMMARY
# ------------------------------------------------------------------------------
show_summary() {
    section "AUDIT SUMMARY"

    value_row "Checks Performed" "$TOTAL_CHECKS"
    value_row "Passed" "${LGREEN}${PASSED_CHECKS}${NC}"
    value_row "Warnings" "${YELLOW}${WARNING_CHECKS}${NC}"
    value_row "Errors" "${LRED}${ERROR_CHECKS}${NC}"
    
    echo

    # Overall Status Calculation
    if [ "$ERROR_CHECKS" -gt 0 ]; then
        row "Security Status" "ATTENTION REQUIRED" "bad"
        divider
        echo -e "  ${LRED}✖ Hardware audit completed with critical findings.${NC}"
    elif [ "$WARNING_CHECKS" -gt 0 ]; then
        row "Security Status" "REVIEW RECOMMENDED" "warn"
        divider
        echo -e "  ${YELLOW}⚠ Hardware audit completed with warnings.${NC}"
    else
        row "Security Status" "GOOD" "ok"
        divider
        echo -e "  ${LGREEN}✔ Hardware audit completed successfully.${NC}"
    fi
    
    divider
    echo
}

# ------------------------------------------------------------------------------
# 8. MAIN EXECUTION
# ------------------------------------------------------------------------------
main() {
    # 1. Collect Data
    get_hardware_information
    
    # 2. Present Info
    show_hardware_information
    
    # 3. Analyze Data
    perform_security_checks
    
    # 4. Display Summary
    show_summary
    
    return 0
}

# Execute main function with all script arguments
main "$@"
