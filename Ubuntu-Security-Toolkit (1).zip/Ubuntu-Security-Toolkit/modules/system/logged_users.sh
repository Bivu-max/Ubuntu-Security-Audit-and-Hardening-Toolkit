clear
#!/usr/bin/env bash
# ==============================================================================
#   MODULE: Logged Users Information
#   Advanced Ubuntu Security Hardening & Audit Toolkit
# ==============================================================================
set -o pipefail

# ------------------------------------------------------------------------------
# 1. BOOTSTRAP & LIBRARY SOURCING
# ------------------------------------------------------------------------------
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"

# Source the common library; exit gracefully if not found
if [ -f "$PROJECT_ROOT/lib/common.sh" ]; then
    source "$PROJECT_ROOT/lib/common.sh"
else
    echo -e "\033[1;31m[ERROR] Cannot find lib/common.sh at $PROJECT_ROOT/lib/common.sh\033[0m"
    exit 2
fi

# ------------------------------------------------------------------------------
# 2. GLOBAL AUDIT VARIABLES
# ------------------------------------------------------------------------------
TOTAL_CHECKS=0
PASSED_CHECKS=0
WARNING_CHECKS=0
ERROR_CHECKS=0

# Logged User Metrics
ACTIVE_SESSIONS_COUNT=0
ROOT_SESSIONS_COUNT=0
UNIQUE_USERS="None"
IDLE_SESSIONS=0
FAILED_LOGINS_COUNT="Unknown"

# ------------------------------------------------------------------------------
# 3. HELPER FUNCTIONS FOR METRICS
# ------------------------------------------------------------------------------
increment_pass()  { ((TOTAL_CHECKS++)); ((PASSED_CHECKS++)); }
increment_warn()  { ((TOTAL_CHECKS++)); ((WARNING_CHECKS++)); }
increment_error() { ((TOTAL_CHECKS++)); ((ERROR_CHECKS++)); }

# ------------------------------------------------------------------------------
# 4. DATA COLLECTION
# ------------------------------------------------------------------------------
get_logged_users() {
    if command_exists who; then
        ACTIVE_SESSIONS_COUNT=$(who 2>/dev/null | wc -l)
        
        if [ "$ACTIVE_SESSIONS_COUNT" -gt 0 ]; then
            ROOT_SESSIONS_COUNT=$(who 2>/dev/null | awk '{print $1}' | grep -c "^root$")
            UNIQUE_USERS=$(who 2>/dev/null | awk '{print $1}' | sort -u | tr '\n' ' ' | sed 's/ $//')
            
            # Count sessions idle for > 1 hour (Format HH:MM) or "old" (> 24h)
            IDLE_SESSIONS=$(who -u 2>/dev/null | awk '$6 != "." && $6 != "old" && $6 ~ /^[0-9]/ {split($6,a,":"); if (a[1] > 0) print $0} $6 == "old" {print $0}' | wc -l)
        fi
    fi

    # Attempt to read failed logins if running as root
    if [ "$EUID" -eq 0 ] && command_exists lastb; then
        # Sample the last 500 failed entries to avoid hanging on massive logs
        FAILED_LOGINS_COUNT=$(lastb -n 500 2>/dev/null | awk 'NF>3' | grep -v "btmp begins" | wc -l)
    fi
}

# ------------------------------------------------------------------------------
# 5. PRESENTATION
# ------------------------------------------------------------------------------
show_logged_users() {
    module_header "LOGGED USERS AUDIT" "6"

    section "ACTIVE USER SESSIONS"
    
    value_row "Total Active Sessions" "$ACTIVE_SESSIONS_COUNT"
    value_row "Direct Root Logins" "$ROOT_SESSIONS_COUNT"
    value_row "Unique Users Logged In" "$UNIQUE_USERS"
    
    if [ "$EUID" -eq 0 ]; then
        value_row "Recent Failed Logins" "$FAILED_LOGINS_COUNT (Sampled)"
    else
        value_row "Recent Failed Logins" "${YELLOW}Hidden (Requires Root)${NC}"
    fi

    # Display detailed session breakdown if users are logged in
    if [ "$ACTIVE_SESSIONS_COUNT" -gt 0 ]; then
        echo
        echo -e "  ${LBLUE}${BOLD}▶ Session Details${NC}"
        echo -e "  ${DIM}${SHORT_LINE}${NC}"
        echo -e "  ${CYAN}$(printf "%-12s %-10s %-16s %-10s" "USER" "TTY" "FROM" "IDLE")${NC}"
        
        who -u 2>/dev/null | while read -r user tty mon day time idle pid from; do
            # Clean up the 'from' field (remove parenthesis)
            from=$(echo "$from" | tr -d '()')
            [ -z "$from" ] && from="Local"
            
            # Colorize idle time if it's long
            local idle_color="$WHITE"
            if [[ "$idle" == "old" ]] || [[ "$idle" =~ ^[1-9][0-9]: ]]; then
                idle_color="$YELLOW"
            fi
            
            printf "  ${WHITE}%-12s %-10s %-16s ${idle_color}%-10s${NC}\n" "$user" "$tty" "$from" "$idle"
        done
    fi
}

# ------------------------------------------------------------------------------
# 6. SECURITY ANALYSIS & CHECKS
# ------------------------------------------------------------------------------
perform_security_checks() {
    section "SECURITY-RELEVANT INFORMATION"

    # Check 1: Root Logins
    if [ "$ROOT_SESSIONS_COUNT" -gt 0 ]; then
        row "Root Sessions" "Direct root login detected!" "bad"
        increment_error
    else
        row "Root Sessions" "No direct root logins active" "ok"
        increment_pass
    fi

    # Check 2: Abandoned / Idle Sessions
    if [ "$IDLE_SESSIONS" -gt 0 ]; then
        row "Idle Sessions" "$IDLE_SESSIONS session(s) idle > 1 hour" "warn"
        increment_warn
    else
        row "Idle Sessions" "No abandoned/stale sessions found" "ok"
        increment_pass
    fi

    # Check 3: Failed Login Attempts (Requires Root)
    if [ "$EUID" -eq 0 ]; then
        if [ "$FAILED_LOGINS_COUNT" -ge 50 ]; then
            row "Authentication" "High failed attempts! Possible Brute-force." "bad"
            increment_error
        elif [ "$FAILED_LOGINS_COUNT" -ge 10 ]; then
            row "Authentication" "Multiple failed attempts detected ($FAILED_LOGINS_COUNT)" "warn"
            increment_warn
        else
            row "Authentication" "Normal failed login rate ($FAILED_LOGINS_COUNT)" "ok"
            increment_pass
        fi
    else
        row "Authentication" "Cannot audit failed logins without root" "info"
        # We do not fail the audit for this, but inform the user
    fi
}

# ------------------------------------------------------------------------------
# 7. SUMMARY
# ------------------------------------------------------------------------------
show_summary() {
    section "AUDIT SUMMARY"

    value_row "Checks Performed" "$TOTAL_CHECKS"
    value_row "Passed" "${LGREEN}${PASSED_CHECKS}${NC}"
    value_row "Warnings" "${YELLOW}${WARNING_CHECKS}${NC}"
    value_row "Errors" "${LRED}${ERROR_CHECKS}${NC}"
    
    echo

    # Overall Status Calculation
    if [ "$ERROR_CHECKS" -gt 0 ]; then
        row "Security Status" "ATTENTION REQUIRED" "bad"
        divider
        echo -e "  ${LRED}✖ Logged users audit completed with critical findings.${NC}"
    elif [ "$WARNING_CHECKS" -gt 0 ]; then
        row "Security Status" "REVIEW RECOMMENDED" "warn"
        divider
        echo -e "  ${YELLOW}⚠ Logged users audit completed with warnings.${NC}"
    else
        row "Security Status" "GOOD" "ok"
        divider
        echo -e "  ${LGREEN}✔ Logged users audit completed successfully.${NC}"
    fi
    
    divider
    echo
}

# ------------------------------------------------------------------------------
# 8. MAIN EXECUTION
# ------------------------------------------------------------------------------
main() {
    # 1. Collect Data
    get_logged_users
    
    # 2. Present Info
    show_logged_users
    
    # 3. Analyze Data
    perform_security_checks
    
    # 4. Display Summary
    show_summary
    
    return 0
}

# Execute main function with all script arguments
main "$@"
