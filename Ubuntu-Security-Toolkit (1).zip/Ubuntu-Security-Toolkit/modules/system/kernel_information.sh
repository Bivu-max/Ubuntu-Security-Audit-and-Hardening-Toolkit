clear
#!/usr/bin/env bash
# ==============================================================================
#   MODULE: Kernel Information
#   Advanced Ubuntu Security Hardening & Audit Toolkit
# ==============================================================================

set -o pipefail

# ------------------------------------------------------------------------------
# 1. BOOTSTRAP & LIBRARY SOURCING
# ------------------------------------------------------------------------------
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"

# Source the common library; exit gracefully if not found
if [ -f "$PROJECT_ROOT/lib/common.sh" ]; then
    source "$PROJECT_ROOT/lib/common.sh"
else
    echo -e "\033[1;31m[ERROR] Cannot find lib/common.sh at $PROJECT_ROOT/lib/common.sh\033[0m"
    exit 2
fi

# ------------------------------------------------------------------------------
# 2. GLOBAL AUDIT VARIABLES
# ------------------------------------------------------------------------------
TOTAL_CHECKS=0
PASSED_CHECKS=0
WARNING_CHECKS=0
ERROR_CHECKS=0

# Kernel Information Variables
KERN_RELEASE="Unknown"
KERN_VERSION="Unknown"
KERN_ARCH="Unknown"
KERN_CMDLINE="Unknown"
KERN_MODULES_COUNT=0

# Security Sysctl Variables
SYS_ASLR="Unknown"
SYS_DMESG="Unknown"
SYS_KPTR="Unknown"
SYS_SYSRQ="Unknown"
SYS_BPF="Unknown"

# ------------------------------------------------------------------------------
# 3. HELPER FUNCTIONS FOR METRICS
# ------------------------------------------------------------------------------
increment_pass()  { ((TOTAL_CHECKS++)); ((PASSED_CHECKS++)); }
increment_warn()  { ((TOTAL_CHECKS++)); ((WARNING_CHECKS++)); }
increment_error() { ((TOTAL_CHECKS++)); ((ERROR_CHECKS++)); }

# ------------------------------------------------------------------------------
# 4. DATA COLLECTION
# ------------------------------------------------------------------------------
get_kernel_information() {
    # Base Kernel Details
    if command_exists uname; then
        KERN_RELEASE="$(uname -r 2>/dev/null || echo "Unknown")"
        KERN_VERSION="$(uname -v 2>/dev/null || echo "Unknown")"
        KERN_ARCH="$(uname -m 2>/dev/null || echo "Unknown")"
    fi

    # Loaded Modules
    if command_exists lsmod; then
        KERN_MODULES_COUNT="$(lsmod 2>/dev/null | tail -n +2 | wc -l)"
    fi

    # Boot Command Line (truncated for display if too long)
    if [ -f /proc/cmdline ]; then
        KERN_CMDLINE="$(cat /proc/cmdline 2>/dev/null | cut -c 1-50)..."
    fi

    # Sysctl Security Parameters
    if command_exists sysctl; then
        SYS_ASLR="$(sysctl -n kernel.randomize_va_space 2>/dev/null || echo "N/A")"
        SYS_DMESG="$(sysctl -n kernel.dmesg_restrict 2>/dev/null || echo "N/A")"
        SYS_KPTR="$(sysctl -n kernel.kptr_restrict 2>/dev/null || echo "N/A")"
        SYS_SYSRQ="$(sysctl -n kernel.sysrq 2>/dev/null || echo "N/A")"
        SYS_BPF="$(sysctl -n kernel.unprivileged_bpf_disabled 2>/dev/null || echo "N/A")"
    fi
}

# ------------------------------------------------------------------------------
# 5. PRESENTATION
# ------------------------------------------------------------------------------
show_kernel_information() {
    module_header "KERNEL INFORMATION AUDIT" "2"

    section "KERNEL IDENTIFICATION"
    
    value_row "Kernel Release" "$KERN_RELEASE"
    value_row "Build Version" "$KERN_VERSION"
    value_row "Architecture" "$KERN_ARCH"
    value_row "Boot Parameters" "$KERN_CMDLINE"
    value_row "Loaded Modules" "$KERN_MODULES_COUNT modules"
}

# ------------------------------------------------------------------------------
# 6. SECURITY ANALYSIS & CHECKS
# ------------------------------------------------------------------------------
perform_security_checks() {
    section "KERNEL SECURITY PARAMETERS"

    # Check 1: ASLR (Address Space Layout Randomization)
    if [ "$SYS_ASLR" = "2" ]; then
        row "ASLR Status" "Fully randomized (2)" "ok"
        increment_pass
    elif [ "$SYS_ASLR" = "1" ]; then
        row "ASLR Status" "Partially randomized (1)" "warn"
        increment_warn
    else
        row "ASLR Status" "Disabled or Unknown ($SYS_ASLR)" "bad"
        increment_error
    fi

    # Check 2: dmesg Restriction
    if [ "$SYS_DMESG" = "1" ]; then
        row "Dmesg Restriction" "Restricted to privileged users" "ok"
        increment_pass
    else
        row "Dmesg Restriction" "Unrestricted (Info leak risk)" "warn"
        increment_warn
    fi

    # Check 3: Kernel Pointer Restriction
    if [[ "$SYS_KPTR" == "1" || "$SYS_KPTR" == "2" ]]; then
        row "Kptr Restriction" "Kernel pointers hidden ($SYS_KPTR)" "ok"
        increment_pass
    else
        row "Kptr Restriction" "Pointers exposed ($SYS_KPTR)" "warn"
        increment_warn
    fi

    # Check 4: Magic SysRq Keys
    if [ "$SYS_SYSRQ" = "0" ]; then
        row "Magic SysRq" "Disabled (Secure)" "ok"
        increment_pass
    elif [ "$SYS_SYSRQ" = "N/A" ]; then
        row "Magic SysRq" "Could not determine status" "info"
    else
        row "Magic SysRq" "Enabled ($SYS_SYSRQ) (Local attack risk)" "warn"
        increment_warn
    fi

    # Check 5: Unprivileged BPF
    if [[ "$SYS_BPF" == "1" || "$SYS_BPF" == "2" ]]; then
        row "Unprivileged eBPF" "Disabled (Secure)" "ok"
        increment_pass
    else
        row "Unprivileged eBPF" "Enabled (Exploit risk)" "warn"
        increment_warn
    fi
}

# ------------------------------------------------------------------------------
# 7. SUMMARY
# ------------------------------------------------------------------------------
show_summary() {
    section "AUDIT SUMMARY"

    value_row "Checks Performed" "$TOTAL_CHECKS"
    value_row "Passed" "${LGREEN}${PASSED_CHECKS}${NC}"
    value_row "Warnings" "${YELLOW}${WARNING_CHECKS}${NC}"
    value_row "Errors" "${LRED}${ERROR_CHECKS}${NC}"
    
    echo

    # Overall Status Calculation
    if [ "$ERROR_CHECKS" -gt 0 ]; then
        row "Security Status" "ATTENTION REQUIRED" "bad"
        divider
        echo -e "  ${LRED}✖ Kernel audit completed with critical vulnerabilities.${NC}"
    elif [ "$WARNING_CHECKS" -gt 0 ]; then
        row "Security Status" "REVIEW RECOMMENDED" "warn"
        divider
        echo -e "  ${YELLOW}⚠ Kernel audit completed. Hardening recommended.${NC}"
    else
        row "Security Status" "GOOD" "ok"
        divider
        echo -e "  ${LGREEN}✔ Kernel audit completed. System securely configured.${NC}"
    fi
    
    divider
    echo
}

# ------------------------------------------------------------------------------
# 8. MAIN EXECUTION
# ------------------------------------------------------------------------------
main() {
    # 1. Collect Data
    get_kernel_information
    
    # 2. Present Info
    show_kernel_information
    
    # 3. Analyze Data
    perform_security_checks
    
    # 4. Display Summary
    show_summary
    
    return 0
}

# Execute main function with all script arguments
main "$@"
