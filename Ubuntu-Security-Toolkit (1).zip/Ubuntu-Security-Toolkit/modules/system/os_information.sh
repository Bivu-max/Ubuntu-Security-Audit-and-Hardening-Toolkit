clear
#!/usr/bin/env bash
# ==============================================================================
#   MODULE: Operating System Information
#   Advanced Ubuntu Security Hardening & Audit Toolkit
# ==============================================================================
set -o pipefail

# ------------------------------------------------------------------------------
# 1. BOOTSTRAP & LIBRARY SOURCING
# ------------------------------------------------------------------------------
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"

# Source the common library; exit gracefully if not found
if [ -f "$PROJECT_ROOT/lib/common.sh" ]; then
    source "$PROJECT_ROOT/lib/common.sh"
else
    echo -e "\033[1;31m[ERROR] Cannot find lib/common.sh at $PROJECT_ROOT/lib/common.sh\033[0m"
    exit 2
fi

# ------------------------------------------------------------------------------
# 2. GLOBAL AUDIT VARIABLES
# ------------------------------------------------------------------------------
TOTAL_CHECKS=0
PASSED_CHECKS=0
WARNING_CHECKS=0
ERROR_CHECKS=0

# OS Information Variables
OS_DISTRO="Unknown"
OS_VERSION="Unknown"
OS_VERSION_ID="Unknown"
OS_CODENAME="Unknown"
OS_ARCH="Unknown"
OS_KERNEL="Unknown"
OS_HOSTNAME="Unknown"
VIRT_TYPE="Unknown"

# ------------------------------------------------------------------------------
# 3. HELPER FUNCTIONS FOR METRICS
# ------------------------------------------------------------------------------
increment_pass()  { ((TOTAL_CHECKS++)); ((PASSED_CHECKS++)); }
increment_warn()  { ((TOTAL_CHECKS++)); ((WARNING_CHECKS++)); }
increment_error() { ((TOTAL_CHECKS++)); ((ERROR_CHECKS++)); }

# ------------------------------------------------------------------------------
# 4. DATA COLLECTION
# ------------------------------------------------------------------------------
get_os_information() {
    # Parse /etc/os-release safely
    if [ -f /etc/os-release ]; then
        # shellcheck disable=SC1091
        source /etc/os-release
        OS_DISTRO="${NAME:-Unknown}"
        OS_VERSION="${VERSION:-Unknown}"
        OS_VERSION_ID="${VERSION_ID:-0}"
        OS_CODENAME="${UBUNTU_CODENAME:-${VERSION_CODENAME:-Unknown}}"
    fi

    # Hardware and Kernel Information
    if command_exists uname; then
        OS_ARCH="$(uname -m 2>/dev/null || echo "Unknown")"
        OS_KERNEL="$(uname -r 2>/dev/null || echo "Unknown")"
    fi

    # Hostname Information
    if command_exists hostname; then
        OS_HOSTNAME="$(hostname 2>/dev/null || echo "Unknown")"
    elif [ -f /etc/hostname ]; then
        OS_HOSTNAME="$(cat /etc/hostname 2>/dev/null || echo "Unknown")"
    fi

    # Virtualization Detection
    if command_exists systemd-detect-virt; then
        VIRT_TYPE="$(systemd-detect-virt 2>/dev/null || echo "None (Bare Metal)")"
        [ "$VIRT_TYPE" = "none" ] && VIRT_TYPE="None (Bare Metal)"
    else
        VIRT_TYPE="Unknown / Command Unavailable"
    fi
}

# ------------------------------------------------------------------------------
# 5. PRESENTATION
# ------------------------------------------------------------------------------
show_os_information() {
    module_header "OPERATING SYSTEM INFORMATION" "1"

    section "SYSTEM IDENTIFICATION"
    value_row "Distribution" "$OS_DISTRO"
    value_row "Version" "$OS_VERSION"
    value_row "Version ID" "$OS_VERSION_ID"
    value_row "Codename" "$OS_CODENAME"
    value_row "Architecture" "$OS_ARCH"
    value_row "Kernel" "$OS_KERNEL"
    value_row "Hostname" "$OS_HOSTNAME"
    value_row "Virtualization" "$VIRT_TYPE"
}

# ------------------------------------------------------------------------------
# 6. SECURITY ANALYSIS & CHECKS
# ------------------------------------------------------------------------------
perform_security_checks() {
    section "SECURITY-RELEVANT INFORMATION"

    # Check 1: Distribution validation
    if [[ "${OS_DISTRO,,}" == *"ubuntu"* ]]; then
        row "Operating System" "Ubuntu Linux confirmed" "ok"
        increment_pass
    else
        row "Operating System" "Non-Ubuntu system detected" "warn"
        increment_warn
    fi

    # Check 2: End-of-Life / Support Status
    # Standard LTS releases: 20.04, 22.04, 24.04, 26.04
    # Simple heuristic to flag older systems
    if [[ "$OS_VERSION_ID" != "Unknown" && "$OS_VERSION_ID" != "0" ]]; then
        # Using string comparison for version strings
        if [[ "$(printf '%s\n' "20.04" "$OS_VERSION_ID" | sort -V | head -n1)" == "$OS_VERSION_ID" && "$OS_VERSION_ID" != "20.04" ]]; then
            row "Support Status" "OS Version $OS_VERSION_ID is heavily outdated" "bad"
            increment_error
        elif [[ "$OS_VERSION_ID" == "20.04" ]]; then
            row "Support Status" "OS Version 20.04 is approaching EOL" "warn"
            increment_warn
        else
            row "Support Status" "Supported Release ($OS_VERSION_ID)" "ok"
            increment_pass
        fi
    else
        row "Support Status" "Could not determine OS version" "warn"
        increment_warn
    fi

    # Check 3: Core Security Files Existence
    local core_files=("/etc/passwd" "/etc/shadow" "/etc/group" "/etc/hosts")
    for file in "${core_files[@]}"; do
        if [ -f "$file" ]; then
            row "System File" "$file exists" "ok"
            increment_pass
        else
            row "System File" "$file is MISSING" "bad"
            increment_error
        fi
    done
}

# ------------------------------------------------------------------------------
# 7. SUMMARY
# ------------------------------------------------------------------------------
show_summary() {
    section "AUDIT SUMMARY"

    value_row "Checks Performed" "$TOTAL_CHECKS"
    value_row "Passed" "${LGREEN}${PASSED_CHECKS}${NC}"
    value_row "Warnings" "${YELLOW}${WARNING_CHECKS}${NC}"
    value_row "Errors" "${LRED}${ERROR_CHECKS}${NC}"
    
    echo

    # Overall Status Calculation
    if [ "$ERROR_CHECKS" -gt 0 ]; then
        row "Security Status" "ATTENTION REQUIRED" "bad"
        divider
        echo -e "  ${LRED}✖ Operating system audit completed with errors.${NC}"
    elif [ "$WARNING_CHECKS" -gt 0 ]; then
        row "Security Status" "REVIEW RECOMMENDED" "warn"
        divider
        echo -e "  ${YELLOW}⚠ Operating system audit completed with warnings.${NC}"
    else
        row "Security Status" "GOOD" "ok"
        divider
        echo -e "  ${LGREEN}✔ Operating system audit completed successfully.${NC}"
    fi
    
    divider
    echo
}

# ------------------------------------------------------------------------------
# 8. MAIN EXECUTION
# ------------------------------------------------------------------------------
main() {
    # 1. Collect
    get_os_information
    
    # 2. Present Info
    show_os_information
    
    # 3. Analyze
    perform_security_checks
    
    # 4. Summarize
    show_summary
    
    # Return 0 to indicate the audit successfully ran to completion
    return 0
}

# Execute main function with all script arguments
main "$@"
