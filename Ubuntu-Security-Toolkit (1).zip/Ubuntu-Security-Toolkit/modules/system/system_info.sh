#!/usr/bin/env bash

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"

source "$PROJECT_ROOT/lib/common.sh"

echo "========================================"
echo "       SYSTEM INFORMATION AUDIT"
echo "========================================"

echo "Hostname      : $(hostname)"
echo "OS            : $(. /etc/os-release && echo "$PRETTY_NAME")"
echo "Kernel        : $(uname -r)"
echo "Architecture  : $(uname -m)"
echo "Uptime        : $(uptime -p)"

if command -v systemctl >/dev/null 2>&1; then
    pass "systemctl is available"
else
    warning "systemctl is not available"
fi

print_summary
