clear
#!/usr/bin/env bash
# ==============================================================================
#   MODULE: Uptime Information
#   Advanced Ubuntu Security Hardening & Audit Toolkit
# ==============================================================================
set -o pipefail

# ------------------------------------------------------------------------------
# 1. BOOTSTRAP & LIBRARY SOURCING
# ------------------------------------------------------------------------------
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"

# Source the common library; exit gracefully if not found
if [ -f "$PROJECT_ROOT/lib/common.sh" ]; then
    source "$PROJECT_ROOT/lib/common.sh"
else
    echo -e "\033[1;31m[ERROR] Cannot find lib/common.sh at $PROJECT_ROOT/lib/common.sh\033[0m"
    exit 2
fi

# ------------------------------------------------------------------------------
# 2. GLOBAL AUDIT VARIABLES
# ------------------------------------------------------------------------------
TOTAL_CHECKS=0
PASSED_CHECKS=0
WARNING_CHECKS=0
ERROR_CHECKS=0

# Uptime & Load Variables
UP_PRETTY="Unknown"
UP_SINCE="Unknown"
UP_SECONDS=0
UP_DAYS=0
LOAD_1M="0.00"
LOAD_5M="0.00"
LOAD_15M="0.00"
CPU_CORES=1
ACTIVE_USERS=0

# ------------------------------------------------------------------------------
# 3. HELPER FUNCTIONS FOR METRICS
# ------------------------------------------------------------------------------
increment_pass()  { ((TOTAL_CHECKS++)); ((PASSED_CHECKS++)); }
increment_warn()  { ((TOTAL_CHECKS++)); ((WARNING_CHECKS++)); }
increment_error() { ((TOTAL_CHECKS++)); ((ERROR_CHECKS++)); }

# ------------------------------------------------------------------------------
# 4. DATA COLLECTION
# ------------------------------------------------------------------------------
get_uptime_information() {
    # 1. Get Uptime Strings
    if command_exists uptime; then
        UP_PRETTY="$(uptime -p 2>/dev/null || echo "Unknown")"
        UP_SINCE="$(uptime -s 2>/dev/null || echo "Unknown")"
    fi

    # 2. Get exact seconds and calculate days safely
    if [ -f /proc/uptime ]; then
        UP_SECONDS=$(awk '{print $1}' /proc/uptime 2>/dev/null)
        # Bash doesn't do floats well, so we use awk to calculate whole days
        UP_DAYS=$(awk -v sec="$UP_SECONDS" 'BEGIN { printf "%d", sec/86400 }' 2>/dev/null)
    fi

    # 3. Get Load Averages
    if [ -f /proc/loadavg ]; then
        read -r LOAD_1M LOAD_5M LOAD_15M _ < /proc/loadavg
    fi

    # 4. Get CPU Cores (for load context)
    if command_exists nproc; then
        CPU_CORES="$(nproc 2>/dev/null || echo 1)"
    fi

    # 5. Get Active Users
    if command_exists who; then
        ACTIVE_USERS="$(who 2>/dev/null | wc -l)"
    fi
}

# ------------------------------------------------------------------------------
# 5. PRESENTATION
# ------------------------------------------------------------------------------
show_uptime_information() {
    module_header "UPTIME INFORMATION AUDIT" "5"

    section "SYSTEM AVAILABILITY"
    
    value_row "Last Boot Time" "$UP_SINCE"
    value_row "Current Uptime" "$UP_PRETTY"
    value_row "Total Uptime (Days)" "$UP_DAYS days"
    
    echo
    section "PERFORMANCE & LOAD"
    
    value_row "CPU Cores Count" "$CPU_CORES"
    value_row "Load Average (1m)" "$LOAD_1M"
    value_row "Load Average (5m)" "$LOAD_5M"
    value_row "Load Average (15m)" "$LOAD_15M"
    value_row "Active User Sessions" "$ACTIVE_USERS"
}

# ------------------------------------------------------------------------------
# 6. SECURITY ANALYSIS & CHECKS
# ------------------------------------------------------------------------------
perform_security_checks() {
    section "SECURITY-RELEVANT INFORMATION"

    # Check 1: Kernel Update Pending / Uptime Duration
    # Best practice: Reboot at least monthly for kernel updates (unless Livepatch is used)
    if [ -z "$UP_DAYS" ]; then
        row "System Uptime" "Could not determine uptime duration" "warn"
        increment_warn
    elif [ "$UP_DAYS" -gt 90 ]; then
        row "System Uptime" "Uptime > 90 days. Kernel updates likely missing." "bad"
        increment_error
    elif [ "$UP_DAYS" -gt 30 ]; then
        row "System Uptime" "Uptime > 30 days. Recommend maintenance reboot." "warn"
        increment_warn
    else
        row "System Uptime" "Recent boot detected ($UP_DAYS days)" "ok"
        increment_pass
    fi

    # Check 2: Load Average / Resource Exhaustion
    # If 1-minute load is more than double the CPU cores, it signals severe congestion (potential DoS/Crypto-miner)
    local is_overloaded
    is_overloaded=$(awk -v load="$LOAD_1M" -v cores="$CPU_CORES" 'BEGIN { if (load > (cores * 2)) print 1; else print 0 }' 2>/dev/null)
    
    if [ "$is_overloaded" -eq 1 ]; then
        row "System Load" "Severe load detected! (1m load: $LOAD_1M)" "bad"
        increment_error
    else
        row "System Load" "System load is within normal parameters" "ok"
        increment_pass
    fi

    # Check 3: Active User Sessions
    # High number of concurrent sessions could indicate lateral movement or unauthorized access
    if [ "$ACTIVE_USERS" -gt 5 ]; then
        row "User Sessions" "High number of active sessions ($ACTIVE_USERS)" "warn"
        increment_warn
    else
        row "User Sessions" "Normal number of active sessions ($ACTIVE_USERS)" "ok"
        increment_pass
    fi
}

# ------------------------------------------------------------------------------
# 7. SUMMARY
# ------------------------------------------------------------------------------
show_summary() {
    section "AUDIT SUMMARY"

    value_row "Checks Performed" "$TOTAL_CHECKS"
    value_row "Passed" "${LGREEN}${PASSED_CHECKS}${NC}"
    value_row "Warnings" "${YELLOW}${WARNING_CHECKS}${NC}"
    value_row "Errors" "${LRED}${ERROR_CHECKS}${NC}"
    
    echo

    # Overall Status Calculation
    if [ "$ERROR_CHECKS" -gt 0 ]; then
        row "Security Status" "ATTENTION REQUIRED" "bad"
        divider
        echo -e "  ${LRED}✖ Uptime and load audit completed with critical findings.${NC}"
    elif [ "$WARNING_CHECKS" -gt 0 ]; then
        row "Security Status" "REVIEW RECOMMENDED" "warn"
        divider
        echo -e "  ${YELLOW}⚠ Uptime and load audit completed with warnings.${NC}"
    else
        row "Security Status" "GOOD" "ok"
        divider
        echo -e "  ${LGREEN}✔ Uptime and load audit completed successfully.${NC}"
    fi
    
    divider
    echo
}

# ------------------------------------------------------------------------------
# 8. MAIN EXECUTION
# ------------------------------------------------------------------------------
main() {
    # 1. Collect Data
    get_uptime_information
    
    # 2. Present Info
    show_uptime_information
    
    # 3. Analyze Data
    perform_security_checks
    
    # 4. Display Summary
    show_summary
    
    return 0
}

# Execute main function with all script arguments
main "$@"
