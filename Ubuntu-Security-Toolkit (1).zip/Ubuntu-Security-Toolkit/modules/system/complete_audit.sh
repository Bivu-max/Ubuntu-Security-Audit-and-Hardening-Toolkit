clear
#!/usr/bin/env bash
# ==============================================================================
#   MODULE: Complete System Audit
#   Advanced Ubuntu Security Hardening & Audit Toolkit
# ==============================================================================
set -o pipefail

# ------------------------------------------------------------------------------
# 1. BOOTSTRAP & LIBRARY SOURCING
# ------------------------------------------------------------------------------
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"

# Source the common library[cite: 4]
if [ -f "$PROJECT_ROOT/lib/common.sh" ]; then
    source "$PROJECT_ROOT/lib/common.sh"
else
    echo -e "\033[1;31m[ERROR] Cannot find lib/common.sh at $PROJECT_ROOT/lib/common.sh\033[0m"
    exit 2
fi

# ------------------------------------------------------------------------------
# 2. GLOBAL VARIABLES & COUNTERS
# ------------------------------------------------------------------------------
TOTAL_CHECKS=0
PASSED_CHECKS=0
WARNING_CHECKS=0
ERROR_CHECKS=0

# Scoring Model Base
AUDIT_SCORE=100
FINDINGS=()

# ------------------------------------------------------------------------------
# 3. HELPER FUNCTIONS
# ------------------------------------------------------------------------------
register_pass() {
    ((TOTAL_CHECKS++))
    ((PASSED_CHECKS++))
}

register_warn() {
    local msg="$1"
    local deduction="${2:-5}"
    ((TOTAL_CHECKS++))
    ((WARNING_CHECKS++))
    AUDIT_SCORE=$((AUDIT_SCORE - deduction))
    FINDINGS+=("${YELLOW}[WARNING] ${msg}${NC}")
}

register_error() {
    local msg="$1"
    local deduction="${2:-15}"
    ((TOTAL_CHECKS++))
    ((ERROR_CHECKS++))
    AUDIT_SCORE=$((AUDIT_SCORE - deduction))
    FINDINGS+=("${LRED}[ERROR] ${msg}${NC}")
}

register_info() {
    local msg="$1"
    FINDINGS+=("${LCYAN}[INFO] ${msg}${NC}")
}

# ------------------------------------------------------------------------------
# 4. DATA COLLECTION & PRESENTATION FUNCTIONS
# ------------------------------------------------------------------------------

collect_system_overview() {
    section "SYSTEM OVERVIEW"

    local os_distro="Unknown" os_version="Unknown"
    if [ -f /etc/os-release ]; then
        # shellcheck disable=SC1091
        source /etc/os-release
        os_distro="${NAME:-Unknown}"
        os_version="${VERSION:-Unknown}"
    fi

    local kernel_ver arch hostname uptime virt
    kernel_ver="$(uname -r 2>/dev/null || echo "Unknown")"
    arch="$(uname -m 2>/dev/null || echo "Unknown")"
    hostname="$(hostname 2>/dev/null || echo "Unknown")"
    
    if command_exists uptime; then
        uptime="$(uptime -p 2>/dev/null | sed 's/^up //')"
    else
        uptime="Unknown"
    fi

    if command_exists systemd-detect-virt; then
        virt="$(systemd-detect-virt 2>/dev/null || echo "Bare Metal")"
        [ "$virt" = "none" ] && virt="Bare Metal"
    else
        virt="Unknown"
    fi

    value_row "Operating System" "$os_distro"
    value_row "Version" "$os_version"
    value_row "Kernel" "$kernel_ver"
    value_row "Architecture" "$arch"
    value_row "Hostname" "$hostname"
    value_row "Virtualization" "$virt"
    value_row "Uptime" "$uptime"
    
    if [[ "${virt,,}" != "bare metal" && "${virt,,}" != "unknown" ]]; then
        register_info "System is running inside a virtual machine/container ($virt)."
    fi
}

check_security_files() {
    section "SECURITY STATUS"

    local files=("/etc/passwd" "/etc/shadow" "/etc/group" "/etc/hosts")
    local files_missing=0

    for f in "${files[@]}"; do
        if [ -f "$f" ]; then
            row "$f" "Present" "ok"
            register_pass
        else
            row "$f" "Missing!" "bad"
            register_error "Core system file missing: $f" 20
            files_missing=1
        fi
    done

    if [ "$files_missing" -eq 0 ]; then
        register_info "Core authentication files are present."
    fi
}

check_kernel_security() {
    section "KERNEL SECURITY"

    # ASLR
    if [ -f /proc/sys/kernel/randomize_va_space ]; then
        local aslr; aslr=$(cat /proc/sys/kernel/randomize_va_space)
        if [ "$aslr" -eq 2 ]; then
            row "ASLR" "Enabled (Full)" "ok"
            register_pass
            register_info "ASLR is fully enabled."
        elif [ "$aslr" -eq 1 ]; then
            row "ASLR" "Enabled (Partial)" "warn"
            register_warn "ASLR is only partially enabled." 5
        else
            row "ASLR" "Disabled!" "bad"
            register_error "ASLR memory protection is disabled." 15
        fi
    else
        row "ASLR" "Parameter unavailable" "info"
    fi

    # dmesg_restrict
    if [ -f /proc/sys/kernel/dmesg_restrict ]; then
        local dmesg; dmesg=$(cat /proc/sys/kernel/dmesg_restrict)
        if [ "$dmesg" -eq 1 ]; then
            row "dmesg Restriction" "Restricted" "ok"
            register_pass
        else
            row "dmesg Restriction" "Unrestricted" "warn"
            register_warn "dmesg (kernel logs) is readable by unprivileged users." 5
        fi
    else
        row "dmesg Restriction" "Parameter unavailable" "info"
    fi

    # kptr_restrict
    if [ -f /proc/sys/kernel/kptr_restrict ]; then
        local kptr; kptr=$(cat /proc/sys/kernel/kptr_restrict)
        if [ "$kptr" -ge 1 ]; then
            row "Kernel Pointer Restrict" "Restricted" "ok"
            register_pass
        else
            row "Kernel Pointer Restrict" "Exposed" "warn"
            register_warn "Kernel pointers are exposed to unprivileged users." 5
        fi
    else
        row "Kernel Pointer Restrict" "Parameter unavailable" "info"
    fi
    
    # unprivileged BPF
    if [ -f /proc/sys/kernel/unprivileged_bpf_disabled ]; then
        local bpf; bpf=$(cat /proc/sys/kernel/unprivileged_bpf_disabled)
        if [ "$bpf" -ge 1 ]; then
            row "Unprivileged BPF" "Restricted" "ok"
            register_pass
        else
            row "Unprivileged BPF" "Allowed" "warn"
            register_warn "Unprivileged eBPF is allowed (exploit risk)." 5
        fi
    else
        row "Unprivileged BPF" "Parameter unavailable" "info"
    fi
}

collect_resource_status() {
    section "RESOURCE STATUS"

    # CPU Load
    local load="Unknown"
    if command_exists uptime; then
        load="$(uptime | awk -F'load average:' '{print $2}' | cut -d, -f1 | xargs)"
    fi

    # Memory
    local mem_usage="Unknown" mem_avail="Unknown" swap_total="Unknown"
    if command_exists free; then
        local total_m used_m
        total_m=$(free -m | awk '/^Mem:/ {print $2}')
        used_m=$(free -m | awk '/^Mem:/ {print $3}')
        if [ "$total_m" -gt 0 ]; then
            mem_usage="$(( (used_m * 100) / total_m ))%"
        fi
        mem_avail="$(free -h | awk '/^Mem:/ {print $7}')"
        swap_total="$(free -h | awk '/^Swap:/ {print $2}')"
    fi

    # Disk
    local disk_usage="Unknown" disk_pct=0
    if command_exists df; then
        disk_usage="$(df -h / 2>/dev/null | awk 'NR==2 {print $5}')"
        disk_pct="${disk_usage%\%}"
    fi

    value_row "CPU Load (1m)" "$load"
    value_row "Memory Usage" "$mem_usage"
    value_row "Available Memory" "$mem_avail"
    value_row "Swap Configured" "$swap_total"
    value_row "Root Disk Usage" "$disk_usage"

    # Resource Checks
    if [[ "$disk_pct" =~ ^[0-9]+$ ]]; then
        if [ "$disk_pct" -gt 90 ]; then
            register_error "Root filesystem usage is critically high ($disk_usage)." 10
        elif [ "$disk_pct" -gt 80 ]; then
            register_warn "Root filesystem usage is high ($disk_usage)." 5
        else
            register_pass
        fi
    fi

    if [[ "$swap_total" == "0B" || "$swap_total" == "0" ]]; then
        register_warn "Swap is not configured (Memory exhaustion risk)." 2
    else
        register_pass
    fi
}

check_service_health() {
    section "SERVICE HEALTH"

    if ! command_exists systemctl; then
        row "Systemd" "Command unavailable" "bad"
        return
    fi

    local active_svcs enabled_svcs failed_svcs failed_list
    active_svcs=$(systemctl list-units --type=service --state=active --no-legend 2>/dev/null | wc -l)
    enabled_svcs=$(systemctl list-unit-files --type=service --state=enabled --no-legend 2>/dev/null | wc -l)
    failed_svcs=$(systemctl list-units --type=service --state=failed --no-legend 2>/dev/null | wc -l)
    
    value_row "Active Services" "$active_svcs"
    value_row "Enabled Services" "$enabled_svcs"
    
    if [ "$failed_svcs" -eq 0 ]; then
        value_row "Failed Services" "${LGREEN}0${NC}"
        register_pass
        register_info "No failed systemd services detected."
    else
        value_row "Failed Services" "${LRED}$failed_svcs${NC}"
        echo
        echo -e "  ${LRED}▶ Failed Services List:${NC}"
        
        failed_list=$(systemctl list-units --type=service --state=failed --no-legend 2>/dev/null | awk '{print $1}' | head -n 5)
        for srv in $failed_list; do
            echo -e "  ${WHITE}- $srv${NC}"
        done
        
        [ "$failed_svcs" -gt 5 ] && echo -e "  ${DIM}...and $((failed_svcs - 5)) more${NC}"
        
        register_error "$failed_svcs system service(s) failed." 10
    fi
}

check_network_exposure() {
    section "NETWORK EXPOSURE"

    local interfaces="Unknown" tcp_listen="Unknown" udp_listen="Unknown"
    if command_exists ip; then
        interfaces=$(ip link show up 2>/dev/null | grep -c '^[0-9]')
    fi

    if command_exists ss; then
        tcp_listen=$(ss -tln 2>/dev/null | tail -n +2 | wc -l)
        udp_listen=$(ss -uln 2>/dev/null | tail -n +2 | wc -l)
        
        value_row "Active Interfaces" "$interfaces"
        value_row "Listening TCP Ports" "$tcp_listen"
        value_row "Listening UDP Ports" "$udp_listen"

        # Check for non-localhost exposed services
        if ss -tln 2>/dev/null | grep -qE '(0\.0\.0\.0|\[::\]):'; then
            register_warn "Services are bound to all interfaces (0.0.0.0 or ::). Review external exposure." 5
        else
            register_pass
        fi
    else
        row "Network Tool" "ss command unavailable" "warn"
    fi
}

generate_findings() {
    section "IMPORTANT FINDINGS"

    if [ ${#FINDINGS[@]} -eq 0 ]; then
        echo -e "  ${LGREEN}✔ No significant security warnings or errors detected.${NC}"
        return
    fi

    for finding in "${FINDINGS[@]}"; do
        echo -e "  $finding"
    done
}

show_audit_summary() {
    section "AUDIT SUMMARY"

    # Enforce score boundaries
    [ "$AUDIT_SCORE" -lt 0 ] && AUDIT_SCORE=0
    [ "$AUDIT_SCORE" -gt 100 ] && AUDIT_SCORE=100

    # Determine status text and color
    local status_text color
    if [ "$ERROR_CHECKS" -gt 0 ] || [ "$AUDIT_SCORE" -lt 60 ]; then
        status_text="CRITICAL"
        color="$LRED"
    elif [ "$WARNING_CHECKS" -gt 3 ] || [ "$AUDIT_SCORE" -lt 80 ]; then
        status_text="ATTENTION REQUIRED"
        color="$YELLOW"
    elif [ "$WARNING_CHECKS" -gt 0 ]; then
        status_text="REVIEW RECOMMENDED"
        color="$YELLOW"
    else
        status_text="GOOD"
        color="$LGREEN"
    fi

    value_row "Checks Performed" "$TOTAL_CHECKS"
    value_row "Passed" "${LGREEN}${PASSED_CHECKS}${NC}"
    value_row "Warnings" "${YELLOW}${WARNING_CHECKS}${NC}"
    value_row "Errors" "${LRED}${ERROR_CHECKS}${NC}"
    
    echo
    value_row "Toolkit Assessment" "${color}${AUDIT_SCORE} / 100${NC}"
    row "Overall Status" "${color}${status_text}${NC}" "info"

    divider
    if [[ "$status_text" == "GOOD" ]]; then
        echo -e "  ${LGREEN}✔ Complete system audit finished with excellent results.${NC}"
    else
        echo -e "  ${color}▶ Complete system audit finished. See findings above.${NC}"
    fi
    divider
    echo
}

# ------------------------------------------------------------------------------
# 5. MAIN EXECUTION
# ------------------------------------------------------------------------------
main() {
    # Custom Banner for Complete Audit[cite: 4]
    echo
    echo -e "${BLUE}${BOLD}"
    echo "  ╔══════════════════════════════════════════════════════════════════════╗"
    echo "  ║              ADVANCED UBUNTU SECURITY HARDENING & AUDIT TOOLKIT      ║"
    echo "  ║                         COMPLETE SYSTEM AUDIT                        ║"
    echo "  ╚══════════════════════════════════════════════════════════════════════╝"
    echo -e "${NC}"

    collect_system_overview
    check_security_files
    check_kernel_security
    collect_resource_status
    check_service_health
    check_network_exposure
    generate_findings
    show_audit_summary

    return 0
}

# Execute main function with all script arguments
main "$@"
