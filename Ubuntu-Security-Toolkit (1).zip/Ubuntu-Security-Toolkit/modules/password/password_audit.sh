#!/bin/bash

# ==========================================
# UBUNTU PASSWORD SECURITY AUDIT
# ==========================================

PROJECT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"

source "$PROJECT_ROOT/lib/common.sh"

echo "=========================================="
echo "       PASSWORD SECURITY AUDIT"
echo "=========================================="

# 1. Check password policy configuration

echo ""
echo "1. Checking Password Policy"

LOGIN_FILE="/etc/login.defs"

if [ -f "$LOGIN_FILE" ]; then

    pass "Password policy file exists"

    MIN_LENGTH=$(awk '$1 == "PASS_MIN_LEN" {value=$2} END {print value}' "$LOGIN_FILE")
    MAX_DAYS=$(awk '$1 == "PASS_MAX_DAYS" {value=$2} END {print value}' "$LOGIN_FILE")
    MIN_DAYS=$(awk '$1 == "PASS_MIN_DAYS" {value=$2} END {print value}' "$LOGIN_FILE")
    WARN_AGE=$(awk '$1 == "PASS_WARN_AGE" {value=$2} END {print value}' "$LOGIN_FILE")

    echo "Minimum Password Length: ${MIN_LENGTH:-Not configured}"
    echo "Maximum Password Age: ${MAX_DAYS:-Not configured} days"
    echo "Minimum Password Age: ${MIN_DAYS:-Not configured} days"
    echo "Password Warning Period: ${WARN_AGE:-Not configured} days"

    if [[ "$MIN_LENGTH" =~ ^[0-9]+$ ]]; then
        if [ "$MIN_LENGTH" -ge 12 ]; then
            pass "Minimum password length is 12 or more"
        else
            warning "Minimum password length is below 12"
        fi
    else
        warning "Minimum password length is not configured"
    fi

    if [[ "$MAX_DAYS" =~ ^[0-9]+$ ]]; then
        if [ "$MAX_DAYS" -gt 0 ] && [ "$MAX_DAYS" -le 365 ]; then
            pass "Maximum password age is within the audit threshold"
        else
            warning "Review maximum password age"
        fi
    else
        warning "Maximum password age is not configured"
    fi

else
    error "Password policy file is missing"
fi

# 2. Check password aging information

echo ""
echo "2. Checking User Password Aging"

while IFS=: read -r USER_NAME _ UID_VALUE _ _ _ SHELL_VALUE
do

    # Skip system accounts and accounts without login shells
    if [ "$UID_VALUE" -lt 1000 ] 2>/dev/null; then
        continue
    fi

    if [[ "$SHELL_VALUE" == */nologin || "$SHELL_VALUE" == */false ]]; then
        continue
    fi

    echo ""
    echo "User: $USER_NAME"

    if AGE_INFO=$(sudo chage -l "$USER_NAME" 2>/dev/null); then

        LAST_CHANGE=$(printf '%s\n' "$AGE_INFO" | grep "^Last password change")
        MAX_AGE=$(printf '%s\n' "$AGE_INFO" | grep "^Maximum number of days between password change")
        INACTIVE=$(printf '%s\n' "$AGE_INFO" | grep "^Password inactive")
        EXPIRY=$(printf '%s\n' "$AGE_INFO" | grep "^Password expires")

        echo "$LAST_CHANGE"
        echo "$MAX_AGE"
        echo "$INACTIVE"
        echo "$EXPIRY"

        if [[ "$EXPIRY" == *"never"* ]]; then
            warning "$USER_NAME has no password expiry date"
        elif [[ -n "$EXPIRY" ]]; then
            pass "Password expiry information is configured for $USER_NAME"
        fi

    else
        warning "Could not read password aging information for $USER_NAME"
    fi

done < /etc/passwd

# 3. Check password aging configuration availability

echo ""
echo "3. Checking Password Aging Database"

if [ -r /etc/shadow ]; then
    pass "Password aging database is accessible"
else
    warning "Password aging database requires additional privileges"
fi

# 4. Final summary

echo ""
print_summary

echo ""
echo "=========================================="
echo " PASSWORD SECURITY AUDIT COMPLETED"
echo "=========================================="
