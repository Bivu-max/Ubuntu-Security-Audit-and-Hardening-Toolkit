
#!/bin/bash

# ==========================================
# UBUNTU SERVICE SECURITY AUDIT
# ==========================================

PROJECT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"

source "$PROJECT_ROOT/lib/common.sh"

echo "=========================================="
echo "         SERVICE SECURITY AUDIT"
echo "=========================================="

# 1. Check systemd availability

echo ""
echo "1. Checking Service Manager"

if ! command -v systemctl >/dev/null 2>&1; then
    error "systemctl is unavailable"
    print_summary
    exit 1
fi

pass "systemd service manager is available"

# 2. Check running services

echo ""
echo "2. Checking Running Services"

RUNNING_COUNT=$(systemctl list-units \
    --type=service --state=running --no-legend --no-pager | wc -l)

echo "Running Services: $RUNNING_COUNT"

systemctl list-units \
    --type=service --state=running --no-pager

if [ "$RUNNING_COUNT" -gt 0 ]; then
    pass "Running services retrieved"
else
    warning "No running services detected"
fi

# 3. Check enabled services

echo ""
echo "3. Checking Enabled Services"

ENABLED_COUNT=$(systemctl list-unit-files \
    --type=service --state=enabled --no-legend --no-pager | wc -l)

echo "Enabled Services: $ENABLED_COUNT"

systemctl list-unit-files \
    --type=service --state=enabled --no-pager

pass "Enabled service information collected"

# 4. Check failed services

echo ""
echo "4. Checking Failed Services"

FAILED_SERVICES=$(systemctl --failed \
    --type=service --no-legend --no-pager)

if [ -z "$FAILED_SERVICES" ]; then
    pass "No failed services detected"
else
    echo "$FAILED_SERVICES"
    warning "Failed services require investigation"
fi

# 5. Check important security-related services

echo ""
echo "5. Checking Important Security Services"

IMPORTANT_SERVICES=(
    "ssh"
    "ufw"
    "fail2ban"
    "apparmor"
)

for SERVICE in "${IMPORTANT_SERVICES[@]}"
do

    echo ""
    echo "Checking: $SERVICE"

    if ! systemctl list-unit-files "${SERVICE}.service" \
        --no-legend --no-pager | grep -q "${SERVICE}.service"; then

        echo "$SERVICE service is not installed"
        continue
    fi

    SERVICE_STATE=$(systemctl is-active "$SERVICE" 2>/dev/null || true)

    echo "Status: $SERVICE_STATE"

    if [ "$SERVICE_STATE" = "active" ]; then
        pass "$SERVICE service is active"
    else
        warning "$SERVICE service is not active"
    fi

done

# 6. Check network listening services

echo ""
echo "6. Checking Services Listening on Network Ports"

if command -v ss >/dev/null 2>&1; then

    ss -tulnp

    pass "Network listening service information collected"

else
    warning "ss command is unavailable"
fi

# 7. Final summary

echo ""
print_summary

echo ""
echo "=========================================="
echo " SERVICE SECURITY AUDIT COMPLETED"
echo "=========================================="
