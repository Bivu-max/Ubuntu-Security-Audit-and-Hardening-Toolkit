
#!/bin/bash

# ==========================================
# UBUNTU PACKAGE SECURITY AUDIT
# ==========================================

PROJECT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"

source "$PROJECT_ROOT/lib/common.sh"

echo "=========================================="
echo "         PACKAGE SECURITY AUDIT"
echo "=========================================="

# 1. Check APT availability

echo ""
echo "1. Checking APT Package Manager"

if ! command -v apt >/dev/null 2>&1; then
    error "APT package manager is unavailable"
    print_summary
    exit 1
fi

pass "APT package manager is available"

# 2. Check installed package count

echo ""
echo "2. Checking Installed Packages"

INSTALLED_COUNT=$(dpkg-query -f='${binary:Package}\n' -W 2>/dev/null | wc -l)

echo "Installed Packages: $INSTALLED_COUNT"

if [ "$INSTALLED_COUNT" -gt 0 ]; then
    pass "Installed package information retrieved"
else
    warning "Could not retrieve installed package information"
fi

# 3. Check package repository configuration

echo ""
echo "3. Checking Package Repositories"

REPO_COUNT=$(
    grep -hE '^[[:space:]]*(deb |deb-src |URIs:)' \
    /etc/apt/sources.list /etc/apt/sources.list.d/*.list \
    /etc/apt/sources.list.d/*.sources 2>/dev/null | wc -l
)

echo "Configured repository entries: $REPO_COUNT"

if [ "$REPO_COUNT" -gt 0 ]; then
    pass "Package repository configuration detected"
else
    warning "No active package repository entries detected"
fi

# 4. Check whether package lists are available

echo ""
echo "4. Checking APT Package Lists"

if [ -d /var/lib/apt/lists ] &&
   find /var/lib/apt/lists -maxdepth 1 -type f \
   -name '*Packages*' -print -quit | grep -q .; then

    pass "APT package lists are available"

else
    warning "APT package lists are missing or empty"
    echo "Run sudo apt update before performing the audit."
fi

# 5. Check available updates

echo ""
echo "5. Checking Available Package Updates"

UPGRADE_OUTPUT=$(apt list --upgradable 2>/dev/null)

UPGRADE_COUNT=$(printf '%s\n' "$UPGRADE_OUTPUT" |
    tail -n +2 | grep -c .)

echo "Available Updates: $UPGRADE_COUNT"

if [ "$UPGRADE_COUNT" -gt 0 ]; then
    warning "$UPGRADE_COUNT package update(s) are available"

    echo ""
    echo "Packages requiring updates:"
    printf '%s\n' "$UPGRADE_OUTPUT" | tail -n +2

else
    pass "No package updates are currently listed"
fi

# 6. Check held packages

echo ""
echo "6. Checking Held Packages"

HELD_PACKAGES=$(apt-mark showhold 2>/dev/null)

if [ -z "$HELD_PACKAGES" ]; then
    pass "No held packages detected"
else
    echo "$HELD_PACKAGES"
    warning "Held packages require review"
fi

# 7. Check security update information

echo ""
echo "7. Checking Security Update Information"

if command -v unattended-upgrade >/dev/null 2>&1; then

    echo "Unattended-upgrades is installed"

    if systemctl is-enabled --quiet unattended-upgrades 2>/dev/null; then
        pass "Automatic update service is enabled"
    else
        warning "Automatic update service is not enabled"
    fi

else
    warning "Unattended-upgrades utility is not installed"
fi

echo ""
echo "Note: Available updates are not necessarily security updates."
echo "Security classification requires repository metadata."

# 8. Final summary

echo ""
print_summary

echo ""
echo "=========================================="
echo " PACKAGE SECURITY AUDIT COMPLETED"
echo "=========================================="
