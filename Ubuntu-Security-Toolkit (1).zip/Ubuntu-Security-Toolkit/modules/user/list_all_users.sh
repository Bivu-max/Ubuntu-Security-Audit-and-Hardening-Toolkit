clear
#!/usr/bin/env bash
# ==============================================================================
#   MODULE: List All Users
#   Advanced Ubuntu Security Toolkit
#   Purpose: Audit and display all configured user accounts on the system.
# ==============================================================================

set -o pipefail

# ------------------------------------------------------------------------------
# 1. BOOTSTRAP & LIBRARY SOURCING
# ------------------------------------------------------------------------------
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" >/dev/null 2>&1 && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/../.." >/dev/null 2>&1 && pwd)"

if [ -f "$PROJECT_ROOT/lib/common.sh" ]; then
    source "$PROJECT_ROOT/lib/common.sh"
else
    printf '\033[1;31m✖ ERROR: Cannot find lib/common.sh\033[0m\n'
    exit 1
fi

# Define missing/mapped colors required by prompt specification
RESET="${NC}"
LIGHT_RED="${LRED}"
LIGHT_GREEN="${LGREEN}"

# ------------------------------------------------------------------------------
# 2. LOCAL FUNCTION OVERRIDES
# ------------------------------------------------------------------------------
# Override to satisfy the strict MODULE 1 / 7 requirement
module_header() {
    local module_name="$1"
    local module_number="$2"

    echo
    echo -e "${BLUE}${BOLD}"
    echo "  ╔══════════════════════════════════════════════════════════════════════╗"
    echo "  ║                                                                      ║"
    printf "  ║%*s%s%*s║\n" \
        $(( (68 - ${#module_name}) / 2 )) "" \
        "$module_name" \
        $(( 68 - ${#module_name} - (68 - ${#module_name}) / 2 )) ""
    echo "  ║                                                                      ║"
    printf "  ║%*sMODULE %s / 7%*s║\n" \
        $(( (68 - 12) / 2 )) "" \
        "$module_number" \
        $(( 68 - 12 - (68 - 12) / 2 )) ""
    echo "  ╚══════════════════════════════════════════════════════════════════════╝"
    echo -e "${RESET}"
}

# ------------------------------------------------------------------------------
# 3. GLOBAL AUDIT VARIABLES
# ------------------------------------------------------------------------------
TOTAL_USERS=0
HUMAN_USERS=0
SYSTEM_USERS=0
LOCKED_USERS=0
LOGIN_USERS=0

CHECKS_PERFORMED=0
PASSED_CHECKS=0
WARNINGS=0
ERRORS=0

# ------------------------------------------------------------------------------
# 4. HELPER FUNCTIONS
# ------------------------------------------------------------------------------
is_valid_shell() {
    local shell_path="$1"
    case "$shell_path" in
        */nologin|*/false|*/sync|*/halt|*/shutdown|"") return 1 ;;
        *) return 0 ;;
    esac
}

increment_pass()  { ((CHECKS_PERFORMED++)); ((PASSED_CHECKS++)); }
increment_warn()  { ((CHECKS_PERFORMED++)); ((WARNINGS++)); }
increment_error() { ((CHECKS_PERFORMED++)); ((ERRORS++)); }

# ------------------------------------------------------------------------------
# 5. DATA COLLECTION
# ------------------------------------------------------------------------------
collect_user_data() {
    if [ ! -r /etc/passwd ]; then
        echo -e "  ${LIGHT_RED}✖ CRITICAL: Cannot read /etc/passwd!${RESET}"
        exit 1
    fi

    while IFS=: read -r user pass uid gid info home shell; do
        ((TOTAL_USERS++))

        # Categorize User Type
        if [ "$uid" -eq 0 ] || ([ "$uid" -ge 1000 ] && [ "$uid" -lt 65534 ]); then
            ((HUMAN_USERS++))
        else
            ((SYSTEM_USERS++))
        fi

        # Categorize Login Shell
        if is_valid_shell "$shell"; then
            ((LOGIN_USERS++))
        fi

        # Check Locked Status (Requires Root)
        if [ "$EUID" -eq 0 ] && [ -r /etc/shadow ]; then
            local shadow_val
            shadow_val=$(awk -F: -v u="$user" '$1==u {print $2}' /etc/shadow 2>/dev/null)
            if [[ "$shadow_val" == "!"* ]] || [[ "$shadow_val" == "*"* ]] || [[ -z "$shadow_val" ]]; then
                ((LOCKED_USERS++))
            fi
        fi
    done < /etc/passwd
}

# ------------------------------------------------------------------------------
# 6. DATA PRESENTATION
# ------------------------------------------------------------------------------
display_user_summary() {
    module_header "USER ACCOUNT AUDIT" "1"

    section "USER ACCOUNT SUMMARY"
    
    value_row "Total Users" "$TOTAL_USERS"
    value_row "Human & Root Users" "$HUMAN_USERS"
    value_row "System Users" "$SYSTEM_USERS"
    
    if [ "$EUID" -eq 0 ]; then
        value_row "Locked Accounts" "$LOCKED_USERS"
    else
        value_row "Locked Accounts" "${YELLOW}Unknown (Requires Root)${RESET}"
    fi
    
    value_row "Login Shell Accounts" "$LOGIN_USERS"
}

display_user_tables() {
    section "HUMAN & ROOT ACCOUNTS (UID >= 1000 or UID 0)"
    printf "  ${LCYAN}%-16s %-5s %-8s %-16s %-18s${RESET}\n" "USER" "UID" "STATUS" "SHELL" "HOME"
    echo -e "  ${DIM}${SHORT_LINE}──────────────────────${RESET}"

    while IFS=: read -r user pass uid gid info home shell; do
        if [ "$uid" -eq 0 ] || ([ "$uid" -ge 1000 ] && [ "$uid" -lt 65534 ]); then
            local status="Unknown"
            local status_color="${WHITE}"
            
            if [ "$EUID" -eq 0 ] && [ -r /etc/shadow ]; then
                local shadow_val
                shadow_val=$(awk -F: -v u="$user" '$1==u {print $2}' /etc/shadow 2>/dev/null)
                if [[ "$shadow_val" == "!"* ]] || [[ "$shadow_val" == "*"* ]] || [[ -z "$shadow_val" ]]; then
                    status="Locked"
                    status_color="${DIM}"
                else
                    status="Active"
                    status_color="${LIGHT_GREEN}"
                fi
            fi

            printf "  ${WHITE}%-16s${RESET} %-5s ${status_color}%-8s${RESET} %-16s %-18s\n" \
                "${user:0:15}" "$uid" "$status" "${shell:0:15}" "${home:0:18}"
        fi
    done < /etc/passwd

    section "SYSTEM ACCOUNTS (UID < 1000 or UID 65534)"
    printf "  ${LCYAN}%-16s %-5s %-8s %-16s %-18s${RESET}\n" "USER" "UID" "STATUS" "SHELL" "HOME"
    echo -e "  ${DIM}${SHORT_LINE}──────────────────────${RESET}"

    while IFS=: read -r user pass uid gid info home shell; do
        if ([ "$uid" -gt 0 ] && [ "$uid" -lt 1000 ]) || [ "$uid" -eq 65534 ]; then
            local status="Unknown"
            local status_color="${WHITE}"
            
            if [ "$EUID" -eq 0 ] && [ -r /etc/shadow ]; then
                local shadow_val
                shadow_val=$(awk -F: -v u="$user" '$1==u {print $2}' /etc/shadow 2>/dev/null)
                if [[ "$shadow_val" == "!"* ]] || [[ "$shadow_val" == "*"* ]] || [[ -z "$shadow_val" ]]; then
                    status="Locked"
                    status_color="${DIM}"
                else
                    status="Active"
                    status_color="${YELLOW}"
                fi
            fi

            printf "  ${WHITE}%-16s${RESET} %-5s ${status_color}%-8s${RESET} %-16s %-18s\n" \
                "${user:0:15}" "$uid" "$status" "${shell:0:15}" "${home:0:18}"
        fi
    done < /etc/passwd
}

# ------------------------------------------------------------------------------
# 7. SECURITY ASSESSMENT
# ------------------------------------------------------------------------------
perform_security_checks() {
    section "SECURITY ASSESSMENT"

    # Check 1: Root privilege level
    if [ "$EUID" -ne 0 ]; then
        row "Privilege Level" "Run as root for full shadow visibility" "warn"
        increment_warn
    else
        row "Privilege Level" "Root privileges detected" "ok"
        increment_pass
    fi

    # Check 2: UID 0 Accounts (Rogue root accounts)
    local uid0_users
    uid0_users=$(awk -F: '$3 == 0 {print $1}' /etc/passwd 2>/dev/null)
    local uid0_count
    uid0_count=$(echo "$uid0_users" | wc -w)
    
    if [ "$uid0_count" -gt 1 ]; then
        row "UID 0 Accounts" "Multiple root accounts found!" "bad"
        echo -e "  ${LIGHT_RED}▶ Rogue root users: $(echo "$uid0_users" | tr '\n' ' ')${RESET}"
        increment_error
    else
        row "UID 0 Accounts" "Only expected root has UID 0" "ok"
        increment_pass
    fi

    # Check 3: System accounts with active login shells
    local system_logins
    system_logins=$(awk -F: '$3 > 0 && $3 < 1000 && $7 !~ /(nologin|false|sync|halt|shutdown)$/ {print $1}' /etc/passwd 2>/dev/null)
    if [ -n "$system_logins" ]; then
        local sys_logins_count
        sys_logins_count=$(echo "$system_logins" | wc -w)
        row "System Logins" "$sys_logins_count system account(s) can login" "warn"
        echo -e "  ${YELLOW}▶ Review system accounts: $(echo "$system_logins" | tr '\n' ' ')${RESET}"
        increment_warn
    else
        row "System Logins" "No unprotected system shells" "ok"
        increment_pass
    fi
}

# ------------------------------------------------------------------------------
# 8. AUDIT SUMMARY & COMPLETION
# ------------------------------------------------------------------------------
show_audit_summary() {
    section "AUDIT SUMMARY"

    value_row "Checks Performed" "$CHECKS_PERFORMED"
    value_row "Passed" "${LIGHT_GREEN}${PASSED_CHECKS}${RESET}"
    value_row "Warnings" "${YELLOW}${WARNINGS}${RESET}"
    value_row "Errors" "${LIGHT_RED}${ERRORS}${RESET}"
    
    echo

    if [ "$ERRORS" -gt 0 ]; then
        value_row "Security Status" "${LIGHT_RED}✖ ACTION REQUIRED${RESET}"
    elif [ "$WARNINGS" -gt 0 ]; then
        value_row "Security Status" "${YELLOW}⚠ REVIEW RECOMMENDED${RESET}"
    else
        value_row "Security Status" "${LIGHT_GREEN}✔ SECURE${RESET}"
    fi

    echo
    echo -e "  ${DIM}${LINE}${RESET}"
    echo -e "  ${LIGHT_GREEN}[SUCCESS] Module completed successfully.${RESET}"
    echo -e "  ${DIM}${LINE}${RESET}"
    echo
}

# ------------------------------------------------------------------------------
# 9. MAIN EXECUTION CONTROLLER
# ------------------------------------------------------------------------------
main() {
    collect_user_data
    display_user_summary
    display_user_tables
    perform_security_checks
    show_audit_summary
    return 0
}

main "$@"
