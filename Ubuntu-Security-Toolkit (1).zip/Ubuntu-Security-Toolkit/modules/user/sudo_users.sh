clear
#!/usr/bin/env bash
# ==============================================================================
#   MODULE: Sudo Users
#   Advanced Ubuntu Security Toolkit
#   Purpose: Identify users who have sudo or administrative privileges.
#            Audit privileged access and detect authorized elevated accounts.
# ==============================================================================

set -o pipefail

# ------------------------------------------------------------------------------
# 1. BOOTSTRAP & LIBRARY SOURCING
# ------------------------------------------------------------------------------
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" >/dev/null 2>&1 && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/../.." >/dev/null 2>&1 && pwd)"

# Fallback basic colors if common.sh doesn't load them properly
RESET='\033[0m'
RED='\033[0;31m'
LIGHT_RED='\033[1;31m'
GREEN='\033[0;32m'
LIGHT_GREEN='\033[1;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
LCYAN='\033[1;36m'
CYAN='\033[0;36m'
MAGENTA='\033[1;35m'
WHITE='\033[1;37m'
BOLD='\033[1m'
DIM='\033[2m'
LINE="──────────────────────────────────────────────────────────────────────"
SHORT_LINE="────────────────────────────────────────────────"

if [ -f "$PROJECT_ROOT/lib/common.sh" ]; then
    # shellcheck source=/dev/null
    source "$PROJECT_ROOT/lib/common.sh"
    # Map common.sh colors to required local names if they exist
    [ -n "$NC" ] && RESET="$NC"
    [ -n "$LRED" ] && LIGHT_RED="$LRED"
    [ -n "$LGREEN" ] && LIGHT_GREEN="$LGREEN"
else
    printf "${LIGHT_RED}✖ WARNING: Cannot find lib/common.sh. Using fallback formatting.${RESET}\n"
fi

# ------------------------------------------------------------------------------
# 2. LOCAL FUNCTION OVERRIDES (Ensuring structural consistency)
# ------------------------------------------------------------------------------
# Override to satisfy the strict MODULE 7 / 7 requirement
module_header() {
    local module_name="$1"
    local module_number="$2"

    echo
    echo -e "${BLUE}${BOLD}  ╔══════════════════════════════════════════════════════════════════════╗${RESET}"
    echo -e "${BLUE}${BOLD}  ║                                                                      ║${RESET}"
    printf "${BLUE}${BOLD}  ║%*s%s%*s║${RESET}\n" \
        $(( (68 - ${#module_name}) / 2 )) "" \
        "$module_name" \
        $(( 68 - ${#module_name} - (68 - ${#module_name}) / 2 )) ""
    echo -e "${BLUE}${BOLD}  ║                                                                      ║${RESET}"
    printf "${BLUE}${BOLD}  ║%*sMODULE %s / 7%*s║${RESET}\n" \
        $(( (68 - 12) / 2 )) "" \
        "$module_number" \

        $(( 68 - 12 - (68 - 12) / 2 )) ""
    echo -e "${BLUE}${BOLD}  ╚══════════════════════════════════════════════════════════════════════╝${RESET}"
    echo
}

# Provide local fallbacks for formatting functions in case common.sh is incomplete
section() {
    local title="$1"
    echo -e "  ${LCYAN}${BOLD}${title}${RESET}"
    echo -e "  ${DIM}${LINE}${RESET}"
}

value_row() {
    local label="$1"
    local value="$2"
    printf "  ${WHITE}%-32s${RESET} : ${CYAN}%s${RESET}\n" "$label" "$value"
}

row() {
    local label="$1"
    local value="$2"
    local status="${3:-info}"
    local colour icon

    case "$status" in
        ok)   colour="${LIGHT_GREEN}"; icon="✔" ;;
        warn) colour="${YELLOW}";      icon="⚠" ;;
        bad)  colour="${LIGHT_RED}";   icon="✖" ;;
        *)    colour="${LCYAN}";       icon="ℹ" ;;
    esac

    printf "  ${WHITE}%-32s${RESET} ${colour}%s  %s${RESET}\n" "$label" "$icon" "$value"
}

increment_pass()  { ((CHECKS_PERFORMED++)); ((PASSED_CHECKS++)); }
increment_warn()  { ((CHECKS_PERFORMED++)); ((WARNINGS++)); }
increment_error() { ((CHECKS_PERFORMED++)); ((ERRORS++)); }

# ------------------------------------------------------------------------------
# 3. GLOBAL AUDIT VARIABLES
# ------------------------------------------------------------------------------
TOTAL_SUDO_USERS=0
SUDO_GROUP_NAME="Unknown"
SUDO_GROUP_EXISTS=0

SUDO_USERS_LIST=()
SUDO_DIR_ISSUES=()

CHECKS_PERFORMED=0
PASSED_CHECKS=0
WARNINGS=0
ERRORS=0

# ------------------------------------------------------------------------------
# 4. DATA COLLECTION
# ------------------------------------------------------------------------------
collect_sudo_data() {
    # 1. Identify the default sudo group on this system (usually 'sudo' on Ubuntu, 'wheel' on Debian/CentOS)
    if grep -q "^sudo:" /etc/group; then
        SUDO_GROUP_NAME="sudo"
        SUDO_GROUP_EXISTS=1
    elif grep -q "^wheel:" /etc/group; then
        SUDO_GROUP_NAME="wheel"
        SUDO_GROUP_EXISTS=1
    else
        SUDO_GROUP_NAME="None Found"
        SUDO_GROUP_EXISTS=0
    fi

    # 2. Collect users in the primary sudo group
    if [ "$SUDO_GROUP_EXISTS" -eq 1 ]; then
        local group_users
        group_users=$(grep "^${SUDO_GROUP_NAME}:" /etc/group | awk -F: '{print $4}' | tr ',' '\n')
        
        for u in $group_users; do
            if [[ -n "$u" ]]; then
                SUDO_USERS_LIST+=("$u:Group Member")
                ((TOTAL_SUDO_USERS++))
            fi
        done
    fi

    # 3. Audit sudoers files for explicit user definitions (Requires Root)
    if [ "$EUID" -eq 0 ]; then
        # Check main /etc/sudoers (ignoring comments, empty lines, and group aliases)
        if [ -f /etc/sudoers ]; then
            local explicit_users
            explicit_users=$(grep -E "^[a-zA-Z0-9_-]+[[:space:]]+ALL=" /etc/sudoers | awk '{print $1}')

            for u in $explicit_users; do
                if [[ "$u" != "root" ]]; then
                    # Check if already counted via group
                    local already_added=0
                    for existing in "${SUDO_USERS_LIST[@]}"; do
                        if [[ "${existing%%:*}" == "$u" ]]; then
                            already_added=1
                            break
                        fi
                    done
                    if [ "$already_added" -eq 0 ]; then
                        SUDO_USERS_LIST+=("$u:Explicit (/etc/sudoers)")
                        ((TOTAL_SUDO_USERS++))
                    fi
                fi
            done
        fi

        # Check /etc/sudoers.d/ drop-in directory
        if [ -d /etc/sudoers.d ]; then
            for f in /etc/sudoers.d/*; do
                if [ -f "$f" ] && [[ "$f" != *~ ]] && [[ "$f" != *.* ]]; then
                    # Basic syntax check for explicit definitions in drop-ins
                    local dropin_users
                    dropin_users=$(grep -E "^[a-zA-Z0-9_-]+[[:space:]]+ALL=" "$f" 2>/dev/null | awk '{print $1}')
                    for u in $dropin_users; do
                        if [[ "$u" != "root" ]]; then
                            # Add if not already counted
                            local already_added=0
                            for existing in "${SUDO_USERS_LIST[@]}"; do
                                if [[ "${existing%%:*}" == "$u" ]]; then
                                    already_added=1
                                    break
                                fi
                            done
                            if [ "$already_added" -eq 0 ]; then
                                SUDO_USERS_LIST+=("$u:Drop-in ($(basename "$f"))")
                                ((TOTAL_SUDO_USERS++))
                            fi
                        fi
                    done
                fi
            done
        fi
        
        # Check permissions on sudoers.d drop-ins
        if [ -d /etc/sudoers.d ]; then
            for f in /etc/sudoers.d/*; do
                if [ -f "$f" ]; then
                    local perms owner
                    perms=$(stat -c "%a" "$f")
                    owner=$(stat -c "%U:%G" "$f")
                    if [[ "$perms" != "440" ]] || [[ "$owner" != "root:root" ]]; then
                        SUDO_DIR_ISSUES+=("$(basename "$f") ($perms, $owner)")
                    fi
                fi
            done
        fi
    fi
}

# ------------------------------------------------------------------------------
# 5. DATA PRESENTATION
# ------------------------------------------------------------------------------
display_sudo_summary() {
    module_header "SUDO USERS AUDIT" "7"

    section "PRIVILEGED ACCOUNT SUMMARY"
    
    value_row "Default Admin Group" "$SUDO_GROUP_NAME"
    
    if [ "$EUID" -eq 0 ]; then
        value_row "Total Sudo Users Found" "$TOTAL_SUDO_USERS"
    else
        value_row "Total Sudo Users Found" "${YELLOW}Partial (Requires Root)${RESET}"
    fi
    echo
}

display_sudo_tables() {
    section "AUTHORIZED SUDO USERS"
    
    if [ ${#SUDO_USERS_LIST[@]} -eq 0 ]; then
        if [ "$EUID" -ne 0 ]; then
            echo -e "  ${YELLOW}⚠ Cannot perform deep audit without root privileges.${RESET}"
            echo -e "  ${DIM}No standard group members found.${RESET}\n"
        else
            echo -e "  ${DIM}No users with sudo privileges found (excluding root).${RESET}\n"
        fi
        return
    fi

    printf "  ${LCYAN}%-20s %-40s${RESET}\n" "USER" "AUTHORIZATION SOURCE"
    echo -e "  ${DIM}${SHORT_LINE}───────────────${RESET}"

    for entry in "${SUDO_USERS_LIST[@]}"; do
        local user="${entry%%:*}"
        local source="${entry#*:}"

        local source_color="${WHITE}"
        if [[ "$source" == *"Explicit"* ]] || [[ "$source" == *"Drop-in"* ]]; then
            source_color="${YELLOW}"
        fi

        printf "  ${WHITE}%-20s${RESET} ${source_color}%-40s${RESET}\n" "${user:0:19}" "${source}"
    done
    echo
}

# ------------------------------------------------------------------------------
# 6. SECURITY ASSESSMENT
# ------------------------------------------------------------------------------
perform_security_checks() {
    section "SECURITY ASSESSMENT"

    # Check 1: Root Privilege Verification
    if [ "$EUID" -ne 0 ]; then
        row "Audit Integrity" "Run as root to read /etc/sudoers and drop-ins" "warn"
        increment_warn
    else
        row "Audit Integrity" "Root privileges detected (Deep scan active)" "ok"
        increment_pass
    fi

    # Check 2: Volume of Sudo Users
    if [ "$TOTAL_SUDO_USERS" -gt 5 ]; then
        row "Admin Sprawl" "High number of sudo users ($TOTAL_SUDO_USERS) detected" "warn"
        echo -e "  ${YELLOW}▶ Review authorization list to enforce Principle of Least Privilege.${RESET}"
        increment_warn
    else
        row "Admin Sprawl" "Manageable number of sudo users ($TOTAL_SUDO_USERS)" "ok"
        increment_pass
    fi

    # Check 3: Sudoers configuration file permissions (Requires Root)
    if [ "$EUID" -eq 0 ]; then
        # Main file
        local main_perms main_owner
        main_perms=$(stat -c "%a" /etc/sudoers)
        main_owner=$(stat -c "%U:%G" /etc/sudoers)
        
        if [[ "$main_perms" != "440" ]] || [[ "$main_owner" != "root:root" ]]; then
            row "/etc/sudoers Security" "Insecure permissions! ($main_perms, $main_owner)" "bad"
            echo -e "  ${LIGHT_RED}▶ Must be 440 and owned by root:root${RESET}"
            increment_error
        else
            row "/etc/sudoers Security" "Secure permissions (440, root:root)" "ok"
            increment_pass
        fi

        # Drop-ins
        if [ ${#SUDO_DIR_ISSUES[@]} -gt 0 ]; then
            row "sudoers.d Security" "${#SUDO_DIR_ISSUES[@]} drop-in file(s) have insecure permissions!" "bad"
            echo -e "  ${LIGHT_RED}▶ Affected files: $(echo "${SUDO_DIR_ISSUES[@]}" | tr ' ' ',')${RESET}"
            increment_error
        else
            row "sudoers.d Security" "All drop-in files have secure permissions" "ok"
            increment_pass
        fi
    fi
    echo
}

# ------------------------------------------------------------------------------
# 7. AUDIT SUMMARY & COMPLETION
# ------------------------------------------------------------------------------
show_audit_summary() {
    section "AUDIT SUMMARY"

    value_row "Checks Performed" "$CHECKS_PERFORMED"
    value_row "Passed" "${LIGHT_GREEN}${PASSED_CHECKS}${RESET}"
    value_row "Warnings" "${YELLOW}${WARNINGS}${RESET}"
    value_row "Errors" "${LIGHT_RED}${ERRORS}${RESET}"
    
    echo

    if [ "$ERRORS" -gt 0 ]; then
        value_row "Security Status" "${LIGHT_RED}✖ ACTION REQUIRED${RESET}"
    elif [ "$WARNINGS" -gt 0 ]; then
        value_row "Security Status" "${YELLOW}⚠ REVIEW RECOMMENDED${RESET}"
    else
        value_row "Security Status" "${LIGHT_GREEN}✔ SECURE${RESET}"
    fi

    echo
    echo -e "  ${DIM}${LINE}${RESET}"
    echo -e "  ${LIGHT_GREEN}[SUCCESS] Module completed successfully.${RESET}"
    echo -e "  ${DIM}${LINE}${RESET}"
    echo
}

# ------------------------------------------------------------------------------
# 8. MAIN EXECUTION CONTROLLER
# ------------------------------------------------------------------------------
main() {
    collect_sudo_data
    display_sudo_summary
    display_sudo_tables
    perform_security_checks
    show_audit_summary
    return 0
}

main "$@"
