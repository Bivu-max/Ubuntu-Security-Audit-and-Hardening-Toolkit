clear
#!/usr/bin/env bash
# ==============================================================================
#   MODULE: Login Shell Users
#   Advanced Ubuntu Security Toolkit
#   Purpose: Identify and audit user accounts with valid interactive login shells.
#            Highlight accounts capable of interactive system access.
# ==============================================================================

set -o pipefail

# ------------------------------------------------------------------------------
# 1. BOOTSTRAP & LIBRARY SOURCING
# ------------------------------------------------------------------------------
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" >/dev/null 2>&1 && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/../.." >/dev/null 2>&1 && pwd)"

# Fallback basic colors if common.sh doesn't load them properly
RESET='\033[0m'
RED='\033[0;31m'
LIGHT_RED='\033[1;31m'
GREEN='\033[0;32m'
LIGHT_GREEN='\033[1;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
LCYAN='\033[1;36m'
CYAN='\033[0;36m'
MAGENTA='\033[1;35m'
WHITE='\033[1;37m'
BOLD='\033[1m'
DIM='\033[2m'
LINE="──────────────────────────────────────────────────────────────────────"
SHORT_LINE="────────────────────────────────────────────────"

if [ -f "$PROJECT_ROOT/lib/common.sh" ]; then
    # shellcheck source=/dev/null
    source "$PROJECT_ROOT/lib/common.sh"
    # Map common.sh colors to required local names if they exist
    [ -n "$NC" ] && RESET="$NC"
    [ -n "$LRED" ] && LIGHT_RED="$LRED"
    [ -n "$LGREEN" ] && LIGHT_GREEN="$LGREEN"
else
    printf "${LIGHT_RED}✖ WARNING: Cannot find lib/common.sh. Using fallback formatting.${RESET}\n"
fi

# ------------------------------------------------------------------------------
# 2. LOCAL FUNCTION OVERRIDES (Ensuring structural consistency)
# ------------------------------------------------------------------------------
# Override to satisfy the strict MODULE 4 / 7 requirement
module_header() {
    local module_name="$1"
    local module_number="$2"

    echo
    echo -e "${BLUE}${BOLD}  ╔══════════════════════════════════════════════════════════════════════╗${RESET}"
    echo -e "${BLUE}${BOLD}  ║                                                                      ║${RESET}"
    printf "${BLUE}${BOLD}  ║%*s%s%*s║${RESET}\n" \
        $(( (68 - ${#module_name}) / 2 )) "" \
        "$module_name" \
        $(( 68 - ${#module_name} - (68 - ${#module_name}) / 2 )) ""
    echo -e "${BLUE}${BOLD}  ║                                                                      ║${RESET}"
    printf "${BLUE}${BOLD}  ║%*sMODULE %s / 7%*s║${RESET}\n" \
        $(( (68 - 12) / 2 )) "" \
        "$module_number" \
        $(( 68 - 12 - (68 - 12) / 2 )) ""
    echo -e "${BLUE}${BOLD}  ╚══════════════════════════════════════════════════════════════════════╝${RESET}"
    echo
}

# Provide local fallbacks for formatting functions in case common.sh is incomplete
section() {
    local title="$1"
    echo -e "  ${LCYAN}${BOLD}${title}${RESET}"
    echo -e "  ${DIM}${LINE}${RESET}"
}

value_row() {
    local label="$1"
    local value="$2"
    printf "  ${WHITE}%-32s${RESET} : ${CYAN}%s${RESET}\n" "$label" "$value"
}

row() {
    local label="$1"
    local value="$2"
    local status="${3:-info}"
    local colour icon

    case "$status" in
        ok)   colour="${LIGHT_GREEN}"; icon="✔" ;;
        warn) colour="${YELLOW}";      icon="⚠" ;;
        bad)  colour="${LIGHT_RED}";   icon="✖" ;;
        *)    colour="${LCYAN}";       icon="ℹ" ;;
    esac

    printf "  ${WHITE}%-32s${RESET} ${colour}%s  %s${RESET}\n" "$label" "$icon" "$value"
}

increment_pass()  { ((CHECKS_PERFORMED++)); ((PASSED_CHECKS++)); }
increment_warn()  { ((CHECKS_PERFORMED++)); ((WARNINGS++)); }
increment_error() { ((CHECKS_PERFORMED++)); ((ERRORS++)); }

# ------------------------------------------------------------------------------
# 3. GLOBAL AUDIT VARIABLES
# ------------------------------------------------------------------------------
TOTAL_LOGIN_USERS=0
HUMAN_LOGIN_USERS=0
SYSTEM_LOGIN_USERS=0
ROOT_LOGIN_USERS=0

VALID_SHELLS=()
LOGIN_USERS_LIST=()
SYSTEM_LOGIN_ISSUES=()

CHECKS_PERFORMED=0
PASSED_CHECKS=0
WARNINGS=0
ERRORS=0

# ------------------------------------------------------------------------------
# 4. HELPER LOGIC
# ------------------------------------------------------------------------------
load_valid_shells() {
    if [ -r /etc/shells ]; then
        while read -r line; do
            # Ignore comments and empty lines
            if [[ -n "$line" && "$line" != \#* ]]; then
                VALID_SHELLS+=("$line")
            fi
        done < /etc/shells
    else
        # Fallback if /etc/shells is unreadable
        VALID_SHELLS=("/bin/bash" "/bin/sh" "/bin/dash" "/bin/zsh" "/usr/bin/bash" "/usr/bin/sh")
    fi
}

is_valid_shell() {
    local target_shell="$1"
    
    # 1. Check against loaded /etc/shells
    for s in "${VALID_SHELLS[@]}"; do
        if [[ "$s" == "$target_shell" ]]; then
            return 0
        fi
    done
    
    # 2. Fallback strict exclusion pattern for non-interactive shells
    case "$target_shell" in
        */nologin|*/false|*/sync|*/halt|*/shutdown|"")
            return 1
            ;;
        *)
            # If not in /etc/shells but doesn't look like a deny-listed shell,
            # we classify it as potentially valid for audit safety.
            return 0
            ;;
    esac
}

# ------------------------------------------------------------------------------
# 5. DATA COLLECTION
# ------------------------------------------------------------------------------
collect_login_shell_data() {
    if [ ! -r /etc/passwd ]; then
        echo -e "  ${LIGHT_RED}✖ CRITICAL: Cannot read /etc/passwd!${RESET}"
        exit 1
    fi

    load_valid_shells

    while IFS=: read -r user pass uid gid info home shell; do
        if is_valid_shell "$shell"; then
            ((TOTAL_LOGIN_USERS++))
            
            local utype="System"
            if [ "$uid" -eq 0 ]; then
                utype="Root"
                ((ROOT_LOGIN_USERS++))
            elif [ "$uid" -ge 1000 ] && [ "$uid" -lt 65534 ]; then
                utype="Human"
                ((HUMAN_LOGIN_USERS++))
            else
                # It's a system user (UID 1-999 or 65534 nobody) WITH a valid shell
                ((SYSTEM_LOGIN_USERS++))
                SYSTEM_LOGIN_ISSUES+=("$user")
            fi

            # Check Lock Status (Requires Root)
            local status="Unknown"
            if [ "$EUID" -eq 0 ] && [ -r /etc/shadow ]; then
                local shadow_val
                shadow_val=$(awk -F: -v u="$user" '$1==u {print $2}' /etc/shadow 2>/dev/null)
                if [[ "$shadow_val" == "!"* ]] || [[ "$shadow_val" == "*"* ]] || [[ -z "$shadow_val" ]]; then
                    status="Locked"
                else
                    status="Active"
                fi
            fi

            LOGIN_USERS_LIST+=("$user:$uid:$utype:$shell:$status")
        fi
    done < /etc/passwd
}

# ------------------------------------------------------------------------------
# 6. DATA PRESENTATION
# ------------------------------------------------------------------------------
display_login_shell_summary() {
    module_header "LOGIN SHELL USERS" "4"

    section "LOGIN SHELL SUMMARY"
    
    value_row "Total Interactive Accounts" "$TOTAL_LOGIN_USERS"
    value_row "Human User Accounts" "$HUMAN_LOGIN_USERS"
    value_row "Root Accounts" "$ROOT_LOGIN_USERS"
    
    if [ "$SYSTEM_LOGIN_USERS" -gt 0 ]; then
        value_row "System/Daemon Accounts" "${LIGHT_RED}${SYSTEM_LOGIN_USERS}${RESET}"
    else
        value_row "System/Daemon Accounts" "${LIGHT_GREEN}0${RESET}"
    fi
    echo
}

display_login_shell_tables() {
    section "ACCOUNTS WITH INTERACTIVE ACCESS"
    
    if [ ${#LOGIN_USERS_LIST[@]} -eq 0 ]; then
        echo -e "  ${DIM}No accounts with interactive login shells found.${RESET}\n"
        return
    fi

    printf "  ${LCYAN}%-16s %-6s %-8s %-20s %-10s${RESET}\n" "USER" "UID" "TYPE" "SHELL" "STATUS"
    echo -e "  ${DIM}${SHORT_LINE}──────────────────────────────${RESET}"

    for entry in "${LOGIN_USERS_LIST[@]}"; do
        # Parse: user:uid:type:shell:status
        local user="${entry%%:*}"
        local rest="${entry#*:}"
        local uid="${rest%%:*}"
        rest="${rest#*:}"
        local utype="${rest%%:*}"
        rest="${rest#*:}"
        local shell="${rest%%:*}"
        local status="${rest#*:}"

        # Coloring logic
        local type_color="${WHITE}"
        if [ "$utype" == "System" ]; then
            type_color="${LIGHT_RED}"
        elif [ "$utype" == "Root" ]; then
            type_color="${MAGENTA}"
        fi

        local status_color="${WHITE}"
        if [ "$status" == "Active" ]; then
            status_color="${LIGHT_GREEN}"
        elif [ "$status" == "Locked" ]; then
            status_color="${YELLOW}"
        elif [ "$status" == "Unknown" ]; then
            status_color="${DIM}"
        fi

        printf "  ${WHITE}%-16s${RESET} %-6s ${type_color}%-8s${RESET} %-20s ${status_color}%-10s${RESET}\n" \
            "${user:0:15}" "$uid" "$utype" "${shell:0:20}" "$status"
    done
    echo
}

# ------------------------------------------------------------------------------
# 7. SECURITY ASSESSMENT
# ------------------------------------------------------------------------------
perform_security_checks() {
    section "SECURITY ASSESSMENT"

    # Check 1: Root Privilege Verification
    if [ "$EUID" -ne 0 ]; then
        row "Audit Context" "Run as root to see locked status of accounts" "warn"
        increment_warn
    else
        row "Audit Context" "Root privileges active (Full visibility)" "ok"
        increment_pass
    fi

    # Check 2: System Accounts with Login Shells
    if [ "$SYSTEM_LOGIN_USERS" -gt 0 ]; then
        row "System Accounts" "$SYSTEM_LOGIN_USERS system account(s) have interactive shells!" "bad"
        echo -e "  ${LIGHT_RED}▶ Vulnerable Accounts: $(echo "${SYSTEM_LOGIN_ISSUES[@]}" | tr ' ' ',')${RESET}"
        echo -e "  ${YELLOW}▶ Best Practice: Change shell to /usr/sbin/nologin using: chsh -s /usr/sbin/nologin <user>${RESET}"
        increment_error
    else
        row "System Accounts" "No system daemons have interactive login access" "ok"
        increment_pass
    fi

    # Check 3: Root Account Shell
    if [ "$ROOT_LOGIN_USERS" -eq 1 ]; then
        row "Root Configuration" "Root account possesses a valid shell" "ok"
        increment_pass
    elif [ "$ROOT_LOGIN_USERS" -eq 0 ]; then
        row "Root Configuration" "Root account lacks a valid login shell" "warn"
        increment_warn
    else
        row "Root Configuration" "Multiple UID 0 accounts with login shells detected!" "bad"
        increment_error
    fi
    echo
}

# ------------------------------------------------------------------------------
# 8. AUDIT SUMMARY & COMPLETION
# ------------------------------------------------------------------------------
show_audit_summary() {
    section "AUDIT SUMMARY"

    value_row "Checks Performed" "$CHECKS_PERFORMED"
    value_row "Passed" "${LIGHT_GREEN}${PASSED_CHECKS}${RESET}"
    value_row "Warnings" "${YELLOW}${WARNINGS}${RESET}"
    value_row "Errors" "${LIGHT_RED}${ERRORS}${RESET}"
    
    echo

    if [ "$ERRORS" -gt 0 ]; then
        value_row "Security Status" "${LIGHT_RED}✖ ACTION REQUIRED${RESET}"
    elif [ "$WARNINGS" -gt 0 ]; then
        value_row "Security Status" "${YELLOW}⚠ REVIEW RECOMMENDED${RESET}"
    else
        value_row "Security Status" "${LIGHT_GREEN}✔ SECURE${RESET}"
    fi

    echo
    echo -e "  ${DIM}${LINE}${RESET}"
    echo -e "  ${LIGHT_GREEN}[SUCCESS] Module completed successfully.${RESET}"
    echo -e "  ${DIM}${LINE}${RESET}"
    echo
}

# ------------------------------------------------------------------------------
# 9. MAIN EXECUTION CONTROLLER
# ------------------------------------------------------------------------------
main() {
    collect_login_shell_data
    display_login_shell_summary
    display_login_shell_tables
    perform_security_checks
    show_audit_summary
    return 0
}

main "$@"
