clear
#!/usr/bin/env bash
# ==============================================================================
#   complete_user_audit.sh
#   Advanced Ubuntu Security Hardening & Audit Toolkit
#   Complete User Audit Module
# ==============================================================================

set -o pipefail

# ==============================================================================
# COLOR & FORMATTING DEFINITIONS
# ==============================================================================
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
MAGENTA='\033[0;35m'
WHITE='\033[1;37m'
RESET='\033[0m'
BOLD='\033[1m'
DIM='\033[2m'

LINE="────────────────────────────────────────────────────────────────────────────"
HEAVY_LINE="============================================================================"

# ==============================================================================
# GLOBAL AUDIT COUNTERS & ARRAYS
# ==============================================================================
CHECKS_PERFORMED=0
PASSED=0
WARNINGS=0
CRITICALS=0
INFOS=0

declare -a FINDINGS_CRIT=()
declare -a FINDINGS_WARN=()
declare -a FINDINGS_PASS=()
declare -a RECOMMENDATIONS=()

# ==============================================================================
# HELPER FUNCTIONS
# ==============================================================================
log_pass() { ((CHECKS_PERFORMED++)); ((PASSED++)); echo -e "  ${GREEN}[PASS]${RESET} $1"; FINDINGS_PASS+=("$1"); }
log_warn() { ((CHECKS_PERFORMED++)); ((WARNINGS++)); echo -e "  ${YELLOW}[WARNING]${RESET} $1"; FINDINGS_WARN+=("$1"); }
log_crit() { ((CHECKS_PERFORMED++)); ((CRITICALS++)); echo -e "  ${RED}[CRITICAL]${RESET} $1"; FINDINGS_CRIT+=("$1"); }
log_info() { ((CHECKS_PERFORMED++)); ((INFOS++)); echo -e "  ${CYAN}[INFO]${RESET} $1"; }

command_exists() { command -v "$1" >/dev/null 2>&1; }

# ==============================================================================
# HEADER
# ==============================================================================
show_header() {
    clear
    echo -e "${BLUE}${BOLD}${HEAVY_LINE}"
    echo -e "                        COMPLETE USER AUDIT"
    echo -e "${HEAVY_LINE}${RESET}"
    echo -e "  ${WHITE}${BOLD}MODULE INFORMATION${RESET}"
    echo -e "  ${DIM}${LINE}${RESET}"
    echo -e "  Module Name      : Complete User Audit"
    echo -e "  Category         : User"
    echo -e "  Module           : 8 / 8"
    echo -e "  Audit Type       : Comprehensive User & Account Security Audit"
    echo -e "  ${DIM}${LINE}${RESET}"
    
    local host_name date_time current_user os_version kernel_version arch
    host_name=$(hostname 2>/dev/null || echo "Unknown")
    date_time=$(date '+%Y-%m-%d %H:%M:%S')
    current_user=$(whoami 2>/dev/null || echo "Unknown")
    os_version=$(grep '^PRETTY_NAME=' /etc/os-release 2>/dev/null | cut -d= -f2 | tr -d '"' || echo "Unknown")
    kernel_version=$(uname -r 2>/dev/null || echo "Unknown")
    arch=$(uname -m 2>/dev/null || echo "Unknown")

    echo -e "  Hostname         : ${CYAN}${host_name}${RESET}"
    echo -e "  Date/Time        : ${CYAN}${date_time}${RESET}"
    echo -e "  Current User     : ${CYAN}${current_user}${RESET}"
    echo -e "  Ubuntu Version   : ${CYAN}${os_version}${RESET}"
    echo -e "  Kernel Version   : ${CYAN}${kernel_version}${RESET}"
    echo -e "  Architecture     : ${CYAN}${arch}${RESET}"
}

# ==============================================================================
# [1] USER ACCOUNT INVENTORY
# ==============================================================================
audit_user_inventory() {
    echo -e "\n  ${BLUE}${BOLD}[1] USER ACCOUNT INVENTORY${RESET}"
    echo -e "  ${DIM}${LINE}${RESET}"

    if [[ ! -f /etc/passwd ]]; then
        log_crit "Cannot read /etc/passwd. Core system file missing."
        return
    fi

    local total_users root_users human_users system_users
    total_users=$(wc -l < /etc/passwd 2>/dev/null)
    root_users=$(awk -F: '$3==0 {print $1}' /etc/passwd 2>/dev/null | wc -l)
    human_users=$(awk -F: '$3>=1000 && $3!=65534 {print $1}' /etc/passwd 2>/dev/null | wc -l)
    system_users=$(awk -F: '$3>0 && $3<1000 {print $1}' /etc/passwd 2>/dev/null | wc -l)

    printf "  %-30s : ${CYAN}%s${RESET}\n" "Total User Accounts" "$total_users"
    printf "  %-30s : ${CYAN}%s${RESET}\n" "Human Users (UID >= 1000)" "$human_users"
    printf "  %-30s : ${CYAN}%s${RESET}\n" "System/Service Accounts" "$system_users"
    printf "  %-30s : ${CYAN}%s${RESET}\n" "Root (UID 0) Accounts" "$root_users"
    echo

    log_info "Basic user inventory collected successfully from /etc/passwd."
}

# ==============================================================================
# [2] HUMAN USER AUDIT
# ==============================================================================
audit_human_users() {
    echo -e "\n  ${BLUE}${BOLD}[2] HUMAN USER AUDIT${RESET}"
    echo -e "  ${DIM}${LINE}${RESET}"

    if [[ ! -f /etc/passwd ]]; then return; fi

    local human_list
    # Note: excluding 'nobody' (65534). Also capturing root (UID 0) as an interactive potential.
    human_list=$(awk -F: '($3>=1000 && $3!=65534) || $3==0 {print $1":"$3":"$6":"$7}' /etc/passwd)
    
    if [[ -z "$human_list" ]]; then
        log_info "No typical human users found on this system."
    else
        printf "  %-15s | %-5s | %-20s | %s\n" "USERNAME" "UID" "HOME DIRECTORY" "LOGIN SHELL"
        echo -e "  ${DIM}----------------------------------------------------------------------${RESET}"
        
        while IFS=: read -r h_user h_uid h_home h_shell; do
            printf "  %-15s | %-5s | %-20s | %s\n" "$h_user" "$h_uid" "$h_home" "$h_shell"
        done <<< "$human_list"
        echo
        log_pass "Human user accounts identified correctly."
    fi
}

# ==============================================================================
# [3] LOCKED ACCOUNT AUDIT
# ==============================================================================
audit_locked_users() {
    echo -e "\n  ${BLUE}${BOLD}[3] LOCKED ACCOUNT AUDIT${RESET}"
    echo -e "  ${DIM}${LINE}${RESET}"

    if [[ "$EUID" -ne 0 ]]; then
        log_warn "Root privileges required for this check (/etc/shadow cannot be read)."
        return
    fi

    if [[ ! -f /etc/shadow ]]; then
        log_crit "Cannot read /etc/shadow. File is missing."
        return
    fi

    # Locked accounts typically start with ! or * in the password hash field
    local locked_count
    locked_count=$(awk -F: '$2 ~ /^[\!\*]/ {print $1}' /etc/shadow | wc -l)
    
    printf "  %-30s : ${CYAN}%s${RESET}\n" "Total Locked Accounts" "$locked_count"
    
    echo -e "  ${DIM}(An account is 'locked' if its password hash begins with '!' or '*', preventing password-based login.)${RESET}"
    echo

    if [[ "$locked_count" -gt 0 ]]; then
        log_info "Locked accounts detected. This is a standard and secure configuration for service accounts."
    else
        log_warn "No locked accounts detected. Ensure service accounts cannot be logged into."
        RECOMMENDATIONS+=("Review service accounts and lock them if password-based authentication is not required.")
    fi
}

# ==============================================================================
# [4] LOGIN SHELL AUDIT
# ==============================================================================
audit_login_shells() {
    echo -e "\n  ${BLUE}${BOLD}[4] LOGIN SHELL AUDIT${RESET}"
    echo -e "  ${DIM}${LINE}${RESET}"

    local valid_shells=()
    if [[ -f /etc/shells ]]; then
        while read -r line; do
            [[ -n "$line" && "$line" != \#* ]] && valid_shells+=("$line")
        done < /etc/shells
    else
        valid_shells=(/bin/bash /bin/sh /bin/zsh /bin/dash /bin/fish)
    fi

    local interactive_users=0
    local sys_interactive=()

    while IFS=: read -r user pass uid gid info home shell; do
        local is_valid=0
        for s in "${valid_shells[@]}"; do
            if [[ "$shell" == "$s" ]]; then
                is_valid=1
                break
            fi
        done

        if [[ "$is_valid" -eq 1 ]]; then
            ((interactive_users++))
            # System accounts (UID 1-999) normally shouldn't have an interactive shell
            if [[ "$uid" -gt 0 && "$uid" -lt 1000 ]]; then
                sys_interactive+=("$user ($shell)")
            fi
        fi
    done < /etc/passwd

    printf "  %-30s : ${CYAN}%s${RESET}\n" "Total Interactive Accounts" "$interactive_users"
    
    if [[ ${#sys_interactive[@]} -gt 0 ]]; then
        echo -e "  ${YELLOW}System accounts with interactive login shells detected:${RESET}"
        for su in "${sys_interactive[@]}"; do
            echo "    - $su"
        done
        echo
        log_warn "Service accounts have interactive shells configured."
        RECOMMENDATIONS+=("Disable interactive shells for service accounts where appropriate (use /usr/sbin/nologin or /bin/false).")
    else
        echo
        log_pass "No unexpected interactive shells for system accounts detected."
    fi
}

# ==============================================================================
# [5] PASSWORD AGING AUDIT
# ==============================================================================
audit_password_aging() {
    echo -e "\n  ${BLUE}${BOLD}[5] PASSWORD AGING AUDIT${RESET}"
    echo -e "  ${DIM}${LINE}${RESET}"

    local pass_max_default="Unknown"
    local pass_min_default="Unknown"
    
    if [[ -f /etc/login.defs ]]; then
        pass_max_default=$(grep '^PASS_MAX_DAYS' /etc/login.defs | awk '{print $2}')
        pass_min_default=$(grep '^PASS_MIN_DAYS' /etc/login.defs | awk '{print $2}')
    fi
    printf "  %-30s : ${CYAN}%s${RESET}\n" "Default PASS_MAX_DAYS" "$pass_max_default"
    printf "  %-30s : ${CYAN}%s${RESET}\n" "Default PASS_MIN_DAYS" "$pass_min_default"
    echo

    if [[ "$EUID" -ne 0 ]]; then
        log_warn "Root privileges required to audit individual account password aging (/etc/shadow)."
        return
    fi

    local never_expire_count=0
    local never_expire_users=()
    local expired_count=0
    local expired_users=()
    
    local current_epoch current_days
    current_epoch=$(date +%s 2>/dev/null)
    current_days=$((current_epoch / 86400))

    while IFS=: read -r user pass last_changed min max warn inactive expire; do
        # Ignore completely locked/system accounts
        if [[ ! "$pass" =~ ^[\!\*] && -n "$pass" ]]; then
            
            # Check for never-expire (99999 or empty)
            if [[ "$max" == "99999" || -z "$max" ]]; then
                ((never_expire_count++))
                never_expire_users+=("$user")
            else
                # Check if currently expired
                if [[ -n "$last_changed" && -n "$max" ]]; then
                    local expiration_day=$((last_changed + max))
                    if [[ "$current_days" -gt "$expiration_day" ]]; then
                        ((expired_count++))
                        expired_users+=("$user")
                    fi
                fi
            fi
        fi
    done < /etc/shadow

    if [[ "$never_expire_count" -gt 0 ]]; then
        log_warn "Some human accounts have passwords configured to never expire."
        echo -e "  ${DIM}Accounts: ${never_expire_users[*]}${RESET}"
        RECOMMENDATIONS+=("Review password expiration settings. Consider enforcing max password age policies.")
    else
        log_pass "All active accounts enforce a maximum password age."
    fi

    if [[ "$expired_count" -gt 0 ]]; then
        log_crit "Accounts with expired passwords that are still active detected!"
        echo -e "  ${DIM}Accounts: ${expired_users[*]}${RESET}"
        RECOMMENDATIONS+=("Force password resets for expired accounts or lock them if inactive.")
    else
        log_pass "No active accounts with currently expired passwords detected."
    fi
}

# ==============================================================================
# [6] ROOT ACCOUNT AUDIT
# ==============================================================================
audit_root_accounts() {
    echo -e "\n  ${BLUE}${BOLD}[6] ROOT ACCOUNT AUDIT${RESET}"
    echo -e "  ${DIM}${LINE}${RESET}"

    if [[ ! -f /etc/passwd ]]; then return; fi

    local uid0_users
    uid0_users=$(awk -F: '$3==0 {print $1}' /etc/passwd)
    local uid0_count
    uid0_count=$(echo "$uid0_users" | wc -w)

    printf "  %-30s : ${CYAN}%s${RESET}\n" "Total UID 0 Accounts" "$uid0_count"
    
    echo -e "  ${WHITE}Identified UID 0 (Root-Equivalent) Accounts:${RESET}"
    for u in $uid0_users; do
        echo "  - $u"
    done
    echo

    if [[ "$uid0_count" -gt 1 ]]; then
        log_crit "Additional UID 0 account detected. These have total administrative control."
        RECOMMENDATIONS+=("Investigate unexpected UID 0 accounts immediately. Remove or restrict if unauthorized.")
    else
        log_pass "No unexpected UID 0 accounts detected (only 'root')."
    fi
}

# ==============================================================================
# [7] SUDO USER AUDIT
# ==============================================================================
audit_sudo_users() {
    echo -e "\n  ${BLUE}${BOLD}[7] SUDO USER AUDIT${RESET}"
    echo -e "  ${DIM}${LINE}${RESET}"

    # Determine default administrative group
    local admin_group=""
    if getent group sudo >/dev/null 2>&1; then
        admin_group="sudo"
    elif getent group wheel >/dev/null 2>&1; then
        admin_group="wheel"
    fi

    if [[ -n "$admin_group" ]]; then
        local group_members
        group_members=$(getent group "$admin_group" | cut -d: -f4)
        printf "  %-30s : ${CYAN}%s${RESET}\n" "Administrative Group" "$admin_group"
        printf "  %-30s : ${CYAN}%s${RESET}\n" "Group Members" "${group_members:-None Found}"
    else
        printf "  %-30s : ${YELLOW}Not Found${RESET}\n" "Administrative Group"
    fi
    echo

    if [[ "$EUID" -ne 0 ]]; then
        log_warn "Root privileges required to audit /etc/sudoers and drop-in configurations."
        return
    fi

    local explicit_sudoers=()
    if [[ -f /etc/sudoers ]]; then
        # Safely parse sudoers ignoring comments, aliases, and default root config
        while read -r line; do
            explicit_sudoers+=("$line")
        done < <(grep -E '^[A-Za-z0-9_]+[[:space:]]+ALL=' /etc/sudoers | grep -v '^root')
    fi

    if [[ -d /etc/sudoers.d ]]; then
        while read -r line; do
            explicit_sudoers+=("$line")
        done < <(grep -hE '^[A-Za-z0-9_]+[[:space:]]+ALL=' /etc/sudoers.d/* 2>/dev/null)
    fi

    if [[ ${#explicit_sudoers[@]} -gt 0 ]]; then
        echo -e "  ${YELLOW}Users explicitly defined in sudoers configuration:${RESET}"
        for entry in "${explicit_sudoers[@]}"; do
            echo "    - $entry"
        done
        echo
        log_warn "Explicit sudoers definitions discovered. Review for least-privilege adherence."
        RECOMMENDATIONS+=("Follow least-privilege principles for sudo access. Centralize management via groups rather than explicit user entries.")
    else
        log_info "No explicit non-root users directly defined in sudoers configurations."
    fi
}

# ==============================================================================
# [8] ACCOUNT SECURITY ANALYSIS
# ==============================================================================
analyze_account_security() {
    echo -e "\n  ${BLUE}${BOLD}[8] ACCOUNT SECURITY ANALYSIS${RESET}"
    echo -e "  ${DIM}${LINE}${RESET}"

    if [[ "$CRITICALS" -gt 0 ]]; then
        log_crit "Critical security misconfigurations exist within the user accounting environment."
    elif [[ "$WARNINGS" -gt 0 ]]; then
        log_warn "Several user configurations require review to align with best practices."
    else
        log_pass "Overall user and account configurations appear structurally secure based on automated checks."
    fi
}

# ==============================================================================
# SUMMARY OUTPUTS
# ==============================================================================
show_audit_summary() {
    echo -e "\n  ${WHITE}${BOLD}────────────────────────────────────────────────────────────────────────────"
    echo -e "                           AUDIT SUMMARY"
    echo -e "  ────────────────────────────────────────────────────────────────────────────${RESET}"

    local status_msg="${GREEN}SECURE${RESET}"
    if [[ "$CRITICALS" -gt 0 ]]; then
        status_msg="${RED}CRITICAL${RESET}"
    elif [[ "$WARNINGS" -gt 0 ]]; then
        status_msg="${YELLOW}REVIEW RECOMMENDED${RESET}"
    fi

    printf "  %-25s : %s\n" "Checks Performed" "$CHECKS_PERFORMED"
    printf "  %-25s : ${GREEN}%s${RESET}\n" "Passed" "$PASSED"
    printf "  %-25s : ${YELLOW}%s${RESET}\n" "Warnings" "$WARNINGS"
    printf "  %-25s : ${RED}%s${RESET}\n" "Critical Issues" "$CRITICALS"
    printf "  %-25s : ${CYAN}%s${RESET}\n" "Information" "$INFOS"
    echo
    printf "  %-25s : %s\n" "Security Status" "$status_msg"
    echo
}

show_findings() {
    echo -e "  ${WHITE}${BOLD}────────────────────────────────────────────────────────────────────────────"
    echo -e "                           SECURITY FINDINGS"
    echo -e "  ────────────────────────────────────────────────────────────────────────────${RESET}"
    
    if [[ ${#FINDINGS_CRIT[@]} -gt 0 ]]; then
        echo -e "  ${RED}[CRITICAL]${RESET}"
        for f in "${FINDINGS_CRIT[@]}"; do echo "  - $f"; done
        echo
    fi

    if [[ ${#FINDINGS_WARN[@]} -gt 0 ]]; then
        echo -e "  ${YELLOW}[WARNING]${RESET}"
        for f in "${FINDINGS_WARN[@]}"; do echo "  - $f"; done
        echo
    fi

    if [[ ${#FINDINGS_PASS[@]} -gt 0 ]]; then
        echo -e "  ${GREEN}[PASS]${RESET}"
        for f in "${FINDINGS_PASS[@]}"; do echo "  - $f"; done
        echo
    fi
}

show_recommendations() {
    if [[ ${#RECOMMENDATIONS[@]} -gt 0 ]]; then
        echo -e "  ${WHITE}${BOLD}────────────────────────────────────────────────────────────────────────────"
        echo -e "                           RECOMMENDATIONS"
        echo -e "  ────────────────────────────────────────────────────────────────────────────${RESET}"
        
        # De-duplicate recommendations safely and output
        printf "%s\n" "${RECOMMENDATIONS[@]}" | sort -u | while read -r rec; do
            if [[ -n "$rec" ]]; then
                echo -e "  ${MAGENTA}•${RESET} $rec"
            fi
        done
        echo
    fi
}

# ==============================================================================
# MAIN CONTROLLER
# ==============================================================================
main() {
    show_header
    audit_user_inventory
    audit_human_users
    audit_locked_users
    audit_login_shells
    audit_password_aging
    audit_root_accounts
    audit_sudo_users
    analyze_account_security
    show_audit_summary
    show_findings
    show_recommendations
    
    echo -e "  ${HEAVY_LINE}"
    echo -e "  ${GREEN}[SUCCESS] Complete User Audit finished executing.${RESET}"
    echo -e "  ${HEAVY_LINE}\n"
    
    exit 0
}

# Execute main function with all script arguments
main "$@"
