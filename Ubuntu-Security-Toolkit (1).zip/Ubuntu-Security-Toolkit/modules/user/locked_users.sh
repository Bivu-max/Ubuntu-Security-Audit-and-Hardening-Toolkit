clear
#!/usr/bin/env bash
# ==============================================================================
#   MODULE: Locked Users
#   Advanced Ubuntu Security Toolkit
#   Purpose: Identify and audit user accounts that are currently locked.
#            Detect locked accounts that may require administrative review
#            and identify inactive, restricted, or misconfigured accounts.
# ==============================================================================

set -o pipefail

# ------------------------------------------------------------------------------
# 1. BOOTSTRAP & LIBRARY SOURCING
# ------------------------------------------------------------------------------
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" >/dev/null 2>&1 && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/../.." >/dev/null 2>&1 && pwd)"

# Fallback basic colors if common.sh doesn't load them properly
RESET='\033[0m'
RED='\033[0;31m'
LIGHT_RED='\033[1;31m'
GREEN='\033[0;32m'
LIGHT_GREEN='\033[1;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
LCYAN='\033[1;36m'
CYAN='\033[0;36m'
MAGENTA='\033[1;35m'
WHITE='\033[1;37m'
BOLD='\033[1m'
DIM='\033[2m'
LINE="──────────────────────────────────────────────────────────────────────"
SHORT_LINE="────────────────────────────────────────────────"

if [ -f "$PROJECT_ROOT/lib/common.sh" ]; then
    # shellcheck source=/dev/null
    source "$PROJECT_ROOT/lib/common.sh"
    # Map common.sh colors to required local names if they exist
    [ -n "$NC" ] && RESET="$NC"
    [ -n "$LRED" ] && LIGHT_RED="$LRED"
    [ -n "$LGREEN" ] && LIGHT_GREEN="$LGREEN"
else
    printf "${LIGHT_RED}✖ WARNING: Cannot find lib/common.sh. Using fallback formatting.${RESET}\n"
fi

# ------------------------------------------------------------------------------
# 2. LOCAL FUNCTION OVERRIDES (Ensuring structural consistency)
# ------------------------------------------------------------------------------
# Override to satisfy the strict MODULE 3 / 7 requirement
module_header() {
    local module_name="$1"
    local module_number="$2"

    echo
    echo -e "${BLUE}${BOLD}  ╔══════════════════════════════════════════════════════════════════════╗${RESET}"
    echo -e "${BLUE}${BOLD}  ║                                                                      ║${RESET}"
    printf "${BLUE}${BOLD}  ║%*s%s%*s║${RESET}\n" \
        $(( (68 - ${#module_name}) / 2 )) "" \
        "$module_name" \
        $(( 68 - ${#module_name} - (68 - ${#module_name}) / 2 )) ""
    echo -e "${BLUE}${BOLD}  ║                                                                      ║${RESET}"
    printf "${BLUE}${BOLD}  ║%*sMODULE %s / 7%*s║${RESET}\n" \
        $(( (68 - 12) / 2 )) "" \
        "$module_number" \
        $(( 68 - 12 - (68 - 12) / 2 )) ""
    echo -e "${BLUE}${BOLD}  ╚══════════════════════════════════════════════════════════════════════╝${RESET}"
    echo
}

# Provide local fallbacks for formatting functions in case common.sh is incomplete
section() {
    local title="$1"
    echo -e "  ${LCYAN}${BOLD}${title}${RESET}"
    echo -e "  ${DIM}${LINE}${RESET}"
}

value_row() {
    local label="$1"
    local value="$2"
    printf "  ${WHITE}%-32s${RESET} : ${CYAN}%s${RESET}\n" "$label" "$value"
}

row() {
    local label="$1"
    local value="$2"
    local status="${3:-info}"
    local colour icon

    case "$status" in
        ok)   colour="${LIGHT_GREEN}"; icon="✔" ;;
        warn) colour="${YELLOW}";      icon="⚠" ;;
        bad)  colour="${LIGHT_RED}";   icon="✖" ;;
        *)    colour="${LCYAN}";       icon="ℹ" ;;
    esac

    printf "  ${WHITE}%-32s${RESET} ${colour}%s  %s${RESET}\n" "$label" "$icon" "$value"
}

increment_pass()  { ((CHECKS_PERFORMED++)); ((PASSED_CHECKS++)); }
increment_warn()  { ((CHECKS_PERFORMED++)); ((WARNINGS++)); }
increment_error() { ((CHECKS_PERFORMED++)); ((ERRORS++)); }

# ------------------------------------------------------------------------------
# 3. GLOBAL AUDIT VARIABLES
# ------------------------------------------------------------------------------
TOTAL_HUMANS=0
LOCKED_HUMANS=0
LOCKED_SYSTEM=0
LOCKED_HUMANS_ACTIVE_SHELL=0
ROOT_LOCKED=-1

LOCKED_HUMAN_LIST=()

CHECKS_PERFORMED=0
PASSED_CHECKS=0
WARNINGS=0
ERRORS=0

# ------------------------------------------------------------------------------
# 4. DATA COLLECTION
# ------------------------------------------------------------------------------
collect_locked_user_data() {
    if [ ! -r /etc/passwd ]; then
        echo -e "  ${LIGHT_RED}✖ CRITICAL: Cannot read /etc/passwd!${RESET}"
        exit 1
    fi

    while IFS=: read -r user pass uid gid info home shell; do
        local is_locked=0
        local active_shell=1

        # Check lock status via /etc/shadow if running as root
        if [ "$EUID" -eq 0 ] && [ -r /etc/shadow ]; then
            local shadow_pass
            shadow_pass=$(awk -F: -v u="$user" '$1==u {print $2}' /etc/shadow 2>/dev/null)
            
            # Locked accounts typically start with ! or * in the password field
            if [[ "$shadow_pass" == "!"* ]] || [[ "$shadow_pass" == "*"* ]] || [[ -z "$shadow_pass" ]]; then
                is_locked=1
            fi
        fi

        # Assess Shell validity
        case "$shell" in
            */nologin|*/false|*/sync|*/halt|*/shutdown)
                active_shell=0
                ;;
            *)
                active_shell=1
                ;;
        esac

        # Evaluate Root account specifically
        if [ "$uid" -eq 0 ]; then
            ROOT_LOCKED=$is_locked
        fi

        # Differentiate Human (>=1000) vs System accounts
        if [ "$uid" -ge 1000 ] && [ "$uid" -lt 65534 ]; then
            ((TOTAL_HUMANS++))
            if [ "$is_locked" -eq 1 ]; then
                ((LOCKED_HUMANS++))
                if [ "$active_shell" -eq 1 ]; then
                    ((LOCKED_HUMANS_ACTIVE_SHELL++))
                fi
                LOCKED_HUMAN_LIST+=("$user:$uid:$shell:$active_shell")
            fi
        else
            if [ "$is_locked" -eq 1 ]; then
                ((LOCKED_SYSTEM++))
            fi
        fi
    done < /etc/passwd
}

# ------------------------------------------------------------------------------
# 5. DATA PRESENTATION
# ------------------------------------------------------------------------------
display_locked_summary() {
    module_header "LOCKED USERS AUDIT" "3"

    section "LOCKED ACCOUNT SUMMARY"
    
    value_row "Total Human Accounts" "$TOTAL_HUMANS"
    
    if [ "$EUID" -eq 0 ]; then
        value_row "Locked Human Accounts" "$LOCKED_HUMANS"
        value_row "Locked System Accounts" "$LOCKED_SYSTEM"
        value_row "Locked Humans w/ Active Shell" "$LOCKED_HUMANS_ACTIVE_SHELL"
    else
        value_row "Locked Accounts" "${YELLOW}Unknown (Requires Root)${RESET}"
    fi
    echo
}

display_locked_tables() {
    section "LOCKED HUMAN USERS DETAIL"
    
    if [ "$EUID" -ne 0 ]; then
        echo -e "  ${YELLOW}⚠ Cannot display locked users. Root privileges are required to read /etc/shadow.${RESET}\n"
        return
    fi

    if [ ${#LOCKED_HUMAN_LIST[@]} -eq 0 ]; then
        echo -e "  ${DIM}No locked human users found.${RESET}\n"
        return
    fi

    printf "  ${LCYAN}%-18s %-6s %-22s %-16s${RESET}\n" "USER" "UID" "SHELL" "SHELL STATUS"
    echo -e "  ${DIM}${SHORT_LINE}─────────────────────────${RESET}"

    for entry in "${LOCKED_HUMAN_LIST[@]}"; do
        # Parse custom array string: user:uid:shell:active_shell
        local user="${entry%%:*}"
        local rest="${entry#*:}"
        local uid="${rest%%:*}"
        rest="${rest#*:}"
        local shell="${rest%%:*}"
        local active_shell="${rest#*:}"

        local shell_status="Restricted"
        local shell_color="${LIGHT_GREEN}"
        
        if [ "$active_shell" -eq 1 ]; then
            shell_status="ACTIVE SHELL"
            shell_color="${YELLOW}"
        fi

        printf "  ${WHITE}%-18s${RESET} %-6s %-22s ${shell_color}%-16s${RESET}\n" \
            "${user:0:17}" "$uid" "${shell:0:21}" "$shell_status"
    done
    echo
}

# ------------------------------------------------------------------------------
# 6. SECURITY ASSESSMENT
# ------------------------------------------------------------------------------
perform_security_checks() {
    section "SECURITY ASSESSMENT"

    # Check 1: Root Privilege Verification
    if [ "$EUID" -ne 0 ]; then
        row "Privilege Level" "Root privileges required for deep audit" "bad"
        increment_error
    else
        row "Privilege Level" "Root privileges detected" "ok"
        increment_pass
    fi

    # Check 2: Locked Users with Active Shells
    if [ "$EUID" -eq 0 ]; then
        if [ "$LOCKED_HUMANS_ACTIVE_SHELL" -gt 0 ]; then
            row "Shell Configurations" "$LOCKED_HUMANS_ACTIVE_SHELL locked user(s) retain active login shells!" "warn"
            echo -e "  ${YELLOW}▶ Best Practice: Change shells of locked users to /usr/sbin/nologin${RESET}"
            increment_warn
        else
            row "Shell Configurations" "All locked users have properly restricted shells" "ok"
            increment_pass
        fi
    fi

    # Check 3: Root Account Lockdown Status
    if [ "$EUID" -eq 0 ]; then
        if [ "$ROOT_LOCKED" -eq 1 ]; then
            row "Root Account" "Password login disabled (Ubuntu Default Secure)" "ok"
            increment_pass
        elif [ "$ROOT_LOCKED" -eq 0 ]; then
            row "Root Account" "Password login ENABLED!" "warn"
            echo -e "  ${YELLOW}▶ Direct root login is active. Ensure this is intentional.${RESET}"
            increment_warn
        fi
    fi
    echo
}

# ------------------------------------------------------------------------------
# 7. AUDIT SUMMARY & COMPLETION
# ------------------------------------------------------------------------------
show_audit_summary() {
    section "AUDIT SUMMARY"

    value_row "Checks Performed" "$CHECKS_PERFORMED"
    value_row "Passed" "${LIGHT_GREEN}${PASSED_CHECKS}${RESET}"
    value_row "Warnings" "${YELLOW}${WARNINGS}${RESET}"
    value_row "Errors" "${LIGHT_RED}${ERRORS}${RESET}"
    
    echo

    if [ "$ERRORS" -gt 0 ]; then
        value_row "Security Status" "${LIGHT_RED}✖ ACTION REQUIRED${RESET}"
    elif [ "$WARNINGS" -gt 0 ]; then
        value_row "Security Status" "${YELLOW}⚠ REVIEW RECOMMENDED${RESET}"
    else
        value_row "Security Status" "${LIGHT_GREEN}✔ SECURE${RESET}"
    fi

    echo
    echo -e "  ${DIM}${LINE}${RESET}"
    echo -e "  ${LIGHT_GREEN}[SUCCESS] Module completed successfully.${RESET}"
    echo -e "  ${DIM}${LINE}${RESET}"
    echo
}

# ------------------------------------------------------------------------------
# 8. MAIN EXECUTION CONTROLLER
# ------------------------------------------------------------------------------
main() {
    collect_locked_user_data
    display_locked_summary
    display_locked_tables
    perform_security_checks
    show_audit_summary
    return 0
}

main "$@"
