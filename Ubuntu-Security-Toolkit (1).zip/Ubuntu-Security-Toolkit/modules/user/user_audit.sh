#!/bin/bash

PROJECT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"

source "$PROJECT_ROOT/lib/common.sh"

echo "======================================"
echo "       USER SECURITY AUDIT"
echo "======================================"

echo ""
echo "1. Checking User Database"

if getent passwd > /dev/null; then
    pass "User database is working"
else
    error "User database problem detected"
fi

echo ""
echo "2. Total User Accounts"

USER_COUNT=$(getent passwd | wc -l)

echo "Total Accounts: $USER_COUNT"

echo ""
echo "3. Checking Administrator Group"

SUDO_GROUP=$(getent group sudo)

if [ -n "$SUDO_GROUP" ]; then
    echo "$SUDO_GROUP"
    warning "Review sudo group membership"
else
    warning "Sudo group not found"
fi

echo ""
echo "4. Checking Important Files"

for FILE in /etc/passwd /etc/shadow /etc/group /etc/gshadow
do
    if [ -e "$FILE" ]; then
        pass "$FILE exists"
    else
        error "$FILE is missing"
    fi
done

echo ""
echo "======================================"
echo "       AUDIT COMPLETED"
echo "======================================"
