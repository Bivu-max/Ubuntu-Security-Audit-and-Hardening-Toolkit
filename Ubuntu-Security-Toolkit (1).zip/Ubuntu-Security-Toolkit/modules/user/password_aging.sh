clear
#!/usr/bin/env bash
# ==============================================================================
#   MODULE: Password Aging
#   Advanced Ubuntu Security Toolkit
#   Purpose: Audit password aging policies (expiration, warnings, limits).
# ==============================================================================

set -o pipefail

# ------------------------------------------------------------------------------
# 1. BOOTSTRAP & LIBRARY SOURCING
# ------------------------------------------------------------------------------
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" >/dev/null 2>&1 && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/../.." >/dev/null 2>&1 && pwd)"

# Fallback basic colors if common.sh doesn't load them properly
RESET='\033[0m'
RED='\033[0;31m'
LIGHT_RED='\033[1;31m'
GREEN='\033[0;32m'
LIGHT_GREEN='\033[1;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
LCYAN='\033[1;36m'
CYAN='\033[0;36m'
MAGENTA='\033[1;35m'
WHITE='\033[1;37m'
BOLD='\033[1m'
DIM='\033[2m'
LINE="──────────────────────────────────────────────────────────────────────"
SHORT_LINE="────────────────────────────────────────────────"

if [ -f "$PROJECT_ROOT/lib/common.sh" ]; then
    # shellcheck source=/dev/null
    source "$PROJECT_ROOT/lib/common.sh"
    # Map common.sh colors to required local names if they exist
    [ -n "$NC" ] && RESET="$NC"
    [ -n "$LRED" ] && LIGHT_RED="$LRED"
    [ -n "$LGREEN" ] && LIGHT_GREEN="$LGREEN"
else
    printf "${LIGHT_RED}✖ WARNING: Cannot find lib/common.sh. Using fallback formatting.${RESET}\n"
fi

# ------------------------------------------------------------------------------
# 2. LOCAL FUNCTION OVERRIDES (Ensuring structural consistency)
# ------------------------------------------------------------------------------
# Override to satisfy the strict MODULE 5 / 7 requirement
module_header() {
    local module_name="$1"
    local module_number="$2"

    echo
    echo -e "${BLUE}${BOLD}  ╔══════════════════════════════════════════════════════════════════════╗${RESET}"
    echo -e "${BLUE}${BOLD}  ║                                                                      ║${RESET}"
    printf "${BLUE}${BOLD}  ║%*s%s%*s║${RESET}\n" \
        $(( (68 - ${#module_name}) / 2 )) "" \
        "$module_name" \
        $(( 68 - ${#module_name} - (68 - ${#module_name}) / 2 )) ""
    echo -e "${BLUE}${BOLD}  ║                                                                      ║${RESET}"
    printf "${BLUE}${BOLD}  ║%*sMODULE %s / 7%*s║${RESET}\n" \
        $(( (68 - 12) / 2 )) "" \
        "$module_number" \
        $(( 68 - 12 - (68 - 12) / 2 )) ""
    echo -e "${BLUE}${BOLD}  ╚══════════════════════════════════════════════════════════════════════╝${RESET}"
    echo
}

# Provide local fallbacks for formatting functions in case common.sh is incomplete
section() {
    local title="$1"
    echo -e "  ${LCYAN}${BOLD}${title}${RESET}"
    echo -e "  ${DIM}${LINE}${RESET}"
}

value_row() {
    local label="$1"
    local value="$2"
    printf "  ${WHITE}%-32s${RESET} : ${CYAN}%s${RESET}\n" "$label" "$value"
}

row() {
    local label="$1"
    local value="$2"
    local status="${3:-info}"
    local colour icon

    case "$status" in
        ok)   colour="${LIGHT_GREEN}"; icon="✔" ;;
        warn) colour="${YELLOW}";      icon="⚠" ;;
        bad)  colour="${LIGHT_RED}";   icon="✖" ;;
        *)    colour="${LCYAN}";       icon="ℹ" ;;
    esac

    printf "  ${WHITE}%-32s${RESET} ${colour}%s  %s${RESET}\n" "$label" "$icon" "$value"
}

increment_pass()  { ((CHECKS_PERFORMED++)); ((PASSED_CHECKS++)); }
increment_warn()  { ((CHECKS_PERFORMED++)); ((WARNINGS++)); }
increment_error() { ((CHECKS_PERFORMED++)); ((ERRORS++)); }

# ------------------------------------------------------------------------------
# 3. GLOBAL AUDIT VARIABLES
# ------------------------------------------------------------------------------
DEF_PASS_MAX_DAYS="Unknown"
DEF_PASS_MIN_DAYS="Unknown"
DEF_PASS_WARN_AGE="Unknown"

ACCOUNTS_AUDITED=0
ACCOUNTS_NO_EXPIRATION=0
ACCOUNTS_EXPIRED=0

ACCOUNT_ISSUES_LIST=()

CHECKS_PERFORMED=0
PASSED_CHECKS=0
WARNINGS=0
ERRORS=0

# Security Thresholds
THRESHOLD_MAX_DAYS=90
THRESHOLD_WARN_DAYS=7

# ------------------------------------------------------------------------------
# 4. DATA COLLECTION
# ------------------------------------------------------------------------------
collect_aging_defaults() {
    if [ -f /etc/login.defs ]; then
        DEF_PASS_MAX_DAYS=$(grep -E "^PASS_MAX_DAYS" /etc/login.defs | awk '{print $2}' || echo "Unknown")
        DEF_PASS_MIN_DAYS=$(grep -E "^PASS_MIN_DAYS" /etc/login.defs | awk '{print $2}' || echo "Unknown")
        DEF_PASS_WARN_AGE=$(grep -E "^PASS_WARN_AGE" /etc/login.defs | awk '{print $2}' || echo "Unknown")
    fi
}

collect_user_aging_data() {
    # If not root, we cannot read /etc/shadow
    if [ "$EUID" -ne 0 ]; then
        return
    fi

    if [ ! -r /etc/shadow ]; then
        echo -e "  ${LIGHT_RED}✖ CRITICAL: Cannot read /etc/shadow despite root privileges!${RESET}"
        exit 1
    fi

    local current_epoch
    current_epoch=$(date +%s)
    local current_days=$(( current_epoch / 86400 ))

    while IFS=: read -r user pass last_changed min_days max_days warn_days inactive expire; do
        # Only audit human users (UID 1000+) and root
        local uid
        uid=$(id -u "$user" 2>/dev/null)
        
        if [[ -n "$uid" ]] && { [ "$uid" -eq 0 ] || [ "$uid" -ge 1000 ]; }; then
            
            # Skip completely locked or disabled accounts (e.g. *, !)
            if [[ "$pass" == "!"* ]] || [[ "$pass" == "*"* ]] || [[ -z "$pass" ]]; then
                continue
            fi
            
            ((ACCOUNTS_AUDITED++))

            local issue_flag=0
            local issue_desc=""

            # Check: No Expiration
            if [[ "$max_days" == "99999" ]] || [[ -z "$max_days" ]]; then
                ((ACCOUNTS_NO_EXPIRATION++))
                issue_flag=1
                issue_desc="No password expiration (Max Days: 99999)"
            fi

            # Check: Expired passwords
            if [[ -n "$last_changed" ]] && [[ -n "$max_days" ]] && [[ "$max_days" != "99999" ]]; then
                local expiration_day=$(( last_changed + max_days ))
                if [[ "$current_days" -gt "$expiration_day" ]]; then
                    ((ACCOUNTS_EXPIRED++))
                    issue_flag=2
                    issue_desc="Password EXPIRED!"
                fi
            fi
            
            if [ "$issue_flag" -gt 0 ]; then
                ACCOUNT_ISSUES_LIST+=("$user|$issue_desc|$issue_flag")
            fi
            
        fi
    done < /etc/shadow
}

# ------------------------------------------------------------------------------
# 5. DATA PRESENTATION
# ------------------------------------------------------------------------------
display_aging_summary() {
    module_header "PASSWORD AGING AUDIT" "5"

    section "GLOBAL DEFAULTS (/etc/login.defs)"
    
    value_row "Default Max Password Age" "${DEF_PASS_MAX_DAYS} days"
    value_row "Default Min Password Age" "${DEF_PASS_MIN_DAYS} days"
    value_row "Default Warning Period" "${DEF_PASS_WARN_AGE} days"
    
    echo
    section "USER ACCOUNT STATUS"
    
    if [ "$EUID" -ne 0 ]; then
        value_row "Accounts Audited" "${YELLOW}Requires Root${RESET}"
        return
    fi
    
    value_row "Active Accounts Audited" "$ACCOUNTS_AUDITED"
    value_row "Accounts with No Expiration" "$ACCOUNTS_NO_EXPIRATION"
    
    if [ "$ACCOUNTS_EXPIRED" -gt 0 ]; then
        value_row "Accounts Currently Expired" "${LIGHT_RED}${ACCOUNTS_EXPIRED}${RESET}"
    else
        value_row "Accounts Currently Expired" "${LIGHT_GREEN}0${RESET}"
    fi
    echo
}

display_aging_tables() {
    if [ "$EUID" -ne 0 ] || [ ${#ACCOUNT_ISSUES_LIST[@]} -eq 0 ]; then
        return
    fi

    section "AGING POLICY VIOLATIONS"
    
    printf "  ${LCYAN}%-18s %-40s${RESET}\n" "USER" "ISSUE DETECTED"
    echo -e "  ${DIM}${SHORT_LINE}──────────────${RESET}"

    for entry in "${ACCOUNT_ISSUES_LIST[@]}"; do
        local user="${entry%%|*}"
        local rest="${entry#*|}"
        local desc="${rest%%|*}"
        local flag="${rest#*|}"

        local color="${YELLOW}"
        if [ "$flag" -eq 2 ]; then
            color="${LIGHT_RED}"
        fi

        printf "  ${WHITE}%-18s${RESET} ${color}%-40s${RESET}\n" "${user:0:17}" "${desc}"
    done
    echo
}

# ------------------------------------------------------------------------------
# 6. SECURITY ASSESSMENT
# ------------------------------------------------------------------------------
perform_security_checks() {
    section "SECURITY ASSESSMENT"

    # Check 1: Root Privilege Verification
    if [ "$EUID" -ne 0 ]; then
        row "Privilege Level" "Root required to read /etc/shadow" "bad"
        increment_error
        return
    else
        row "Privilege Level" "Root privileges detected" "ok"
        increment_pass
    fi

    # Check 2: Global Max Days
    if [[ "$DEF_PASS_MAX_DAYS" == "99999" ]] || [[ "$DEF_PASS_MAX_DAYS" == "Unknown" ]]; then
        row "Global Max Age" "Default policy allows non-expiring passwords" "warn"
        echo -e "  ${YELLOW}▶ Best Practice: Set PASS_MAX_DAYS to $THRESHOLD_MAX_DAYS or less.${RESET}"
        increment_warn
    elif [[ "$DEF_PASS_MAX_DAYS" -gt "$THRESHOLD_MAX_DAYS" ]]; then
        row "Global Max Age" "Max age ($DEF_PASS_MAX_DAYS) exceeds secure threshold ($THRESHOLD_MAX_DAYS)" "warn"
        increment_warn
    else
        row "Global Max Age" "Securely configured ($DEF_PASS_MAX_DAYS days)" "ok"
        increment_pass
    fi

    # Check 3: Global Warning Age
    if [[ "$DEF_PASS_WARN_AGE" == "Unknown" ]] || [[ "$DEF_PASS_WARN_AGE" -lt "$THRESHOLD_WARN_DAYS" ]]; then
        row "Warning Period" "Warning period ($DEF_PASS_WARN_AGE) is too short" "warn"
        increment_warn
    else
        row "Warning Period" "Properly configured ($DEF_PASS_WARN_AGE days)" "ok"
        increment_pass
    fi

    # Check 4: User-Level Expiration Overrides
    if [ "$ACCOUNTS_NO_EXPIRATION" -gt 0 ]; then
        row "User Policies" "$ACCOUNTS_NO_EXPIRATION account(s) have non-expiring passwords" "warn"
        echo -e "  ${YELLOW}▶ Fix using: chage -M $THRESHOLD_MAX_DAYS <user>${RESET}"
        increment_warn
    else
        row "User Policies" "All audited accounts enforce password expiration" "ok"
        increment_pass
    fi

    # Check 5: Expired Accounts
    if [ "$ACCOUNTS_EXPIRED" -gt 0 ]; then
        row "Expired Accounts" "$ACCOUNTS_EXPIRED active account(s) have expired passwords!" "bad"
        increment_error
    else
        row "Expired Accounts" "No expired passwords found" "ok"
        increment_pass
    fi
    echo
}

# ------------------------------------------------------------------------------
# 7. AUDIT SUMMARY & COMPLETION
# ------------------------------------------------------------------------------
show_audit_summary() {
    section "AUDIT SUMMARY"

    value_row "Checks Performed" "$CHECKS_PERFORMED"
    value_row "Passed" "${LIGHT_GREEN}${PASSED_CHECKS}${RESET}"
    value_row "Warnings" "${YELLOW}${WARNINGS}${RESET}"
    value_row "Errors" "${LIGHT_RED}${ERRORS}${RESET}"
    
    echo

    if [ "$ERRORS" -gt 0 ]; then
        value_row "Security Status" "${LIGHT_RED}✖ ACTION REQUIRED${RESET}"
    elif [ "$WARNINGS" -gt 0 ]; then
        value_row "Security Status" "${YELLOW}⚠ REVIEW RECOMMENDED${RESET}"
    else
        value_row "Security Status" "${LIGHT_GREEN}✔ SECURE${RESET}"
    fi

    echo
    echo -e "  ${DIM}${LINE}${RESET}"
    echo -e "  ${LIGHT_GREEN}[SUCCESS] Module completed successfully.${RESET}"
    echo -e "  ${DIM}${LINE}${RESET}"
    echo
}

# ------------------------------------------------------------------------------
# 8. MAIN EXECUTION CONTROLLER
# ------------------------------------------------------------------------------
main() {
    collect_aging_defaults
    collect_user_aging_data
    display_aging_summary
    display_aging_tables
    perform_security_checks
    show_audit_summary
    return 0
}

main "$@"
