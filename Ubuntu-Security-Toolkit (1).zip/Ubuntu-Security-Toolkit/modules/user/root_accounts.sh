clear
#!/usr/bin/env bash
# ==============================================================================
#   MODULE: Root Accounts
#   Advanced Ubuntu Security Toolkit
#   Purpose: Identify and audit accounts with root-level privileges or UID 0.
#            Detect additional root-equivalent accounts that may represent risks.
# ==============================================================================

set -o pipefail

# ------------------------------------------------------------------------------
# 1. BOOTSTRAP & LIBRARY SOURCING
# ------------------------------------------------------------------------------
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" >/dev/null 2>&1 && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/../.." >/dev/null 2>&1 && pwd)"

# Fallback basic colors if common.sh doesn't load them properly
RESET='\033[0m'
RED='\033[0;31m'
LIGHT_RED='\033[1;31m'
GREEN='\033[0;32m'
LIGHT_GREEN='\033[1;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
LCYAN='\033[1;36m'
CYAN='\033[0;36m'
MAGENTA='\033[1;35m'
WHITE='\033[1;37m'
BOLD='\033[1m'
DIM='\033[2m'
LINE="──────────────────────────────────────────────────────────────────────"
SHORT_LINE="────────────────────────────────────────────────"

if [ -f "$PROJECT_ROOT/lib/common.sh" ]; then
    # shellcheck source=/dev/null
    source "$PROJECT_ROOT/lib/common.sh"
    # Map common.sh colors to required local names if they exist
    [ -n "$NC" ] && RESET="$NC"
    [ -n "$LRED" ] && LIGHT_RED="$LRED"
    [ -n "$LGREEN" ] && LIGHT_GREEN="$LGREEN"
else
    printf "${LIGHT_RED}✖ WARNING: Cannot find lib/common.sh. Using fallback formatting.${RESET}\n"
fi

# ------------------------------------------------------------------------------
# 2. LOCAL FUNCTION OVERRIDES (Ensuring structural consistency)
# ------------------------------------------------------------------------------
# Override to satisfy the strict MODULE 6 / 7 requirement
module_header() {
    local module_name="$1"
    local module_number="$2"

    echo
    echo -e "${BLUE}${BOLD}  ╔══════════════════════════════════════════════════════════════════════╗${RESET}"
    echo -e "${BLUE}${BOLD}  ║                                                                      ║${RESET}"
    printf "${BLUE}${BOLD}  ║%*s%s%*s║${RESET}\n" \
        $(( (68 - ${#module_name}) / 2 )) "" \
        "$module_name" \
        $(( 68 - ${#module_name} - (68 - ${#module_name}) / 2 )) ""
    echo -e "${BLUE}${BOLD}  ║                                                                      ║${RESET}"
    printf "${BLUE}${BOLD}  ║%*sMODULE %s / 7%*s║${RESET}\n" \
        $(( (68 - 12) / 2 )) "" \
        "$module_number" \

        $(( 68 - 12 - (68 - 12) / 2 )) ""
    echo -e "${BLUE}${BOLD}  ╚══════════════════════════════════════════════════════════════════════╝${RESET}"
    echo
}

# Provide local fallbacks for formatting functions in case common.sh is incomplete
section() {
    local title="$1"
    echo -e "  ${LCYAN}${BOLD}${title}${RESET}"
    echo -e "  ${DIM}${LINE}${RESET}"
}

value_row() {
    local label="$1"
    local value="$2"
    printf "  ${WHITE}%-32s${RESET} : ${CYAN}%s${RESET}\n" "$label" "$value"
}

row() {
    local label="$1"
    local value="$2"
    local status="${3:-info}"
    local colour icon

    case "$status" in
        ok)   colour="${LIGHT_GREEN}"; icon="✔" ;;
        warn) colour="${YELLOW}";      icon="⚠" ;;
        bad)  colour="${LIGHT_RED}";   icon="✖" ;;
        *)    colour="${LCYAN}";       icon="ℹ" ;;
    esac

    printf "  ${WHITE}%-32s${RESET} ${colour}%s  %s${RESET}\n" "$label" "$icon" "$value"
}

increment_pass()  { ((CHECKS_PERFORMED++)); ((PASSED_CHECKS++)); }
increment_warn()  { ((CHECKS_PERFORMED++)); ((WARNINGS++)); }
increment_error() { ((CHECKS_PERFORMED++)); ((ERRORS++)); }

# ------------------------------------------------------------------------------
# 3. GLOBAL AUDIT VARIABLES
# ------------------------------------------------------------------------------
UID_0_USERS=()
GID_0_USERS=()

ROOT_SHELL="Unknown"
ROOT_LOCKED="Unknown"
ROOT_HAS_PASSWORD="Unknown"

CHECKS_PERFORMED=0
PASSED_CHECKS=0
WARNINGS=0
ERRORS=0

# ------------------------------------------------------------------------------
# 4. DATA COLLECTION
# ------------------------------------------------------------------------------
collect_root_data() {
    if [ ! -r /etc/passwd ]; then
        echo -e "  ${LIGHT_RED}✖ CRITICAL: Cannot read /etc/passwd!${RESET}"
        exit 1
    fi

    # Read /etc/passwd for UID 0 and GID 0 accounts
    while IFS=: read -r user pass uid gid info home shell; do
        if [ "$uid" -eq 0 ]; then
            UID_0_USERS+=("$user:$home:$shell")
            if [ "$user" = "root" ]; then
                ROOT_SHELL="$shell"
            fi
        fi
        
        # Check for non-root users assigned to the root group (GID 0)
        if [ "$gid" -eq 0 ] && [ "$user" != "root" ]; then
            GID_0_USERS+=("$user:$home:$shell")
        fi
    done < /etc/passwd

    # Read /etc/shadow for root password status (Requires Root privileges)
    if [ "$EUID" -eq 0 ] && [ -r /etc/shadow ]; then
        local shadow_val
        shadow_val=$(awk -F: '$1=="root" {print $2}' /etc/shadow 2>/dev/null)
        
        if [[ -z "$shadow_val" ]]; then
            ROOT_HAS_PASSWORD="No (Empty)"
            ROOT_LOCKED="No"
        elif [[ "$shadow_val" == "!"* ]] || [[ "$shadow_val" == "*"* ]]; then
            ROOT_HAS_PASSWORD="Yes"
            ROOT_LOCKED="Yes (Secure Default)"
        else
            ROOT_HAS_PASSWORD="Yes"
            ROOT_LOCKED="No (Password Login Enabled)"
        fi
    else
        ROOT_HAS_PASSWORD="Unknown (Requires Root)"
        ROOT_LOCKED="Unknown (Requires Root)"
    fi
}

# ------------------------------------------------------------------------------
# 5. DATA PRESENTATION
# ------------------------------------------------------------------------------
display_root_summary() {
    module_header "ROOT ACCOUNTS AUDIT" "6"

    section "ROOT ACCOUNT OVERVIEW"
    
    value_row "Total UID 0 Accounts" "${#UID_0_USERS[@]}"
    value_row "Non-Root GID 0 Accounts" "${#GID_0_USERS[@]}"
    value_row "Root Login Shell" "$ROOT_SHELL"
    value_row "Root Account Locked" "$ROOT_LOCKED"
    echo
}

display_privileged_tables() {
    section "UID 0 (ROOT-EQUIVALENT) ACCOUNTS"
    
    if [ ${#UID_0_USERS[@]} -eq 0 ]; then
        echo -e "  ${LIGHT_RED}✖ CRITICAL: No UID 0 accounts found! System may be broken.${RESET}\n"
    else
        printf "  ${LCYAN}%-16s %-24s %-16s${RESET}\n" "USER" "HOME DIR" "SHELL"
        echo -e "  ${DIM}${SHORT_LINE}───────────────${RESET}"

        for entry in "${UID_0_USERS[@]}"; do
            local user="${entry%%:*}"
            local rest="${entry#*:}"
            local home="${rest%%:*}"
            local shell="${rest#*:}"

            local color="${WHITE}"
            if [ "$user" != "root" ]; then
                color="${LIGHT_RED}"
            fi

            printf "  ${color}%-16s${RESET} %-24s %-16s\n" "${user:0:15}" "${home:0:23}" "${shell:0:15}"
        done
        echo
    fi

    if [ ${#GID_0_USERS[@]} -gt 0 ]; then
        section "GID 0 (ROOT GROUP) NON-ROOT ACCOUNTS"
        
        printf "  ${LCYAN}%-16s %-24s %-16s${RESET}\n" "USER" "HOME DIR" "SHELL"
        echo -e "  ${DIM}${SHORT_LINE}───────────────${RESET}"

        for entry in "${GID_0_USERS[@]}"; do
            local user="${entry%%:*}"
            local rest="${entry#*:}"
            local home="${rest%%:*}"
            local shell="${rest#*:}"

            printf "  ${YELLOW}%-16s${RESET} %-24s %-16s\n" "${user:0:15}" "${home:0:23}" "${shell:0:15}"
        done
        echo
    fi
}

# ------------------------------------------------------------------------------
# 6. SECURITY ASSESSMENT
# ------------------------------------------------------------------------------
perform_security_checks() {
    section "SECURITY ASSESSMENT"

    # Check 1: Root Privilege Verification
    if [ "$EUID" -ne 0 ]; then
        row "Privilege Level" "Root required to audit shadow file" "warn"
        increment_warn
    else
        row "Privilege Level" "Root privileges active" "ok"
        increment_pass
    fi

    # Check 2: UID 0 Exclusivity
    if [ ${#UID_0_USERS[@]} -eq 1 ] && [ "${UID_0_USERS[0]%%:*}" = "root" ]; then
        row "UID 0 Accounts" "Only 'root' has UID 0" "ok"
        increment_pass
    else
        row "UID 0 Accounts" "Multiple UID 0 accounts exist!" "bad"
        echo -e "  ${LIGHT_RED}▶ Rogue accounts detected. These have full system control.${RESET}"
        increment_error
    fi

    # Check 3: GID 0 Usage by Non-Root
    if [ ${#GID_0_USERS[@]} -eq 0 ]; then
        row "GID 0 Membership" "No unauthorized users in root group" "ok"
        increment_pass
    else
        row "GID 0 Membership" "${#GID_0_USERS[@]} non-root user(s) in GID 0!" "warn"
        echo -e "  ${YELLOW}▶ Best Practice: Regular users should not share the root primary group.${RESET}"
        increment_warn
    fi

    # Check 4: Root Password Lock (Ubuntu Default)
    if [ "$EUID" -eq 0 ]; then
        if [[ "$ROOT_LOCKED" == "Yes"* ]]; then
            row "Root Login Status" "Password login disabled (Secure)" "ok"
            increment_pass
        elif [[ "$ROOT_LOCKED" == "No"* ]]; then
            if [[ "$ROOT_HAS_PASSWORD" == "No"* ]]; then
                row "Root Login Status" "Root password is EMPTY!" "bad"
                increment_error
            else
                row "Root Login Status" "Root password login is enabled" "warn"
                echo -e "  ${YELLOW}▶ Ubuntu default disables root password. Ensure this is intentional.${RESET}"
                increment_warn
            fi
        fi
    fi
    echo
}

# ------------------------------------------------------------------------------
# 7. AUDIT SUMMARY & COMPLETION
# ------------------------------------------------------------------------------
show_audit_summary() {
    section "AUDIT SUMMARY"

    value_row "Checks Performed" "$CHECKS_PERFORMED"
    value_row "Passed" "${LIGHT_GREEN}${PASSED_CHECKS}${RESET}"
    value_row "Warnings" "${YELLOW}${WARNINGS}${RESET}"
    value_row "Errors" "${LIGHT_RED}${ERRORS}${RESET}"
    
    echo

    if [ "$ERRORS" -gt 0 ]; then
        value_row "Security Status" "${LIGHT_RED}✖ ACTION REQUIRED${RESET}"
    elif [ "$WARNINGS" -gt 0 ]; then
        value_row "Security Status" "${YELLOW}⚠ REVIEW RECOMMENDED${RESET}"
    else
        value_row "Security Status" "${LIGHT_GREEN}✔ SECURE${RESET}"
    fi

    echo
    echo -e "  ${DIM}${LINE}${RESET}"
    echo -e "  ${LIGHT_GREEN}[SUCCESS] Module completed successfully.${RESET}"
    echo -e "  ${DIM}${LINE}${RESET}"
    echo
}

# ------------------------------------------------------------------------------
# 8. MAIN EXECUTION CONTROLLER
# ------------------------------------------------------------------------------
main() {
    collect_root_data
    display_root_summary
    display_privileged_tables
    perform_security_checks
    show_audit_summary
    return 0
}

main "$@"
