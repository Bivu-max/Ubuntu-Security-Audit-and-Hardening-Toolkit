clear
#!/usr/bin/env bash
# ==============================================================================
#   MODULE: Human Users
#   Advanced Ubuntu Security Toolkit
#   Purpose: Identify and audit human/user accounts rather than system accounts.
# ==============================================================================

set -o pipefail

# ------------------------------------------------------------------------------
# 1. BOOTSTRAP & LIBRARY SOURCING
# ------------------------------------------------------------------------------
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" >/dev/null 2>&1 && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/../.." >/dev/null 2>&1 && pwd)"

# Fallback color definitions in case common.sh is missing or incomplete
RESET='\033[0m'
RED='\033[0;31m'
LIGHT_RED='\033[1;31m'
GREEN='\033[0;32m'
LIGHT_GREEN='\033[1;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
LCYAN='\033[1;36m'
CYAN='\033[0;36m'
MAGENTA='\033[1;35m'
WHITE='\033[1;37m'
BOLD='\033[1m'
DIM='\033[2m'
LINE="──────────────────────────────────────────────────────────────────────"
SHORT_LINE="────────────────────────────────────────────────"

if [ -f "$PROJECT_ROOT/lib/common.sh" ]; then
    source "$PROJECT_ROOT/lib/common.sh"
    # Ensure missing mapped colors required by this module's design are defined
    [ -z "$RESET" ] && RESET="${NC}"
    [ -z "$LIGHT_RED" ] && LIGHT_RED="${LRED}"
    [ -z "$LIGHT_GREEN" ] && LIGHT_GREEN="${LGREEN}"
else
    printf "${LIGHT_RED}✖ WARNING: Cannot find lib/common.sh. Using fallback formatting.${RESET}\n"
fi

# ------------------------------------------------------------------------------
# 2. LOCAL FUNCTION OVERRIDES
# ------------------------------------------------------------------------------
# Override to satisfy the strict MODULE 2 / 7 requirement
module_header() {
    local module_name="$1"
    local module_number="$2"

    echo
    echo -e "${BLUE}${BOLD}  ╔══════════════════════════════════════════════════════════════════════╗${RESET}"
    echo -e "${BLUE}${BOLD}  ║                                                                      ║${RESET}"
    printf "${BLUE}${BOLD}  ║%*s%s%*s║${RESET}\n" \
        $(( (68 - ${#module_name}) / 2 )) "" \
        "$module_name" \
        $(( 68 - ${#module_name} - (68 - ${#module_name}) / 2 )) ""
    echo -e "${BLUE}${BOLD}  ║                                                                      ║${RESET}"
    printf "${BLUE}${BOLD}  ║%*sMODULE %s / 7%*s║${RESET}\n" \
        $(( (68 - 12) / 2 )) "" \
        "$module_number" \
        $(( 68 - 12 - (68 - 12) / 2 )) ""
    echo -e "${BLUE}${BOLD}  ╚══════════════════════════════════════════════════════════════════════╝${RESET}"
    echo
}

section() {
    local title="$1"
    echo -e "  ${LCYAN}${BOLD}${title}${RESET}"
    echo -e "  ${DIM}${LINE}${RESET}"
}

value_row() {
    local label="$1"
    local value="$2"
    printf "  ${WHITE}%-32s${RESET} : ${CYAN}%s${RESET}\n" "$label" "$value"
}

row() {
    local label="$1"
    local value="$2"
    local status="${3:-info}"
    local colour icon

    case "$status" in
        ok)   colour="${LIGHT_GREEN}"; icon="✔" ;;
        warn) colour="${YELLOW}";      icon="⚠" ;;
        bad)  colour="${LIGHT_RED}";   icon="✖" ;;
        *)    colour="${LCYAN}";       icon="ℹ" ;;
    esac

    printf "  ${WHITE}%-32s${RESET} ${colour}%s  %s${RESET}\n" "$label" "$icon" "$value"
}

increment_pass()  { ((CHECKS_PERFORMED++)); ((PASSED_CHECKS++)); }
increment_warn()  { ((CHECKS_PERFORMED++)); ((WARNINGS++)); }
increment_error() { ((CHECKS_PERFORMED++)); ((ERRORS++)); }

# ------------------------------------------------------------------------------
# 3. GLOBAL AUDIT VARIABLES
# ------------------------------------------------------------------------------
TOTAL_HUMAN_USERS=0
ACTIVE_HUMAN_USERS=0
LOCKED_HUMAN_USERS=0

CHECKS_PERFORMED=0
PASSED_CHECKS=0
WARNINGS=0
ERRORS=0

HUMAN_USERS_LIST=()
MISSING_HOMES_LIST=()
EMPTY_PASSWORDS_LIST=()

# ------------------------------------------------------------------------------
# 4. DATA COLLECTION
# ------------------------------------------------------------------------------
collect_user_data() {
    if [ ! -r /etc/passwd ]; then
        echo -e "  ${LIGHT_RED}✖ CRITICAL: Cannot read /etc/passwd!${RESET}"
        exit 1
    fi

    while IFS=: read -r user pass uid gid info home shell; do
        # Identify Human Users: UID 0 (root) and UID >= 1000 (excluding nobody 65534)
        if [ "$uid" -eq 0 ] || ([ "$uid" -ge 1000 ] && [ "$uid" -lt 65534 ]); then
            HUMAN_USERS_LIST+=("$user:$uid:$home:$shell")
            ((TOTAL_HUMAN_USERS++))

            # Track missing home directories
            if [ ! -d "$home" ] && [ "$home" != "/nonexistent" ]; then
                MISSING_HOMES_LIST+=("$user")
            fi

            # Check account status if running as root
            if [ "$EUID" -eq 0 ] && [ -r /etc/shadow ]; then
                local shadow_val
                shadow_val=$(awk -F: -v u="$user" '$1==u {print $2}' /etc/shadow 2>/dev/null)
                
                if [[ -z "$shadow_val" ]]; then
                    EMPTY_PASSWORDS_LIST+=("$user")
                    ((ACTIVE_HUMAN_USERS++))
                elif [[ "$shadow_val" == "!"* ]] || [[ "$shadow_val" == "*"* ]]; then
                    ((LOCKED_HUMAN_USERS++))
                else
                    ((ACTIVE_HUMAN_USERS++))
                fi
            fi
        fi
    done < /etc/passwd
}

# ------------------------------------------------------------------------------
# 5. DATA PRESENTATION
# ------------------------------------------------------------------------------
display_user_summary() {
    module_header "HUMAN USERS AUDIT" "2"

    section "HUMAN ACCOUNT SUMMARY"
    
    value_row "Total Human Users" "$TOTAL_HUMAN_USERS"
    
    if [ "$EUID" -eq 0 ]; then
        value_row "Active Human Accounts" "$ACTIVE_HUMAN_USERS"
        value_row "Locked Human Accounts" "$LOCKED_HUMAN_USERS"
    else
        value_row "Active Human Accounts" "${YELLOW}Unknown (Requires Root)${RESET}"
        value_row "Locked Human Accounts" "${YELLOW}Unknown (Requires Root)${RESET}"
    fi
    echo
}

display_user_tables() {
    section "HUMAN USER LIST (UID >= 1000 & UID 0)"
    
    printf "  ${LCYAN}%-16s %-6s %-10s %-18s %-12s${RESET}\n" "USER" "UID" "STATUS" "HOME DIR" "SHELL"
    echo -e "  ${DIM}${SHORT_LINE}────────────────────────${RESET}"

    for u in "${HUMAN_USERS_LIST[@]}"; do
        local user="${u%%:*}"
        local rest="${u#*:}"
        local uid="${rest%%:*}"
        rest="${rest#*:}"
        local home="${rest%%:*}"
        local shell="${rest#*:}"

        local status="Unknown"
        local status_color="${WHITE}"
        
        # Determine Password Status
        if [ "$EUID" -eq 0 ] && [ -r /etc/shadow ]; then
            local shadow_val
            shadow_val=$(awk -F: -v usr="$user" '$1==usr {print $2}' /etc/shadow 2>/dev/null)
            
            if [[ -z "$shadow_val" ]]; then
                status="NO PASS"
                status_color="${LIGHT_RED}"
            elif [[ "$shadow_val" == "!"* ]] || [[ "$shadow_val" == "*"* ]]; then
                status="Locked"
                status_color="${DIM}"
            else
                status="Active"
                status_color="${LIGHT_GREEN}"
            fi
        fi

        # Highlight missing home directory
        local display_home="$home"
        if [ ! -d "$home" ] && [ "$home" != "/nonexistent" ]; then
            display_home="${YELLOW}MISSING!${RESET}"
        else
            display_home="${home:0:18}"
        fi

        # Extract just the binary name of the shell for clean output
        local shell_bin
        shell_bin=$(basename "$shell" 2>/dev/null || echo "$shell")

        printf "  ${WHITE}%-16s${RESET} %-6s ${status_color}%-10s${RESET} %-27s %-12s\n" \
            "${user:0:15}" "$uid" "$status" "$display_home" "${shell_bin:0:12}"
    done
    echo
}

# ------------------------------------------------------------------------------
# 6. SECURITY ASSESSMENT
# ------------------------------------------------------------------------------
perform_security_checks() {
    section "SECURITY ASSESSMENT"

    # Check 1: Root privilege level
    if [ "$EUID" -ne 0 ]; then
        row "Privilege Level" "Run as root to audit passwords" "warn"
        increment_warn
    else
        row "Privilege Level" "Root privileges detected" "ok"
        increment_pass
    fi

    # Check 2: Missing Home Directories
    if [ ${#MISSING_HOMES_LIST[@]} -gt 0 ]; then
        row "Home Directories" "${#MISSING_HOMES_LIST[@]} users missing home directories" "warn"
        echo -e "  ${YELLOW}▶ Affected users: $(echo "${MISSING_HOMES_LIST[@]}")${RESET}"
        increment_warn
    else
        row "Home Directories" "All human users have valid homes" "ok"
        increment_pass
    fi

    # Check 3: Empty Passwords (requires root)
    if [ "$EUID" -eq 0 ]; then
        if [ ${#EMPTY_PASSWORDS_LIST[@]} -gt 0 ]; then
            row "Empty Passwords" "${#EMPTY_PASSWORDS_LIST[@]} users have NO password set!" "bad"
            echo -e "  ${LIGHT_RED}▶ Affected users: $(echo "${EMPTY_PASSWORDS_LIST[@]}")${RESET}"
            increment_error
        else
            row "Empty Passwords" "No empty passwords detected" "ok"
            increment_pass
        fi
    fi
    echo
}

# ------------------------------------------------------------------------------
# 7. AUDIT SUMMARY & COMPLETION
# ------------------------------------------------------------------------------
show_audit_summary() {
    section "AUDIT SUMMARY"

    value_row "Checks Performed" "$CHECKS_PERFORMED"
    value_row "Passed" "${LIGHT_GREEN}${PASSED_CHECKS}${RESET}"
    value_row "Warnings" "${YELLOW}${WARNINGS}${RESET}"
    value_row "Errors" "${LIGHT_RED}${ERRORS}${RESET}"
    
    echo

    if [ "$ERRORS" -gt 0 ]; then
        value_row "Security Status" "${LIGHT_RED}✖ ACTION REQUIRED${RESET}"
    elif [ "$WARNINGS" -gt 0 ]; then
        value_row "Security Status" "${YELLOW}⚠ REVIEW RECOMMENDED${RESET}"
    else
        value_row "Security Status" "${LIGHT_GREEN}✔ SECURE${RESET}"
    fi

    echo
    echo -e "  ${DIM}${LINE}${RESET}"
    echo -e "  ${LIGHT_GREEN}[SUCCESS] Module completed successfully.${RESET}"
    echo -e "  ${DIM}${LINE}${RESET}"
    echo
}

# ------------------------------------------------------------------------------
# 8. MAIN EXECUTION CONTROLLER
# ------------------------------------------------------------------------------
main() {
    collect_user_data
    display_user_summary
    display_user_tables
    perform_security_checks
    show_audit_summary
    return 0
}

main "$@"

