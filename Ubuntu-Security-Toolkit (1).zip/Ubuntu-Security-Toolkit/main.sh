#!/usr/bin/env bash
# ==============================================================================
#   main.sh
#   Advanced Ubuntu Security Hardening & Audit Toolkit
#   Master Controller
# ==============================================================================

# ==============================================================================
#   SAFETY & SHELL SETTINGS
# ==============================================================================

set -o pipefail

# ==============================================================================
#   PATH CONFIGURATION
# ==============================================================================

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

LIB_DIR="$SCRIPT_DIR/lib"
MODULE_DIR="$SCRIPT_DIR/modules"
LOG_DIR="$SCRIPT_DIR/logs"
BACKUP_DIR="$SCRIPT_DIR/backups"
CONFIG_DIR="$SCRIPT_DIR/config"
REPORT_DIR="$SCRIPT_DIR/reports"

COMMON="$LIB_DIR/common.sh"

# ==============================================================================
#   LOAD COMMON LIBRARY
# ==============================================================================

if [[ ! -f "$COMMON" ]]; then
    echo
    echo -e "\033[1;31m[ERROR]\033[0m common.sh not found!"
    echo
    echo -e "\033[1;36mExpected:\033[0m"
    echo "$COMMON"
    echo
    exit 1
fi

source "$COMMON"

# ==============================================================================
#   DIRECTORIES
# ==============================================================================

mkdir -p "$LOG_DIR"
mkdir -p "$BACKUP_DIR"
mkdir -p "$CONFIG_DIR"
mkdir -p "$REPORT_DIR"

# ==============================================================================
#   TOOL INFORMATION
# ==============================================================================

TOOL_NAME="Advanced Ubuntu Security Hardening & Audit Toolkit"
VERSION="1.0.0"

LOG_FILE="$LOG_DIR/main_$(date '+%Y%m%d_%H%M%S').log"

# ==============================================================================
#   LOGGING
# ==============================================================================

exec > >(tee -a "$LOG_FILE") 2>&1

# ==============================================================================
#   COLORS
# ==============================================================================

RESET='\033[0m'

# Main interface
CYAN='\033[1;36m'
BLUE='\033[1;34m'
MAGENTA='\033[1;35m'
WHITE='\033[1;37m'

# Status colors
GREEN='\033[1;32m'
YELLOW='\033[1;33m'
RED='\033[1;31m'

# Secondary colors
DIM='\033[2m'
BOLD='\033[1m'

# ==============================================================================
#   BASIC FUNCTIONS
# ==============================================================================

pause_screen() {
    echo
    echo -e "${DIM}${CYAN}Press Enter to continue...${RESET}"
    read -r _
}

error_message() {
    echo -e "${RED}[ERROR]${RESET} $1"
}

success_message() {
    echo -e "${GREEN}[SUCCESS]${RESET} $1"
}

warning_message() {
    echo -e "${YELLOW}[WARNING]${RESET} $1"
}

info_message() {
    echo -e "${CYAN}[INFO]${RESET} $1"
}

# ==============================================================================
#   ROOT CHECK
# ==============================================================================

check_root() {

    if [[ $EUID -ne 0 ]]; then

        echo
        echo -e "${RED}==========================================================================${RESET}"
        echo -e "${RED}${BOLD}                         ROOT ACCESS REQUIRED${RESET}"
        echo -e "${RED}==========================================================================${RESET}"
        echo
        echo "This toolkit requires administrator privileges."
        echo
        echo -e "${CYAN}Run:${RESET}"
        echo
        echo -e "${GREEN}    sudo ./main.sh${RESET}"
        echo
        echo -e "${RED}==========================================================================${RESET}"
        echo

        exit 1
    fi
}

# ==============================================================================
#   UBUNTU CHECK
# ==============================================================================

check_ubuntu() {

    if [[ ! -f /etc/os-release ]]; then
        return 1
    fi

    source /etc/os-release

    if [[ "${ID:-}" == "ubuntu" ]]; then
        return 0
    fi

    return 1
}

# ==============================================================================
#   BANNER
# ==============================================================================

show_banner() {

    clear

    echo
    echo -e "${CYAN}============================================================================${RESET}"
    echo
    echo -e "${BLUE}        ██████╗ ███████╗ ██████╗██╗   ██╗██████╗ ██╗████████╗██╗   ██╗${RESET}"
    echo -e "${BLUE}       ██╔═══██╗██╔════╝██╔════╝██║   ██║██╔══██╗██║╚══██╔══╝╚██╗ ██╔╝${RESET}"
    echo -e "${BLUE}       ██║   ██║█████╗  ██║     ██║   ██║██████╔╝██║   ██║    ╚████╔╝ ${RESET}"
    echo -e "${BLUE}       ██║   ██║██╔══╝  ██║     ╚██╗ ██╔╝██╔══██╗██║   ██║     ╚██╔╝  ${RESET}"
    echo -e "${BLUE}       ╚██████╔╝███████╗╚██████╗ ╚████╔╝ ██║  ██║██║   ██║      ██║   ${RESET}"
    echo -e "${BLUE}        ╚═════╝ ╚══════╝ ╚═════╝  ╚═══╝  ╚═╝  ╚═╝╚═╝   ╚═╝      ╚═╝   ${RESET}"
    echo
    echo -e "${MAGENTA}${BOLD}             ADVANCED UBUNTU SECURITY HARDENING & AUDIT TOOLKIT${RESET}"
    echo
    echo -e "${CYAN}============================================================================${RESET}"
    echo
    echo -e "${WHITE} Version : ${GREEN}$VERSION${RESET}"
    echo -e "${WHITE} Host    : ${CYAN}$(hostname)${RESET}"
    echo -e "${WHITE} Date    : ${YELLOW}$(date '+%d-%m-%Y %H:%M:%S')${RESET}"
    echo -e "${WHITE} User    : ${MAGENTA}${SUDO_USER:-$USER}${RESET}"
    echo
    echo -e "${CYAN}============================================================================${RESET}"
    echo
}

# ==============================================================================
#   MODULE EXECUTOR
# ==============================================================================

run_module() {

    local module="$1"

    if [[ ! -f "$module" ]]; then
        error_message "Module not found: $module"
        pause_screen
        return 1
    fi

    info_message "Executing module: $(basename "$module")"

    echo
    echo -e "${DIM}----------------------------------------------------------------------------${RESET}"
    echo

    bash "$module"

    local status=$?

    echo
    echo -e "${DIM}----------------------------------------------------------------------------${RESET}"

    if [[ $status -eq 0 ]]; then
        success_message "Module completed successfully."
    else
        warning_message "Module finished with exit code: $status"
    fi

    pause_screen

    return $status
}

# ==============================================================================
#   RUN ALL MODULES IN DIRECTORY
# ==============================================================================

run_directory_modules() {

    local directory="$1"

    if [[ ! -d "$directory" ]]; then
        error_message "Directory not found: $directory"
        pause_screen
        return 1
    fi

    local found=0

    for module in "$directory"/*.sh; do

        [[ -f "$module" ]] || continue

        found=1

        echo
        echo -e "${BLUE}${BOLD}Running:${RESET} ${CYAN}$(basename "$module")${RESET}"
        echo

        bash "$module"

        echo
        echo -e "${DIM}----------------------------------------------------------------------------${RESET}"

    done

    if [[ $found -eq 0 ]]; then
        warning_message "No modules found in $directory"
    else
        success_message "All modules completed."
    fi

    pause_screen
}

# ==============================================================================
#   FIREWALL MENU
# ==============================================================================

firewall_menu() {

    while true; do

        clear

        echo
        echo -e "${CYAN}============================================================================${RESET}"
        echo -e "${MAGENTA}${BOLD}                           FIREWALL AUDIT${RESET}"
        echo -e "${CYAN}============================================================================${RESET}"
        echo
        echo -e " ${GREEN}[1]${RESET} Firewall Status"
        echo -e " ${GREEN}[2]${RESET} UFW Configuration"
        echo -e " ${GREEN}[3]${RESET} Firewall Rules"
        echo -e " ${GREEN}[4]${RESET} Default Policy"
        echo -e " ${GREEN}[5]${RESET} Firewall Logging"
        echo -e " ${GREEN}[6]${RESET} Open Ports"
        echo -e " ${GREEN}[7]${RESET} Network Interfaces"
        echo
        echo -e " ${YELLOW}[8]${RESET} Complete Firewall Audit"
        echo
        echo -e " ${MAGENTA}[0]${RESET} Back"
        echo
        echo -e "${CYAN}============================================================================${RESET}"
        echo

        read -rp "$(echo -e "${CYAN}Select option:${RESET} ")" choice

        case "$choice" in

            1)
                run_module "$MODULE_DIR/firewall/firewall_status.sh"
                ;;

            2)
                run_module "$MODULE_DIR/firewall/ufw_configuration.sh"
                ;;

            3)
                run_module "$MODULE_DIR/firewall/firewall_rules.sh"
                ;;

            4)
                run_module "$MODULE_DIR/firewall/default_policy.sh"
                ;;

            5)
                run_module "$MODULE_DIR/firewall/firewall_logging.sh"
                ;;

            6)
                run_module "$MODULE_DIR/firewall/open_ports.sh"
                ;;

            7)
                run_module "$MODULE_DIR/firewall/network_interfaces.sh"
                ;;

            8)
                run_module "$MODULE_DIR/firewall/complete_firewall_audit.sh"
                ;;

            0)
                return
                ;;

            *)
                error_message "Invalid option."
                sleep 1
                ;;

        esac

    done
}

# ==============================================================================
#   PACKAGE MENU
# ==============================================================================

package_menu() {

    while true; do

        clear

        echo
        echo -e "${CYAN}============================================================================${RESET}"
        echo -e "${MAGENTA}${BOLD}                            PACKAGE AUDIT${RESET}"
        echo -e "${CYAN}============================================================================${RESET}"
        echo
        echo -e " ${GREEN}[1]${RESET} Package Manager"
        echo -e " ${GREEN}[2]${RESET} Installed Packages"
        echo -e " ${GREEN}[3]${RESET} Package Updates"
        echo -e " ${GREEN}[4]${RESET} Security Updates"
        echo -e " ${GREEN}[5]${RESET} Package Sources"
        echo -e " ${GREEN}[6]${RESET} Held Packages"
        echo -e " ${GREEN}[7]${RESET} Package Integrity"
        echo
        echo -e " ${YELLOW}[8]${RESET} Complete Package Audit"
        echo
        echo -e " ${MAGENTA}[0]${RESET} Back"
        echo
        echo -e "${CYAN}============================================================================${RESET}"
        echo

        read -rp "$(echo -e "${CYAN}Select option:${RESET} ")" choice

        case "$choice" in

            1)
                run_module "$MODULE_DIR/package/package_manager.sh"
                ;;

            2)
                run_module "$MODULE_DIR/package/installed_packages.sh"
                ;;

            3)
                run_module "$MODULE_DIR/package/package_updates.sh"
                ;;

            4)
                run_module "$MODULE_DIR/package/security_updates.sh"
                ;;

            5)
                run_module "$MODULE_DIR/package/package_sources.sh"
                ;;

            6)
                run_module "$MODULE_DIR/package/held_packages.sh"
                ;;

            7)
                run_module "$MODULE_DIR/package/package_integrity.sh"
                ;;

            8)
                run_module "$MODULE_DIR/package/complete_package_audit.sh"
                ;;

            0)
                return
                ;;

            *)
                error_message "Invalid option."
                sleep 1
                ;;

        esac

    done
}

# ==============================================================================
#   PERMISSION MENU
# ==============================================================================

permission_menu() {

    while true; do

        clear

        echo
        echo -e "${CYAN}============================================================================${RESET}"
        echo -e "${MAGENTA}${BOLD}                         PERMISSION AUDIT${RESET}"
        echo -e "${CYAN}============================================================================${RESET}"
        echo
        echo -e " ${GREEN}[1]${RESET} File Permissions"
        echo -e " ${GREEN}[2]${RESET} Directory Permissions"
        echo -e " ${GREEN}[3]${RESET} SUID Files"
        echo -e " ${GREEN}[4]${RESET} SGID Files"
        echo -e " ${GREEN}[5]${RESET} World-Writable Files"
        echo -e " ${GREEN}[6]${RESET} Special Permissions"
        echo -e " ${GREEN}[7]${RESET} ACL Audit"
        echo
        echo -e " ${YELLOW}[8]${RESET} Complete Permission Audit"
        echo
        echo -e " ${MAGENTA}[0]${RESET} Back"
        echo
        echo -e "${CYAN}============================================================================${RESET}"
        echo

        read -rp "$(echo -e "${CYAN}Select option:${RESET} ")" choice

        case "$choice" in

            1)
                run_module "$MODULE_DIR/permission/file_permissions.sh"
                ;;

            2)
                run_module "$MODULE_DIR/permission/directory_permissions.sh"
                ;;

            3)
                run_module "$MODULE_DIR/permission/suid_files.sh"
                ;;

            4)
                run_module "$MODULE_DIR/permission/sgid_files.sh"
                ;;

            5)
                run_module "$MODULE_DIR/permission/world_writable.sh"
                ;;

            6)
                run_module "$MODULE_DIR/permission/special_permissions.sh"
                ;;

            7)
                run_module "$MODULE_DIR/permission/acl_audit.sh"
                ;;

            8)
                run_module "$MODULE_DIR/permission/complete_permission_audit.sh"
                ;;

            0)
                return
                ;;

            *)
                error_message "Invalid option."
                sleep 1
                ;;

        esac

    done
}

# ==============================================================================
#   SSH MENU
# ==============================================================================

ssh_menu() {

    while true; do

        clear

        echo
        echo -e "${CYAN}============================================================================${RESET}"
        echo -e "${MAGENTA}${BOLD}                             SSH AUDIT${RESET}"
        echo -e "${CYAN}============================================================================${RESET}"
        echo
        echo -e " ${GREEN}[1]${RESET} SSH Service"
        echo -e " ${GREEN}[2]${RESET} SSH Configuration"
        echo -e " ${GREEN}[3]${RESET} SSH Port"
        echo -e " ${GREEN}[4]${RESET} Root Login"
        echo -e " ${GREEN}[5]${RESET} Password Authentication"
        echo -e " ${GREEN}[6]${RESET} SSH Key Authentication"
        echo -e " ${GREEN}[7]${RESET} Failed Logins"
        echo
        echo -e " ${YELLOW}[8]${RESET} Complete SSH Audit"
        echo
        echo -e " ${MAGENTA}[0]${RESET} Back"
        echo
        echo -e "${CYAN}============================================================================${RESET}"
        echo

        read -rp "$(echo -e "${CYAN}Select option:${RESET} ")" choice

        case "$choice" in

            1)
                run_module "$MODULE_DIR/ssh/ssh_service.sh"
                ;;

            2)
                run_module "$MODULE_DIR/ssh/ssh_configuration.sh"
                ;;

            3)
                run_module "$MODULE_DIR/ssh/ssh_port.sh"
                ;;

            4)
                run_module "$MODULE_DIR/ssh/root_login.sh"
                ;;

            5)
                run_module "$MODULE_DIR/ssh/password_authentication.sh"
                ;;

            6)
                run_module "$MODULE_DIR/ssh/ssh_key_authentication.sh"
                ;;

            7)
                run_module "$MODULE_DIR/ssh/failed_logins.sh"
                ;;

            8)
                run_module "$MODULE_DIR/ssh/complete_ssh_audit.sh"
                ;;

            0)
                return
                ;;

            *)
                error_message "Invalid option."
                sleep 1
                ;;

        esac

    done
}

# ==============================================================================
#   SYSTEM MENU
# ==============================================================================

system_menu() {

    while true; do

        clear

        echo
        echo -e "${CYAN}============================================================================${RESET}"
        echo -e "${MAGENTA}${BOLD}                           SYSTEM AUDIT${RESET}"
        echo -e "${CYAN}============================================================================${RESET}"
        echo
        echo -e " ${GREEN}[1]${RESET} OS Information"
        echo -e " ${GREEN}[2]${RESET} Kernel Information"
        echo -e " ${GREEN}[3]${RESET} Hardware Information"
        echo -e " ${GREEN}[4]${RESET} Hostname Information"
        echo -e " ${GREEN}[5]${RESET} Uptime Information"
        echo -e " ${GREEN}[6]${RESET} Logged Users"
        echo -e " ${GREEN}[7]${RESET} Running Services"
        echo
        echo -e " ${YELLOW}[8]${RESET} Complete System Audit"
        echo
        echo -e " ${MAGENTA}[0]${RESET} Back"
        echo
        echo -e "${CYAN}============================================================================${RESET}"
        echo

        read -rp "$(echo -e "${CYAN}Select option:${RESET} ")" choice

        case "$choice" in

            1)
                run_module "$MODULE_DIR/system/os_information.sh"
                ;;

            2)
                run_module "$MODULE_DIR/system/kernel_information.sh"
                ;;

            3)
                run_module "$MODULE_DIR/system/hardware_information.sh"
                ;;

            4)
                run_module "$MODULE_DIR/system/hostname_information.sh"
                ;;

            5)
                run_module "$MODULE_DIR/system/uptime_information.sh"
                ;;

            6)
                run_module "$MODULE_DIR/system/logged_users.sh"
                ;;

            7)
                run_module "$MODULE_DIR/system/running_services.sh"
                ;;

            8)
                run_module "$MODULE_DIR/system/complete_audit.sh"
                ;;

            0)
                return
                ;;

            *)
                error_message "Invalid option."
                sleep 1
                ;;

        esac

    done
}

# ==============================================================================
#   USER MENU
# ==============================================================================

user_menu() {

    while true; do

        clear

        echo
        echo -e "${CYAN}============================================================================${RESET}"
        echo -e "${MAGENTA}${BOLD}                            USER AUDIT${RESET}"
        echo -e "${CYAN}============================================================================${RESET}"
        echo
        echo -e " ${GREEN}[1]${RESET} List All Users"
        echo -e " ${GREEN}[2]${RESET} Human Users"
        echo -e " ${GREEN}[3]${RESET} Locked Users"
        echo -e " ${GREEN}[4]${RESET} Login Shell Users"
        echo -e " ${GREEN}[5]${RESET} Password Aging"
        echo -e " ${GREEN}[6]${RESET} Root Accounts"
        echo -e " ${GREEN}[7]${RESET} Sudo Users"
        echo
        echo -e " ${YELLOW}[8]${RESET} Complete User Audit"
        echo
        echo -e " ${MAGENTA}[0]${RESET} Back"
        echo
        echo -e "${CYAN}============================================================================${RESET}"
        echo

        read -rp "$(echo -e "${CYAN}Select option:${RESET} ")" choice

        case "$choice" in

            1)
                run_module "$MODULE_DIR/user/list_all_users.sh"
                ;;

            2)
                run_module "$MODULE_DIR/user/human_users.sh"
                ;;

            3)
                run_module "$MODULE_DIR/user/locked_users.sh"
                ;;

            4)
                run_module "$MODULE_DIR/user/login_shell_users.sh"
                ;;

            5)
                run_module "$MODULE_DIR/user/password_aging.sh"
                ;;

            6)
                run_module "$MODULE_DIR/user/root_accounts.sh"
                ;;

            7)
                run_module "$MODULE_DIR/user/sudo_users.sh"
                ;;

            8)
                run_module "$MODULE_DIR/user/complete_user_audit.sh"
                ;;

            0)
                return
                ;;

            *)
                error_message "Invalid option."
                sleep 1
                ;;

        esac

    done
}

# ==============================================================================
#   COMPLETE SECURITY AUDIT
# ==============================================================================

complete_security_audit() {

    clear

    echo
    echo -e "${CYAN}============================================================================${RESET}"
    echo -e "${MAGENTA}${BOLD}                    COMPLETE SECURITY AUDIT${RESET}"
    echo -e "${CYAN}============================================================================${RESET}"
    echo
    echo "The toolkit will now execute all security audit categories."
    echo
    echo -e "${YELLOW}This may take some time.${RESET}"
    echo
    echo -e "${CYAN}============================================================================${RESET}"
    echo

    read -rp "$(echo -e "${YELLOW}Continue? [y/N]: ${RESET}")" answer

    case "$answer" in

        y|Y)

            echo
            info_message "Starting complete security audit..."
            echo

            run_directory_modules "$MODULE_DIR/system"
            run_directory_modules "$MODULE_DIR/user"
            run_directory_modules "$MODULE_DIR/permission"
            run_directory_modules "$MODULE_DIR/package"
            run_directory_modules "$MODULE_DIR/ssh"
            run_directory_modules "$MODULE_DIR/firewall"

            success_message "Complete security audit finished."

            ;;

        *)
#!/usr/bin/env bash

# ==========================================
# UBUNTU SECURITY AUDIT AND HARDENING TOOLKIT
# MAIN MENU
# ==========================================

PROJECT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Function to execute an individual module

run_module() {
    MODULE_PATH="$PROJECT_ROOT/$1"

    echo ""
    echo "=========================================="

    if [ ! -f "$MODULE_PATH" ]; then
        echo "[ERROR] Module file not found:"
        echo "$MODULE_PATH"
        echo "Please check the filename and location."
        echo "=========================================="
        return 1
    fi

    echo "Running: $1"
    echo "=========================================="
    echo ""

    bash "$MODULE_PATH"
    MODULE_STATUS=$?

    echo ""
    echo "=========================================="

    if [ "$MODULE_STATUS" -eq 0 ]; then
        echo "[+] Module execution completed."
    else
        echo "[!] Module exited with an error."
    fi

    echo "=========================================="

    return "$MODULE_STATUS"
}

# Function to run all audit modules

run_all_modules() {

    MODULES=(
        "modules/user/user_audit.sh"
        "modules/permission/file_permission.sh"
        "modules/password/password_audit.sh"
        "modules/network/network_audit.sh"
        "modules/firewall/firewall_audit.sh"
        "modules/ssh/ssh_audit.sh"
        "modules/service/service_audit.sh"
        "modules/package/package_audit.sh"
        "modules/logs/log_audit.sh"
        "modules/backup/backup.sh"
    )

    echo ""
    echo "=========================================="
    echo "       RUNNING ALL SECURITY MODULES"
    echo "=========================================="

    for MODULE in "${MODULES[@]}"; do
        run_module "$MODULE"
    done

    echo ""
    echo "=========================================="
    echo "       ALL MODULES EXECUTED"
    echo "=========================================="
}

# Main menu loop

while true
do
    clear

    echo "================================================"
    echo "     UBUNTU SECURITY AUDIT AND HARDENING TOOLKIT"
    echo "================================================"
    echo ""
    echo "  1. User Security Audit"
    echo "  2. File Permission Audit"
    echo "  3. Password Security Audit"
    echo "  4. Network Security Audit"
    echo "  5. Firewall Security Audit"
    echo "  6. SSH Security Audit"
    echo "  7. Service Security Audit"
    echo "  8. Package Security Audit"
    echo "  9. Log Monitoring Audit"
    echo " 10. Backup and Recovery"
    echo " 11. Run All Security Audits"
    echo " 12. Exit"
    echo ""
    echo "================================================"

    read -r -p "Enter your choice [1-12]: " choice

    case "$choice" in

        1)
            run_module "modules/user/user_audit.sh"
            ;;

        2)
            run_module "modules/permission/file_permission.sh"
            ;;

        3)
            run_module "modules/password/password_audit.sh"
            ;;

        4)
            run_module "modules/network/network_audit.sh"
            ;;

        5)
            run_module "modules/firewall/firewall_audit.sh"
            ;;

        6)
            run_module "modules/ssh/ssh_audit.sh"
            ;;

        7)
            run_module "modules/service/service_audit.sh"
            ;;

        8)
            run_module "modules/package/package_audit.sh"
            ;;

        9)
            run_module "modules/logs/log_audit.sh"
            ;;

        10)
            run_module "modules/backup/backup.sh"
            ;;

        11)
            run_all_modules
            ;;

        12)
            echo ""
            echo "Thank you for using Ubuntu Security Toolkit."
            echo "Exiting program..."
            exit 0
            ;;

        *)
            echo ""
            echo "[!] Invalid choice. Please enter a number from 1 to 12."
            ;;

    esac

    echo ""
    read -r -p "Press Enter to return to the main menu..."
done

            info_message "Operation cancelled."
            pause_screen
            ;;

    esac
}

# ==============================================================================
#   SYSTEM INFORMATION
# ==============================================================================

system_information() {

    clear

    echo
    echo -e "${CYAN}============================================================================${RESET}"
    echo -e "${MAGENTA}${BOLD}                         SYSTEM INFORMATION${RESET}"
    echo -e "${CYAN}============================================================================${RESET}"
    echo

    echo -e "${WHITE}Hostname      :${RESET} ${CYAN}$(hostname)${RESET}"
    echo -e "${WHITE}Kernel        :${RESET} ${GREEN}$(uname -r)${RESET}"
    echo -e "${WHITE}Architecture  :${RESET} ${BLUE}$(uname -m)${RESET}"
    echo -e "${WHITE}IP Address    :${RESET} ${CYAN}$(hostname -I 2>/dev/null | xargs)${RESET}"
    echo -e "${WHITE}Uptime        :${RESET} ${GREEN}$(uptime -p 2>/dev/null)${RESET}"
    echo -e "${WHITE}Current User  :${RESET} ${MAGENTA}${SUDO_USER:-$USER}${RESET}"
    echo -e "${WHITE}Date          :${RESET} ${YELLOW}$(date '+%d-%m-%Y %H:%M:%S')${RESET}"

    echo
    echo -e "${CYAN}============================================================================${RESET}"

    pause_screen
}

# ==============================================================================
#   TOOLKIT HEALTH CHECK
# ==============================================================================

health_check() {

    clear

    echo
    echo -e "${CYAN}============================================================================${RESET}"
    echo -e "${MAGENTA}${BOLD}                         TOOLKIT HEALTH CHECK${RESET}"
    echo -e "${CYAN}============================================================================${RESET}"
    echo

    local failed=0

    echo -e "${BLUE}[1]${RESET} Checking common.sh..."

    if [[ -f "$COMMON" ]]; then
        success_message "common.sh found."
    else
        error_message "common.sh missing."
        failed=$((failed + 1))
    fi

    echo
    echo -e "${BLUE}[2]${RESET} Checking module directories..."

    local directories=(
        "$MODULE_DIR/firewall"
        "$MODULE_DIR/package"
        "$MODULE_DIR/permission"
        "$MODULE_DIR/ssh"
        "$MODULE_DIR/system"
        "$MODULE_DIR/user"
    )

    for directory in "${directories[@]}"; do

        if [[ -d "$directory" ]]; then
            success_message "$(basename "$directory") module directory OK."
        else
            error_message "$(basename "$directory") module directory missing."
            failed=$((failed + 1))
        fi

    done

    echo
    echo -e "${BLUE}[3]${RESET} Checking required commands..."

    local commands=(
        bash
        awk
        sed
        grep
        find
        cut
        sort
        systemctl
        apt
        dpkg
        ss
    )

    for command_name in "${commands[@]}"; do

        if command -v "$command_name" >/dev/null 2>&1; then
            success_message "$command_name available."
        else
            warning_message "$command_name not available."
        fi

    done

    echo
    echo -e "${CYAN}============================================================================${RESET}"

    if [[ $failed -eq 0 ]]; then
        success_message "Toolkit health check PASSED."
    else
        warning_message "Toolkit health check completed with $failed issue(s)."
    fi

    pause_screen
}

# ==============================================================================
#   ABOUT
# ==============================================================================

about_toolkit() {

    clear

    echo
    echo -e "${CYAN}============================================================================${RESET}"
    echo -e "${MAGENTA}${BOLD}                              ABOUT${RESET}"
    echo -e "${CYAN}============================================================================${RESET}"
    echo
    echo -e " ${WHITE}$TOOL_NAME${RESET}"
    echo
    echo -e "${WHITE} Version :${RESET} ${GREEN}$VERSION${RESET}"
    echo
    echo -e "${CYAN}Purpose:${RESET}"
    echo
    echo -e "  ${GREEN}•${RESET} Ubuntu security auditing"
    echo -e "  ${GREEN}•${RESET} User and account auditing"
    echo -e "  ${GREEN}•${RESET} File and directory permission auditing"
    echo -e "  ${GREEN}•${RESET} SUID / SGID analysis"
    echo -e "  ${GREEN}•${RESET} ACL auditing"
    echo -e "  ${GREEN}•${RESET} Package security auditing"
    echo -e "  ${GREEN}•${RESET} SSH security auditing"
    echo -e "  ${GREEN}•${RESET} Firewall and network auditing"
    echo -e "  ${GREEN}•${RESET} System information auditing"
    echo -e "  ${GREEN}•${RESET} Security reporting"
    echo -e "  ${GREEN}•${RESET} Security configuration backup"
    echo
    echo -e "${CYAN}Technology:${RESET}"
    echo
    echo -e "  ${BLUE}•${RESET} Ubuntu Linux"
    echo -e "  ${BLUE}•${RESET} Bash Shell Scripting"
    echo -e "  ${BLUE}•${RESET} Linux Security Utilities"
    echo
    echo -e "${CYAN}============================================================================${RESET}"

    pause_screen
}

# ======================================================================

#!/usr/bin/env bash

# ==========================================
# UBUNTU SECURITY AUDIT AND HARDENING TOOLKIT
# MAIN MENU
# ==========================================

PROJECT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Function to execute an individual module

run_module() {
    MODULE_PATH="$PROJECT_ROOT/$1"

    echo ""
    echo "=========================================="

    if [ ! -f "$MODULE_PATH" ]; then
        echo "[ERROR] Module file not found:"
        echo "$MODULE_PATH"
        echo "Please check the filename and location."
        echo "=========================================="
        return 1
    fi

    echo "Running: $1"
    echo "=========================================="
    echo ""

    bash "$MODULE_PATH"
    MODULE_STATUS=$?

    echo ""
    echo "=========================================="

    if [ "$MODULE_STATUS" -eq 0 ]; then
        echo "[+] Module execution completed."
    else
        echo "[!] Module exited with an error."
    fi

    echo "=========================================="

    return "$MODULE_STATUS"
}

# Function to run all audit modules

run_all_modules() {

    MODULES=(
        "modules/user/user_audit.sh"
        "modules/permission/file_permission.sh"
        "modules/password/password_audit.sh"
        "modules/network/network_audit.sh"
        "modules/firewall/firewall_audit.sh"
        "modules/ssh/ssh_audit.sh"
        "modules/service/service_audit.sh"
        "modules/package/package_audit.sh"
        "modules/logs/log_audit.sh"
        "modules/backup/backup.sh"
    )

    echo ""
    echo "=========================================="
    echo "       RUNNING ALL SECURITY MODULES"
    echo "=========================================="

    for MODULE in "${MODULES[@]}"; do
        run_module "$MODULE"
    done

    echo ""
    echo "=========================================="
    echo "       ALL MODULES EXECUTED"
    echo "=========================================="
}

# Main menu loop

while true
do
    clear

    echo "================================================"
    echo "     UBUNTU SECURITY AUDIT AND HARDENING TOOLKIT"
    echo "================================================"
    echo ""
    echo "  1. User Security Audit"
    echo "  2. File Permission Audit"
    echo "  3. Password Security Audit"
    echo "  4. Network Security Audit"
    echo "  5. Firewall Security Audit"
    echo "  6. SSH Security Audit"
    echo "  7. Service Security Audit"
    echo "  8. Package Security Audit"
    echo "  9. Log Monitoring Audit"
    echo " 10. Backup and Recovery"
    echo " 11. Run All Security Audits"
    echo " 12. Exit"
    echo ""
    echo "================================================"

    read -r -p "Enter your choice [1-12]: " choice

    case "$choice" in

        1)
            run_module "modules/user/user_audit.sh"
            ;;

        2)
            run_module "modules/permission/file_permission.sh"
            ;;

        3)
            run_module "modules/password/password_audit.sh"
            ;;

        4)
            run_module "modules/network/network_audit.sh"
            ;;

        5)
            run_module "modules/firewall/firewall_audit.sh"
            ;;

        6)
            run_module "modules/ssh/ssh_audit.sh"
            ;;

        7)
            run_module "modules/service/service_audit.sh"
            ;;

        8)
            run_module "modules/package/package_audit.sh"
            ;;

        9)
            run_module "modules/logs/log_audit.sh"
            ;;

        10)
            run_module "modules/backup/backup.sh"
            ;;

        11)
            run_all_modules
            ;;

        12)
            echo ""
            echo "Thank you for using Ubuntu Security Toolkit."
            echo "Exiting program..."
            exit 0
            ;;

        *)
            echo ""
            echo "[!] Invalid choice. Please enter a number from 1 to 12."
            ;;

    esac

    echo ""
    read -r -p "Press Enter to return to the main menu..."
done
